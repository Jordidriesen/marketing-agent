<?php
function init_block_cases_archive() {
    if ( ! function_exists( 'acf_register_block' ) ) {
        return;
    }

    acf_register_block( array(
        'name'              => 'cases-archive',
        'title'             => __( 'Archiv für Cases / Archive for Cases', 'ATLAS' ),
        'description'       => __( 'cases-archive', 'ATLAS' ),
        'category'          => 'custom_blocks',
        'icon'              => 'media-code',
        'mode'              => 'auto',
        'keywords'          => array( 'cases archive', 'slider', 'articles', 'neu' ),
        'align'             => 'full',
        'supports'          => array(
			'align' => false,
        ),
		'example'         => [
            'attributes' => [
                'mode' => 'auto',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-cases-archive/index.php',
    ));
}

add_action( 'acf/init', 'init_block_cases_archive' );