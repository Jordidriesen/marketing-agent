<?php
/**
 * The footer for theme.
 *
 * Hooks for placing content (used by the ATLAS Content Blocks plugin):
 * - atlas_before_footer After the page content, before the site footer
 * - atlas_after_footer  After the site footer
 *
 * @package    WordPress
 * @subpackage ATLAS
 * @since      ATLAS 1.0
 */

?>
	<?php do_action( 'atlas_before_footer' ); ?>
	<?php get_theme_part('components/footer/main'); ?>
	<?php do_action( 'atlas_after_footer' ); ?>
</div> <!-- /#page -->
<?php wp_footer(); ?>
<?php echo Theme_App::render_scripts( 'end_scripts' ); ?>
</body>
</html>
