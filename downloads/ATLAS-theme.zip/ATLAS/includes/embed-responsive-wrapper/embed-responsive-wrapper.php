<?php
/**
 * Adds embed responsive wrapper
 *
 * @package WordPress
 * @subpackage ATLAS
 * @since ATLAS 1.0
 */

add_filter( 'embed_oembed_html', 'oembed_video_wrapper', 99, 4 );

function oembed_video_wrapper( $cached_html, $url ) {
	$class = 'iframe-wrapper';
	$icon  = get_svg( 'video-play' );
	$id    = substr( $url, strrpos( $url, '/' ) + 1 );

	// The overlay needs its script, so load it on pages that render an embed.
	wp_enqueue_script( 'ATLAS/block_embed_script' );

	if ( strpos( $url, 'wistia' ) !== false ) {
		$class  .= ' wistia';
		$data    = json_decode( file_get_contents( "https://fast.wistia.com/oembed?url=$url" ) );
		$img_src = $data->thumbnail_url;
	} elseif ( strpos( $url, 'vimeo' ) !== false ) {
		$class  .= ' vimeo';
		$data    = json_decode( file_get_contents( "https://vimeo.com/api/v2/video/$id.json" ) );
		$img_src = $data[0]->thumbnail_large;
	} else {
		$class  .= ' youtube';
		$img_src = "https://img.youtube.com/vi/$id/0.jpg";
	}

	return "<div class='$class' data-video-id='$id'>
                <div class='iframe-wrapper__overlay' style='background-image: url($img_src);'>
                    <button class='iframe-wrapper__play'>$icon</button>
                </div>
                $cached_html
            </div>";
}