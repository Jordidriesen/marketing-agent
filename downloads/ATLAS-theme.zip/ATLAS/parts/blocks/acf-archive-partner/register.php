<?php
function init_block_archive_partner_slider()
{
    if (! function_exists('acf_register_block')) {
        return;
    }

    acf_register_block(array(
        'name'              => 'archive-partner',
        'title'             => __('Partner Archiv / Partner Archive', 'ATLAS'),
        'description'       => __('Partner Archiv', 'ATLAS'),
        'category'          => 'custom_blocks',
        'icon'              => 'media-code',
        'mode'              => 'auto',
        'keywords'          => array('archive', 'partner', 'articles', 'neu'),
        'align'             => 'full',
        'supports'          => array(
            'align' => false,
        ),
        'example'         => [
            'attributes' => [
                'mode' => 'auto',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-archive-partner/index.php',
        'enqueue_assets'  => function () {
            $block_directory = basename(__DIR__);
            wp_enqueue_style(
                'ATLAS/'.$block_directory,
                get_template_directory_uri(). '/parts/blocks/'.$block_directory. '/style.css'
            );
        }
    ));
}

add_action('acf/init', 'init_block_archive_partner_slider');
