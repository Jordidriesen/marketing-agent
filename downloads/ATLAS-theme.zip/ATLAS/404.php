<?php
/**
 * The 404 page template.
 *
 * @package    WordPress
 * @subpackage ATLAS
 * @since      ATLAS 1.0
 */

get_header();
?>
	<main style="margin-top: 120px; min-height:50vh;" class="page-content page-content--404">
		<div class="container" style="text-align: center;">
			<h1><?php _e( '404 - Page not found' ); ?></h1>
			<h2 style="margin-bottom: 32px;">
				<?php _e( 'It seems like you dont have access to this site.', 'ATLAS' ); ?>
			</h2>
			
			<?php 
				$name = 'core-button';
				loadStylesDep('blocks/core-button', $name); 
			?>
			<div class="wp-block-button">
				<a class="wp-block-button__link" href="<?php echo home_url(); ?>" target="_self"><?php echo _e( 'Back to Homepage', 'ATLAS' ); ?></a>
			</div>
		</div>
	</main>
<?php
get_footer();
