<?php
function admin_style() {
    wp_enqueue_style('admin-styles', get_template_directory_uri().'/css/style-admin.css');
}

add_action('admin_enqueue_scripts', 'admin_style');


// Enqueue admin styles on frontend when user logged in for custom admin bar

if(is_user_logged_in()) {
    add_action( 'wp_enqueue_scripts', function() {
        wp_enqueue_style('admin-custom-colors', get_template_directory_uri().'/css/admin/colors/theme/colors-front.css');
    });
}