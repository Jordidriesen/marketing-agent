<?php
if ( isset($id) ):
	$img = get_the_post_thumbnail($id,'news-image');
	$title = get_the_title($id);
	$short_desc = get_the_excerpt($id);
	$link_url = get_permalink($id);
	$link_target = isset($link_target) ? $link_target : '_self';

	$date = get_field('webinar_date', $id);
	$time_start = get_field('webinar_time_start', $id);
	$duration = get_field('webinar_duration', $id);

	// Without a date the webinar is a recording, not an upcoming live session
	$is_recorded = empty($date);

	if ( $is_recorded ) {
		$link_title = !empty($btn_txt_recorded) ? $btn_txt_recorded : __('Watch replay', 'ATLAS');
	} else {
		$link_title = !empty($btn_txt) ? $btn_txt : __('Register', 'ATLAS');
	}

	$webinar_types = get_the_terms($id, 'webinar-type');
	$term = ($webinar_types && !is_wp_error($webinar_types)) ? $webinar_types[0] : false;
?>
<div class="single-webinar-card">
	<?php loadStyles(__DIR__, 'single-webinar-card'); ?>
	<div class="single-webinar-card__wrapper">
	<?php if (!empty($img)) : ?>
		<figure class="single-webinar-card__img">
			<?php if ( $term ) : ?>
			<span class="single-webinar-card__term"><?php echo esc_html( $term->name ); ?></span>
			<?php endif; ?>

			<?php echo $img; ?>
		</figure>
	<?php endif; ?>
		<div class="single-webinar-card__content">

			<div class="single-webinar-card__meta">
				<?php if ( $is_recorded ) : ?>
					<span class="single-webinar-card__recorded"><?php echo __('Recorded', 'ATLAS'); ?></span>

					<?php if (!empty($duration)) : ?>
						<span class="single-webinar-card__meta--space"> · </span>
						<span class="single-webinar-card__duration"><?php printf(__('%s min', 'ATLAS'), esc_html($duration)); ?></span>
					<?php endif; ?>
				<?php else : ?>
					<time class="single-webinar-card__date" datetime="<?php echo esc_attr(date_i18n('Y-m-d', strtotime($date))); ?>"><?php echo date_i18n('d M Y', strtotime($date)); ?></time>

					<?php if (!empty($time_start)) : ?>
						<span class="single-webinar-card__meta--space"> · </span>
						<span class="single-webinar-card__time"><?php echo date_i18n(get_option('time_format'), strtotime($time_start)) . ' CET'; ?></span>
					<?php endif; ?>
				<?php endif; ?>
			</div>
			<h3 class="single-webinar-card__title" role="heading"><?php echo $title; ?></h3>
			<?php if (!empty($short_desc)) : ?>
				<span class="single-webinar-card__desc"><?php echo $short_desc; ?></span>
			<?php endif; ?>
			<?php $name = 'core-button';?>
			<?php loadStylesDep('blocks/core-button', $name); ?>
			<div class="wp-block-button is-style-link-only"><a class="wp-block-button__link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a></div>
		</div>
	</div>
</div>
<?php
endif;
