<?php
/**
 * Block with content hero
 *
 * @package WordPress
 * @subpackage ATLAS
 * @since ATLAS 1.0
 */
$block_object = new Block( $block );

$hero_style = 'full-width';

loadAcfBlockPreviewImage(__DIR__);

if ( have_rows('hero_row') ) :
    $name = $block_object->block_name();
    $hero_class = 'block-hero__wrapper block-hero__wrapper--' . $hero_style;
    $layout_counter = $block['id'];
?>
<section class="block-hero">
    <?php loadStyles(__DIR__, $name); ?>
    <div class="block-hero__container">
        <div class="<?php echo $hero_class; ?>" data-hero="<?php echo $layout_counter; ?>">
        <?php
        while ( have_rows('hero_row') ) : the_row() ;
            $content = get_sub_field('content');
            $primary_button = get_sub_field('primary_button');
            $secondary_button = get_sub_field('secondary_button');

            $single_class = "hero-image hero-image--$hero_style";
            $content_row = 'hero-image__content-row';

            $bg_html = '';
        ?>
            <div class="<?php echo $single_class; ?>">
                <div class="hero-image__wrapper">

                    <?php 
                        $hero_select = get_sub_field('hero_select');
                        if ( $hero_select == 'image' ) :
                            $hero_img = wp_get_attachment_image(get_sub_field('image'), 'full', false, 'data-object-fit');
                    ?>
                        <div class="hero-image__bg">
                        <div class="hero-image__bg--overlay"></div>
                            <?php 
                            echo $hero_img;
                        ?></div>
                    <?php 
                        elseif( $hero_select == 'video' ):
                            $hero_media = get_sub_field('video');
                    ?>
                        <div class="hero-image__bg video">
                            <div class="hero-image__bg-vid">
                                <video class="hero-image__bg-video" autoplay="" muted="" loop="" playsinline="" src="<?php echo $hero_media; ?>" data-object-fit="cover"></video>
                            </div>
                        </div>                    
                    <?php else: ?>
                        <div class="hero-image__bg video">
                            <?php 
                                $fallback = get_sub_field('video_yt_fallback'); 
                                if( $fallback ) :
                            ?>
                                    <style>
                                    .hero-image__bg-vid::after {
                                        background-image: url('<?php echo $fallback; ?>')!important;
                                    }
                                    </style>
                            <?php endif; ?>
                            <div class="hero-image__bg-vid">
                                <?php
                                    $video = get_sub_field('video_yt'); // Get video from ACF oEmbed
                                    $videoUrl = get_sub_field('video_yt', false); // Get video Url
                                    
                                    parse_str( parse_url( $videoUrl, PHP_URL_QUERY ), $videoId );
                                    preg_match('/src="(.+?)"/', $video, $matches);
                                    $src = $matches[1];
                                
                                    $params = array(
                                    'controls' => 0,
                                    'hd' => 1,
                                    'disablekb' => 1,
                                    'modestbranding' => 1,
                                    'rel' => 0,
                                    'autoplay' => 1,
                                    'loop' => 1,
                                    'showinfo' => 0,
                                    'mute' => 1,
                                    'playlist' => $videoId['v']
                                    );
                                
                                    $new_src = add_query_arg($params, $src);
                                    $video = str_replace($src, $new_src, $video);
                                    $attributes = 'frameborder="0"';
                                
                                    $video = str_replace('></iframe>', ' ' . $attributes . '></iframe>', $video);
                                
                                    echo $video; 
                                ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="hero-image__content-wrapper">
                        <div class="container hero-image__content-container">
                            <div class="<?php echo $content_row; ?>">
                                <div class="hero-image__content">
                                    <?php echo $content; ?>
                                <?php if ( !empty($primary_button) || !empty($secondary_button) ) : ?>
                                    <div class="hero-image__buttons">
                                        <div data-styles-id="core-button"></div>
                                    <?php 
                                    if (!empty($primary_button)) :
                                        $link = $primary_button;
                                        $link_url = $link['url'];
                                        $link_title = $link['title'];
                                        $link_target = $link['target'] ? $link['target'] : '_self';
                                    ?>
                                        <div class="wp-block-button"><a class="wp-block-button__link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a></div>
                                    <?php endif; ?>
                                    <?php 
                                    if (!empty($secondary_button)) :
                                        $link = $secondary_button;
                                        $link_url = $link['url'];
                                        $link_title = $link['title'];
                                        $link_target = $link['target'] ? $link['target'] : '_self';
                                    ?>
                                        <div class="wp-block-button is-style-fill-secondary"><a class="wp-block-button__link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a></div>
                                    <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php
        endwhile;
        ?>
        </div>
    </div>
</section>
<?php
endif;