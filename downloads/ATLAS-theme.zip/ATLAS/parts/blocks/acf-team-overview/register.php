<?php
// Register CPT Team if doesn't exists
custom_register_team_cpt();

// Register block
function init_block_team_overview() {
    if ( ! function_exists( 'acf_register_block' ) ) {
        return;
    }

    acf_register_block( array(
        'name'              => 'team-overview',
        'title'             => __( 'Mitarbeiter Übersicht / Team Overview', 'ATLAS' ),
        'description'       => __( 'Team Overview', 'ATLAS' ),
        'category'          => 'custom_blocks',
        'icon'              => 'groups',
        'mode'              => 'auto',
        'keywords'          => array( 'team', 'team overview', 'overview', 'mitarbeiter', 'übersicht' ),
        'supports'          => array(
			'align' => false,
        ),
		'example'         => [
            'attributes' => [
                'mode' => 'auto',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-team-overview/index.php',
    ));
}

add_action( 'acf/init', 'init_block_team_overview' );