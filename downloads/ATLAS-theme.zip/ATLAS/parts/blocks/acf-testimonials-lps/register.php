<?php
function init_block_testimonials_lps() {
    if ( ! function_exists( 'acf_register_block' ) ) {
        return;
    }

    acf_register_block( array(
        'name'              => 'testimonials-lps',
        'title'             => __( 'Kundenrezensionen (LPs) / Testimonials (LPs)', 'ATLAS' ),
        'description'       => __( 'testimonials-lps', 'ATLAS' ),
        'category'          => 'custom_blocks',
        'icon'              => 'slides',
        'mode'              => 'auto',
        'keywords'          => array( 'slider', 'testimonials', 'landingpage' ),
        'align'             => 'full',
        'supports'          => array(
			'align' => false
        ),
		'example'         => [
            'attributes' => [
                'mode' => 'auto',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-testimonials-lps/index.php',
        'enqueue_assets'  => function () {
			wp_enqueue_script(
				'ATLAS/acf-testimonials-lps',
                get_template_directory_uri() . '/parts/blocks/acf-testimonials-lps/index.min.js',
                [ 'splide_script' ],
                false,
                array(
                    'in_footer' => true,
                    'strategy'  => 'defer',
                )
			);
		}
    ));
}

add_action( 'acf/init', 'init_block_testimonials_lps' );