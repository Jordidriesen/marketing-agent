<?php
function extend_block_paragraph_script() {
    wp_enqueue_script(
        'core/paragraph',
        get_template_directory_uri() . '/parts/blocks/core-paragraph/admin.min.js',
        array( 'wp-i18n', 'wp-dom-ready', 'wp-editor', 'wp-blocks', 'wp-compose', 'wp-element', 'wp-hooks' )
    );
}
add_action( 'enqueue_block_editor_assets', 'extend_block_paragraph_script' );