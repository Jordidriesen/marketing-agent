<?php

	$block_object = new Block( $block );
	$name = $block_object->block_name();

	$class = $block_object->block_class();

	if( have_rows( 'timeline_repeater' ) ):

	loadAcfBlockPreviewImage(__DIR__);
?>

<div class="<?php echo $class; ?>">

<?php loadStylesThird('splide'); ?>
<?php loadStylesComponents('sliders'); ?>
<?php echo loadStyles(__DIR__, $name); ?>

	<ul class="timeline_list js-timeline">

<?php

		while( have_rows( 'timeline_repeater' ) ) : the_row();
			$headline = get_sub_field( 'timeline_headline' );
			$editor = get_sub_field( 'timeline_editor' );

?>
		<li class="timeline_list-item js-timeline_list-item">

			<div class="timeline_list-content">
				<h3><?php echo $headline; ?></h3>
				<div><?php echo $editor; ?></div>
			</div>

			<div class="timeline_list-marker">
				<div class="timeline_list-marker-point"></div>

			</div>
			
		</li>

<?php

		endwhile;

?>

	</ul>

</div>

<?php

	endif;

?>