<?php
/**
 * Menu Item Template: Menu Template
 */
$rows = ! empty( $rows ) ? $rows : []; ?>
<div class="mega-menu-wrapper">    
    <div class="mega-menu-wrapper__container">
    <?php
    foreach ( $rows as $row ) : 
        $columns = ! empty( $row['menu_columns'] ) ? $row['menu_columns'] : [];
        ?>
        <div class="sub-menu-wrapper__row">
            <?php 
            foreach ( $columns as $column ) : 
                $heading_type = $column['type'];
                $text = $column['text'];
                $link = $column['link'];
                $editor = $column['editor'];
            ?>
            <div class="sub-menu-wrapper">
                <?php if ( ! empty( $link ) || !empty( $text ) ) : ?>
                    <p class="sub-menu-text"><?php 
                    if ( $heading_type === 'link' ) {
                        echo '<span class="h3">';
                        echo esc_html( $link['title'], 'ATLAS' );
                        echo '</span>';
                    } else {
                        echo '<span class="h3">' . esc_html( $text, 'ATLAS' ) . '</span>';
                    }
                    ?></p>
                <?php else: ?>
                    <div class="sub-menu-spacing"></div>
                <?php endif;

                    if ( ! empty( $editor ) ) : ?>
                    <div class="sub-menu-editor"><?php echo $editor; ?></div>
                <?php
                endif;
                $deactivate_menu = $column['deactivate_menu'];
                if ( isset( $column['menu'] ) && ! empty( $column['menu'] ) && ! $deactivate_menu ) :
                    wp_nav_menu(
                        array(
                            'menu'       => intval( $column['menu'] ),
                            'container'  => false,
                            'menu_class' => 'sub-menu',
                        )
                    );
                elseif ( $heading_type === 'link' && ! empty( $link['url'] ) ) : 
                    $link_text = $column['link_text'] ? $column['link_text'] : $link['title'];
                ?>
                    <a href="<?php echo esc_url( $link['url'] ); ?>" class="sub-menu-link"><?php echo $link_text; ?></a>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        </div>
    <?php endforeach; ?>
    </div>
</div>
