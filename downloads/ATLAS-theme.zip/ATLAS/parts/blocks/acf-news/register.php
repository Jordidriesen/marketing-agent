<?php
function init_block_news_slider() {
    if ( ! function_exists( 'acf_register_block' ) ) {
        return;
    }

    acf_register_block( array(
        'name'              => 'news',
        'title'             => __( 'Neuigkeiten / News', 'ATLAS' ),
        'description'       => __( 'News', 'ATLAS' ),
        'category'          => 'custom_blocks',
        'icon'              => 'media-code',
        'mode'              => 'auto',
        'keywords'          => array( 'news', 'slider', 'articles', 'neu' ),
        'align'             => 'full',
        'supports'          => array(
			'align' => false,
        ),
		'example'         => [
            'attributes' => [
                'mode' => 'auto',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-news/index.php',
        'enqueue_assets'  => function () {
			wp_enqueue_script(
				'ATLAS/acf-news',
                get_template_directory_uri() . '/parts/blocks/acf-news/index.min.js',
                [ 'splide_script' ],
                false,
                array(
                    'in_footer' => true,
                    'strategy'  => 'defer',
                )
			);
		}
    ));
}

add_action( 'acf/init', 'init_block_news_slider' );