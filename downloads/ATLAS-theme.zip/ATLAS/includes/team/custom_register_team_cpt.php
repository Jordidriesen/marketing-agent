<?php
function register_team_init() {
	$labels = array(
		'name'                  => _x( 'Team', 'Post type general name', 'ATLAS' ),
		'singular_name'         => _x( 'Team', 'Post type singular name', 'ATLAS' ),
		'menu_name'             => _x( 'Team', 'Admin Menu text', 'ATLAS' ),
		'name_admin_bar'        => _x( 'Team', 'Add New on Toolbar', 'ATLAS' ),
		'add_new'               => __( 'Add New', 'ATLAS' ),
		'add_new_item'          => __( 'Add New team', 'ATLAS' ),
		'new_item'              => __( 'New team', 'ATLAS' ),
		'edit_item'             => __( 'Edit team', 'ATLAS' ),
		'view_item'             => __( 'View team', 'ATLAS' ),
		'all_items'             => __( 'All team', 'ATLAS' ),
		'search_items'          => __( 'Search team', 'ATLAS' ),
		'parent_item_colon'     => __( 'Parent team:', 'ATLAS' ),
		'not_found'             => __( 'No team found.', 'ATLAS' ),
		'not_found_in_trash'    => __( 'No team found in Trash.', 'ATLAS' ),
		'archives'              => _x( 'team archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'ATLAS' ),
		'insert_into_item'      => _x( 'Insert into team', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'ATLAS' ),
		'uploaded_to_this_item' => _x( 'Uploaded to this team', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'ATLAS' ),
		'filter_items_list'     => _x( 'Filter team list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'ATLAS' ),
		'items_list_navigation' => _x( 'team list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'ATLAS' ),
		'items_list'            => _x( 'team list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'ATLAS' ),
	);
	
	$args = array(
		'labels'             => $labels,
		'public'             => false,
		'publicly_queryable' => false,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'team' ),
		'capability_type'    => 'post',
		'menu_icon'          => 'dashicons-groups',
		'has_archive'        => false,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'           => array( 'title', 'editor', 'thumbnail' ),
	);
	
	register_post_type( 'team', $args );
}

function custom_register_team_cpt() {
	if ( ! post_type_exists( 'team' ) ) { 
		add_action( 'init', 'register_team_init' );
	}	
}