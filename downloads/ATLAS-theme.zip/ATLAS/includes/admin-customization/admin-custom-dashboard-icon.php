<?php
function wpb_custom_logo() {
    echo '
    <style type="text/css">
        #wpadminbar #wp-admin-bar-wp-logo > .ab-item {
            padding: 0;
        } 
        #wpadminbar > #wp-toolbar > #wp-admin-bar-root-default #wp-admin-bar-wp-logo .ab-icon, 
        #wpadminbar #wp-admin-bar-wp-logo .ab-icon {
            padding: 0;
            width: auto;
            height: auto;
            margin: 0;
        }
        #wpadminbar #wp-admin-bar-wp-logo > .ab-item .ab-icon:before {
            background-image: url(' . get_bloginfo('stylesheet_directory') . '/images/admin-logo.png) !important;
            background-position: 0 0;
            color:rgba(0, 0, 0, 0);
            background-size: cover;
            width: 32px;
            height: 32px;
            display: block;
            top: 0;
            left: 0;
        }
        #wpadminbar #wp-admin-bar-wp-logo.hover > .ab-item .ab-icon {
            background-position: 0 0;
        }
    </style>
    ';
}

//hook into the administrative header output
add_action('wp_before_admin_bar_render', 'wpb_custom_logo');