<?php
/**
 * Block settings: defaults, sanitising, locations, rule types and the cached
 * index of published blocks.
 *
 * @package AtlasContentBlocks
 */

defined( 'ABSPATH' ) || exit;

class Atlas_CB_Settings {

	/**
	 * Default settings of a content block.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'type'        => 'hook',
			'location'    => 'atlas_after_header',
			'custom_hook' => '',
			'priority'    => 10,
			'include'     => array( array( 'rule' => 'entire_site', 'value' => '' ) ),
			'exclude'     => array(),
			'user'        => 'all',
			'hide_on'     => array(),
			'start'       => '',
			'end'         => '',
			'popup'       => array(
				'trigger'       => 'click',
				'selector'      => '',
				'delay'         => 3,
				'scroll'        => 50,
				'frequency'     => 'always',
				'days'          => 7,
				'size'          => 'medium',
				'close_overlay' => 1,
				'label'         => '',
			),
		);
	}

	/**
	 * Theme locations a block can be placed at. Extend with the
	 * `atlas_cb_locations` filter (hook name => label).
	 *
	 * @return array
	 */
	public static function locations() {
		$locations = array(
			'wp_body_open'        => __( 'Right after <body>', 'atlas-content-blocks' ),
			'atlas_before_header' => __( 'Before header', 'atlas-content-blocks' ),
			'atlas_after_header'  => __( 'After header', 'atlas-content-blocks' ),
			'content_start'       => __( 'Start of post content', 'atlas-content-blocks' ),
			'content_end'         => __( 'End of post content', 'atlas-content-blocks' ),
			'atlas_before_footer' => __( 'Before footer', 'atlas-content-blocks' ),
			'atlas_after_footer'  => __( 'After footer', 'atlas-content-blocks' ),
		);

		$locations = (array) apply_filters( 'atlas_cb_locations', $locations );

		$locations['custom'] = __( 'Custom hook…', 'atlas-content-blocks' );
		$locations['manual'] = __( 'Nowhere automatically (block or shortcode only)', 'atlas-content-blocks' );

		return $locations;
	}

	/**
	 * Display rule choices, grouped for the admin select. Rules marked in
	 * value_rules() take an extra value.
	 *
	 * @return array Group label => [ rule => label ].
	 */
	public static function rule_choices() {
		$general = array(
			'entire_site' => __( 'Entire site', 'atlas-content-blocks' ),
			'front_page'  => __( 'Front page', 'atlas-content-blocks' ),
			'posts_page'  => __( 'Blog page (latest posts)', 'atlas-content-blocks' ),
			'search'      => __( 'Search results', 'atlas-content-blocks' ),
			'not_found'   => __( '404 page', 'atlas-content-blocks' ),
		);

		$singular = array( 'singular:any' => __( 'Any single post or page', 'atlas-content-blocks' ) );
		$archive  = array( 'archive:any' => __( 'Any archive', 'atlas-content-blocks' ) );

		foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $type ) {
			if ( ATLAS_CB_POST_TYPE === $type->name || 'attachment' === $type->name ) {
				continue;
			}
			/* translators: %s: post type name */
			$singular[ 'singular:' . $type->name ] = sprintf( __( 'Single: %s', 'atlas-content-blocks' ), $type->labels->singular_name );
			if ( $type->has_archive || 'post' === $type->name ) {
				/* translators: %s: post type name */
				$archive[ 'archive:' . $type->name ] = sprintf( __( 'Archive: %s', 'atlas-content-blocks' ), $type->labels->name );
			}
		}

		$specific = array(
			'post_ids'      => __( 'Specific posts or pages (IDs)', 'atlas-content-blocks' ),
			'child_of'      => __( 'Pages below a parent (ID)', 'atlas-content-blocks' ),
			'term'          => __( 'Category, tag or term (taxonomy:slug)', 'atlas-content-blocks' ),
			'page_template' => __( 'Page template (file name)', 'atlas-content-blocks' ),
		);

		return array(
			__( 'General', 'atlas-content-blocks' )  => $general,
			__( 'Singular', 'atlas-content-blocks' ) => $singular,
			__( 'Archives', 'atlas-content-blocks' ) => $archive,
			__( 'Specific', 'atlas-content-blocks' ) => $specific,
		);
	}

	/**
	 * Rules that need a value, with the placeholder shown in the admin.
	 *
	 * @return array
	 */
	public static function value_rules() {
		return array(
			'post_ids'      => __( 'e.g. 796, 1024', 'atlas-content-blocks' ),
			'child_of'      => __( 'e.g. 812', 'atlas-content-blocks' ),
			'term'          => __( 'e.g. category:news', 'atlas-content-blocks' ),
			'page_template' => __( 'e.g. default or templates/landing.php', 'atlas-content-blocks' ),
		);
	}

	/**
	 * Settings of one block, merged with the defaults.
	 *
	 * @param int $post_id Block ID.
	 *
	 * @return array
	 */
	public static function get( $post_id ) {
		$stored = get_post_meta( $post_id, ATLAS_CB_META, true );
		return self::merge( is_array( $stored ) ? $stored : array() );
	}

	/**
	 * Merge stored settings with the defaults, one level deep for popup settings.
	 *
	 * @param array $settings Stored settings.
	 *
	 * @return array
	 */
	public static function merge( array $settings ) {
		$defaults          = self::defaults();
		$merged            = array_merge( $defaults, $settings );
		$merged['popup']   = array_merge( $defaults['popup'], isset( $settings['popup'] ) && is_array( $settings['popup'] ) ? $settings['popup'] : array() );
		$merged['include'] = is_array( $merged['include'] ) ? $merged['include'] : array();
		$merged['exclude'] = is_array( $merged['exclude'] ) ? $merged['exclude'] : array();
		$merged['hide_on'] = is_array( $merged['hide_on'] ) ? $merged['hide_on'] : array();
		return $merged;
	}

	/**
	 * Sanitise raw settings from the meta box.
	 *
	 * @param array $raw Unslashed form input.
	 *
	 * @return array
	 */
	public static function sanitize( array $raw ) {
		$defaults = self::defaults();
		$clean    = array();

		$clean['type'] = in_array( $raw['type'] ?? '', array( 'hook', 'popup' ), true ) ? $raw['type'] : 'hook';

		$location          = sanitize_key( $raw['location'] ?? '' );
		$clean['location'] = array_key_exists( $location, self::locations() ) ? $location : $defaults['location'];

		// Hook names may contain characters sanitize_key() strips (slashes, dots).
		$clean['custom_hook'] = preg_replace( '/[^A-Za-z0-9_\-\/\.]/', '', (string) ( $raw['custom_hook'] ?? '' ) );
		$clean['priority']    = max( -1000, min( 1000, (int) ( $raw['priority'] ?? 10 ) ) );

		$clean['include'] = self::sanitize_rules( $raw['include'] ?? array() );
		$clean['exclude'] = self::sanitize_rules( $raw['exclude'] ?? array() );

		$clean['user'] = in_array( $raw['user'] ?? '', array( 'all', 'logged_in', 'logged_out' ), true ) ? $raw['user'] : 'all';

		$hide_on          = isset( $raw['hide_on'] ) && is_array( $raw['hide_on'] ) ? $raw['hide_on'] : array();
		$clean['hide_on'] = array_values( array_intersect( array( 'mobile', 'tablet', 'desktop' ), $hide_on ) );

		$clean['start'] = self::sanitize_datetime( $raw['start'] ?? '' );
		$clean['end']   = self::sanitize_datetime( $raw['end'] ?? '' );

		$popup          = isset( $raw['popup'] ) && is_array( $raw['popup'] ) ? $raw['popup'] : array();
		$clean['popup'] = array(
			'trigger'       => in_array( $popup['trigger'] ?? '', array( 'click', 'load', 'scroll', 'exit' ), true ) ? $popup['trigger'] : 'click',
			'selector'      => self::sanitize_selector( $popup['selector'] ?? '' ),
			'delay'         => max( 0, min( 600, (int) ( $popup['delay'] ?? 3 ) ) ),
			'scroll'        => max( 1, min( 100, (int) ( $popup['scroll'] ?? 50 ) ) ),
			'frequency'     => in_array( $popup['frequency'] ?? '', array( 'always', 'session', 'days' ), true ) ? $popup['frequency'] : 'always',
			'days'          => max( 1, min( 365, (int) ( $popup['days'] ?? 7 ) ) ),
			'size'          => in_array( $popup['size'] ?? '', array( 'small', 'medium', 'large', 'full' ), true ) ? $popup['size'] : 'medium',
			'close_overlay' => empty( $popup['close_overlay'] ) ? 0 : 1,
			'label'         => sanitize_text_field( $popup['label'] ?? '' ),
		);

		return $clean;
	}

	/**
	 * Sanitise a list of display rules, dropping unknown rules and empty values.
	 *
	 * @param mixed $rules Raw rows.
	 *
	 * @return array
	 */
	private static function sanitize_rules( $rules ) {
		if ( ! is_array( $rules ) ) {
			return array();
		}

		$allowed = array();
		foreach ( self::rule_choices() as $group ) {
			$allowed = array_merge( $allowed, array_keys( $group ) );
		}
		$needs_value = self::value_rules();

		$clean = array();
		foreach ( $rules as $row ) {
			$rule = is_array( $row ) ? (string) ( $row['rule'] ?? '' ) : '';

			// Keep rules for post types that are temporarily unregistered.
			$known = in_array( $rule, $allowed, true ) || preg_match( '/^(singular|archive):[a-z0-9_-]+$/', $rule );
			if ( ! $known ) {
				continue;
			}

			$value = isset( $needs_value[ $rule ] ) ? sanitize_text_field( $row['value'] ?? '' ) : '';
			if ( isset( $needs_value[ $rule ] ) && '' === $value ) {
				continue;
			}

			$clean[] = array( 'rule' => $rule, 'value' => $value );
		}

		return $clean;
	}

	/**
	 * Accept a datetime-local value (Y-m-d\TH:i) or nothing.
	 *
	 * @param string $value Raw value.
	 *
	 * @return string
	 */
	private static function sanitize_datetime( $value ) {
		$value = trim( (string) $value );
		return preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $value ) ? $value : '';
	}

	/**
	 * Keep a CSS selector list free of markup characters. It is only ever passed
	 * to querySelector / closest in the browser.
	 *
	 * @param string $value Raw selector.
	 *
	 * @return string
	 */
	private static function sanitize_selector( $value ) {
		$value = wp_strip_all_tags( (string) $value );
		return trim( str_replace( array( '<', '>', '{', '}', ';' ), '', $value ) );
	}

	/**
	 * Settings of all published blocks in the current language, cached until a
	 * block changes.
	 *
	 * @return array Block ID => settings.
	 */
	public static function index() {
		$language = (string) apply_filters( 'wpml_current_language', '' );
		$key      = 'atlas_cb_index_' . (int) get_option( 'atlas_cb_cache_version', 1 ) . '_' . sanitize_key( $language );

		$index = get_transient( $key );
		if ( is_array( $index ) ) {
			return $index;
		}

		$ids = get_posts(
			array(
				'post_type'        => ATLAS_CB_POST_TYPE,
				'post_status'      => 'publish',
				'numberposts'      => -1,
				'fields'           => 'ids',
				'orderby'          => 'menu_order title',
				'order'            => 'ASC',
				// Let WPML limit the list to the current language.
				'suppress_filters' => false,
			)
		);

		$index = array();
		foreach ( $ids as $id ) {
			$index[ (int) $id ] = self::get( $id );
		}

		set_transient( $key, $index, DAY_IN_SECONDS );

		return $index;
	}

	/**
	 * Invalidate the cached index for every language.
	 */
	public static function flush_index() {
		update_option( 'atlas_cb_cache_version', (int) get_option( 'atlas_cb_cache_version', 1 ) + 1, false );
	}
}
