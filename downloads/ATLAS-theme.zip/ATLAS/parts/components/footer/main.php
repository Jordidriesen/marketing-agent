<?php
$landing_footer = get_field('show_landing_footer');
$class = $landing_footer ? 'main-footer main-footer--landing' : 'main-footer';
?>
<footer class="<?php echo $class; ?>">
	<?php echo loadStyles(__DIR__, 'footer'); ?>
	<?php get_theme_part('components/footer/parts/top'); ?>
	<?php get_theme_part('components/footer/parts/bottom'); ?>
</footer>