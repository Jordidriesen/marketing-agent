<?php

/**
 * Add some custom classes for menu containing
 * additional columns to handle custom CSS
 * styles for them separately
 */

function additional_columns_class( $classes, $item, $args, $depth ) {
	$columns = get_field( 'menu_rows', $item );
	if ( empty( $columns ) ) {
		return $classes;
	}

	$classes[] = 'columns-count-' . count( $columns );
	$classes[] = 'menu-item-has-children';

	return $classes;
}

add_filter( 'nav_menu_css_class', 'additional_columns_class', 10, 4 );
