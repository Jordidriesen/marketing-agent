<?php
/**
 * Block with Pricing Columns
 *
 * @package WordPress
 * @subpackage ATLAS
 * @since ATLAS 1.0
 */
$block_object = new Block( $block );

loadAcfBlockPreviewImage(__DIR__);

$name = $block_object->block_name();

$member = get_field('team_single_member');

if (!empty($member)) :
    $id = $member->ID;
    $img = get_the_post_thumbnail($id, 'team-image');
    $title = get_the_title($id);
    $short_desc = get_field('team_description', $id);
    $tel = get_field('team_tel', $id);
	$mail = get_field('team_mail', $id);
	$custom_1 = get_field('team_custom_1', $id);
	$custom_2 = get_field('team_custom_2', $id);
?>
<section class="block-team-single">
    <?php loadStyles(__DIR__, $name); ?>
    <div class="block-team-single__container container">
        <div class="block-team-single__row row">
        <?php if ( !empty($img) ) : ?>
            <div class="block-team-single__img-col col col-12 col-lg-6">
                <figure class="block-team-single__img"><?php echo $img; ?></figure>
            </div>
        <?php endif; ?>
            <div class="block-team-single__content-col col col-12 col-lg-6">
                <div class="block-team-single__content">
                <?php if (!empty($title)) : ?>
                    <h2 class="block-team-single__title"><?php echo $title; ?></h2>
                <?php endif; ?>
                <?php if (!empty($short_desc)) : ?>
                    <span class="block-team-single__details block-team-single__details-short-desc"><?php echo $short_desc; ?></span>
                <?php endif; ?>
                <?php if (!empty($tel)) : ?>
                    <span class="block-team-single__details block-team-single__details-tel"><?php echo $tel; ?></span>
                <?php endif; ?>	
                <?php if (!empty($mail)) : ?>
                    <span class="block-team-single__details block-team-single__details-mail"><?php echo $mail; ?></span>
                <?php endif; ?>	
                <?php if (!empty($custom_1)) : ?>
                    <span class="block-team-single__details block-team-single__details-custom_1"><?php echo $custom_1; ?></span>
                <?php endif; ?>	
                <?php if (!empty($custom_2)) : ?>
                    <span class="block-team-single__details block-team-single__details-custom_2"><?php echo $custom_2; ?></span>
                <?php endif; ?>		
                <?php echo apply_filters('the_content', $member->post_content); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
endif;