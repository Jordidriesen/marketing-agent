<?php
if (!function_exists('auto_id_subheading')) {
    function auto_id_subheading( $content ) {
        $content = preg_replace_callback( '/(<([a-z][a-z0-9]*)[^>]*class="[^"]*is-style-subheading[^"]*"[^>]*)>(.*?)(<\/\2>)/i', function( $matches ) {
            if ( ! stripos( $matches[0], 'id=' ) ) :
                $text = html_entity_decode($matches[3], ENT_QUOTES, 'UTF-8');
                $text = str_replace(['ä', 'ö', 'ü', 'ß', '&'], ['ae', 'oe', 'ue', 'ss', 'and'], $text);
                $matches[0] = $matches[1] . ' id="' . sanitize_title_with_dashes( $text, '', 'save' ) . '">' . $matches[3] . $matches[4];
            endif;
            return $matches[0];
        }, $content );

        return $content;
    }
    add_filter( 'the_content', 'auto_id_subheading' );
}

if (!function_exists('generateIndexSubheading')) {
    function generateIndexSubheading($html) {
        preg_match_all('/<([a-z][a-z0-9]*)[^>]*class="[^"]*is-style-subheading[^"]*"[^>]*>(.*?)<\/\1>/i', $html, $matches);

        $index = "<ul class='block-subnav__list'>";
        $prev = 2;

        foreach ($matches[0] as $i => $match){

            $curr = 2; // Assuming a default level for simplicity
            $text = strip_tags($matches[2][$i]);
            $text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');
            $slugText = str_replace(['ä', 'ö', 'ü', 'ß', '&'], ['ae', 'oe', 'ue', 'ss', 'and'], $text);
            $slug = strtolower(str_replace("--","-",preg_replace('/[^\da-zäoeuess]/i', '-', $slugText)));
            $anchor = '<a name="'.$slug.'">'.$text.'</a>';
            $html = str_replace($text,$anchor,$html);
            
            $prev <= $curr ?: $index .= str_repeat('</ul>',($prev - $curr));
            $prev >= $curr ?: $index .= "<ul class='block-subnav__list'>";
            
            $index .= '<li><a href="#'.$slug.'">'.$text.'</a></li>';
            
            $prev = $curr;
        }

        $index .= str_repeat('</ul>', $prev - 1) . "</ul>";

        return ["html" => $html, "index" => $index];
    }
}