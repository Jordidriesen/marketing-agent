<?php
/**
 * Block with testimonial slider
 *
 * @package WordPress
 * @subpackage ATLAS
 * @since ATLAS 1.0
 */
$block_object = new Block( $block );

loadAcfBlockPreviewImage(__DIR__);

$testimonials = get_field('testimonial_slider_lps');

if ( $testimonials ) :
    $name = $block_object->block_name();
    $slider_class = 'block-testimonial__wrapper';
    $layout_counter = $block['id'];
    
    $show_dots = 1;
?>
<section class="block-testimonial testimonial-landingpage">
    <?php loadStyles(__DIR__, $name); ?>
    <?php loadStylesThird('splide'); ?>
    <div class="block-testimonial__container">

        <div class="<?php echo $slider_class; ?>" data-slider="<?php echo $layout_counter; ?>" data-dots="<?php echo $show_dots; ?>">
            <?php
            foreach ( $testimonials as $testimonial ) :
                $testimonial = apply_filters( 'wpml_object_id', $testimonial, 'testimonial', TRUE  );
                $content = get_post_field('post_content', $testimonial);
                $content = apply_filters('the_content', $content);
                $author_name = get_the_title($testimonial);
                $author_description = get_field('testimonial_position', $testimonial);
                $author_company = get_field('testimonial_company', $testimonial);
            ?>
                <div class="testimonial-slide">
                    <div class="testimonial-slide__wrapper">
                        <div class="testimonial-slide__wrapper-content">
                            <?php if ( !empty($content) ) : ?>
                                <div class="testimonial-slide__content">
                                    <div class="testimonial-slide__quote">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="60" height="46" viewBox="0 0 60 46" fill="none">
                                            <path d="M15.6872 -3.87395e-06C18.3506 -3.6411e-06 20.7331 0.803173 22.8345 2.40952C24.9114 4.01587 26.3042 6.09683 27.0128 8.65238C27.5015 10.4291 27.7459 12.3032 27.7459 14.2746C27.7459 17.2683 27.1594 20.2984 25.9866 23.3651C24.8137 26.4561 23.201 29.3645 21.1484 32.0905C19.0959 34.8164 16.7257 37.3598 14.0379 39.7206C11.3256 42.1058 8.41784 44.1989 5.3146 46L4.62786e-07 40.7063C5.5223 36.3011 9.2975 32.8936 11.3256 30.4841C13.3293 28.0746 14.3678 25.6772 14.4411 23.2921C11.46 22.9513 8.96763 21.6735 6.96396 19.4587C4.9603 17.2439 3.95846 14.6518 3.95846 11.6825C3.95847 8.4455 5.10691 5.68307 7.40379 3.39524C9.67624 1.13174 12.4374 -4.15806e-06 15.6872 -3.87395e-06ZM47.9414 -1.0542e-06C50.6048 -8.21358e-07 52.9872 0.803176 55.0886 2.40953C57.1656 4.01587 58.5583 6.09683 59.267 8.65238C59.7557 10.4291 60 12.3032 60 14.2746C60 17.2683 59.4136 20.2984 58.2407 23.3651C57.0678 26.4561 55.4551 29.3646 53.4026 32.0905C51.35 34.8164 48.9798 37.3598 46.292 39.7206C43.5797 42.1058 40.672 44.1989 37.5687 46L32.2541 40.7063C37.7764 36.3011 41.5516 32.8936 43.5797 30.4841C45.5834 28.0746 46.6219 25.6772 46.6952 23.2921C43.7141 22.9513 41.2217 21.6735 39.2181 19.4587C37.2144 17.2439 36.2126 14.6519 36.2126 11.6825C36.2126 8.4455 37.361 5.68307 39.6579 3.39524C41.9304 1.13175 44.6915 -1.33831e-06 47.9414 -1.0542e-06Z" fill="#E7312F"/>
                                        </svg>
                                    </div>
                                    <h3 class="h4"><?php echo $content; ?></h3>
                                </div>
                            <?php endif; ?>
                            <div class="testimonial-slide__meta">
                                <?php if ( !empty($author_name) || !empty($author_description) ) : ?>
                                    <div class="testimonial-slide__author-head">
                                    <?php if ( !empty($author_name) ) : ?>
                                        <span class="testimonial-slide__author-name"><?php echo $author_name; if ( !empty($author_description) ) :?>, <?php endif; ?></span>
                                    <?php endif; ?>
                                    <?php if ( !empty($author_description) ) : ?>
                                        <span class="testimonial-slide__author-description"><?php echo $author_description; ?></span>
                                    <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                <?php if ( !empty($author_company) ) : ?>
                                    <span class="testimonial-slide__author-company"><?php echo $author_company; ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                                    
                        <?php
                            $image = get_the_post_thumbnail($testimonial, 'large');
                            if ( !empty($image) ) :
                        ?>
                        <div class="testimonial-slide__image">
                            <?php echo $image; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php
            endforeach;
            ?>
        </div>
    </div>
</section>
<?php
endif;