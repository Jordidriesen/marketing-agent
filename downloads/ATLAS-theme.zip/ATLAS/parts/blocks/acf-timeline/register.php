<?php
function init_block_timeline() {
    if ( ! function_exists( 'acf_register_block' ) ) {
        return;
    }

    acf_register_block( array(
        'name'              => 'timeline',
        'title'             => __( 'Zeitstrahl / Timeline', 'ATLAS' ),
        'description'       => __( 'Timeline block', 'ATLAS' ),
        'category'          => 'custom_blocks',
        'icon'              => 'media-document',
        'mode'              => 'auto',
        'keywords'          => array( 'timeline', 'zeitstrahl', 'zeit', 'history', 'geschichte' ),
        'supports'          => array(
            'align' => false,
        ),
		'example'         => [
            'attributes' => [
                'mode' => 'preview',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-timeline/index.php',
        'enqueue_assets'  => function () {
			wp_enqueue_script(
				'ATLAS/acf-timeline',
                get_template_directory_uri() . '/parts/blocks/acf-timeline/index.min.js',
                [ 'splide_script' ],
                false,
                array(
                    'in_footer' => true,
                    'strategy'  => 'defer',
                )
			);
		}
    ));
}

add_action( 'acf/init', 'init_block_timeline' );