/**
 * Turns the Rank Math FAQ block into an accordion. Vanilla port of the former
 * inline jQuery script, with the same behaviour: answers start hidden, a click on a
 * question toggles its answer and closes all other answers on the page. Like the
 * jQuery version, rapid clicks queue up rather than interrupt each other.
 */
import { slideUpQueued, slideToggleQueued } from 'lib/slide';

// jQuery's 'fast' speed
const SPEED = 200;

const nextAnswer = (question) => {
	let el = question.nextElementSibling;
	while (el && !el.classList.contains('rank-math-answer')) {
		el = el.nextElementSibling;
	}
	return el;
};

const accordion = () => {
	document.querySelectorAll('.rank-math-block .rank-math-answer').forEach((answer) => {
		answer.style.display = 'none';
	});

	const questions = document.querySelectorAll('.rank-math-block .rank-math-question');

	questions.forEach((question) => {
		question.addEventListener('click', () => {
			const answer = nextAnswer(question);

			// Expand or collapse this panel
			if (answer) {
				slideToggleQueued(answer, SPEED, () => answer.classList.toggle('collapse'));
			}

			// Hide the other panels
			document.querySelectorAll('.rank-math-answer').forEach((other) => {
				if (other !== answer) {
					slideUpQueued(other, SPEED);
				}
			});

			questions.forEach((other) => {
				if (other !== question) {
					other.classList.remove('collapse');
				}
			});
			question.classList.toggle('collapse');
		});
	});
};

accordion();
