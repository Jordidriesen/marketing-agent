<?php
add_filter( 'render_block', 'wrap_columns_block', 10, 2 );
function wrap_columns_block( $block_content, $block ) {
	if ( 'core/columns' === $block['blockName'] ) {
		$block_content = '<div data-styles-id="core-columns"></div>' . $block_content;
	}
	return $block_content;
}
