<?php
if ( isset($id) ):
	$img = get_the_post_thumbnail($id,'news-image');
	$title = get_the_title($id);
	$date = get_the_date('d.m.Y', $id);
	$short_desc = get_the_excerpt($id);
	$link_url = get_permalink($id);
	$link_target = isset($link_target) ? $link_target : '_self';
?>
<a href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>" class="single-lab">
	<?php loadStyles(__DIR__, 'single-lab'); ?>
	<div class="single-lab__wrapper">
	<?php if (!empty($img)) : ?>
		<figure class="single-lab__img"><?php echo $img; ?></figure>
	<?php endif; ?>
		<div class="single-lab__content">
			<h3 class="single-lab__title h4" role="heading"><?php echo $title; ?></h3>
		</div>
	</div>
</a>
<?php
endif;