<?php
function init_block_case_teaser() {
    if ( ! function_exists( 'acf_register_block' ) ) {
        return;
    }

    acf_register_block( array(
        'name'              => 'case-teaser',
        'title'             => __( 'Vorschau / Teaser', 'ATLAS' ),
        'description'       => __( 'Customer Case Teaser block', 'ATLAS' ),
        'category'          => 'custom_blocks',
        'icon'              => 'media-document',
        'mode'              => 'auto',
        'keywords'          => array( 'case-teaser' ),
        'supports'          => array(
            'align' => false,
        ),
		'example'         => [
            'attributes' => [
                'mode' => 'preview',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-case-teaser/index.php',
    ));
}

add_action( 'acf/init', 'init_block_case_teaser' );