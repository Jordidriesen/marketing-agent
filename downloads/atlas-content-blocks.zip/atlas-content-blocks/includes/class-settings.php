<?php
/**
 * Block settings: defaults, sanitising, locations, condition rule types and
 * the cached index of published blocks.
 *
 * @package AtlasContentBlocks
 */

defined( 'ABSPATH' ) || exit;

class Atlas_CB_Settings {

	/** Locations that insert into the post content rather than run on an action. */
	const CONTENT_LOCATIONS = array( 'content_start', 'content_end', 'after_paragraph', 'before_heading' );

	/**
	 * Default settings of a content block.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'type'        => 'hook',
			// No location means the block is only placed by hand (block or shortcode).
			'locations'   => array( 'atlas_after_header' ),
			'custom_hook' => '',
			'priority'    => 10,
			'paragraph'   => 2,
			'heading'     => 1,
			'container'   => array(
				'structure'      => 'default',
				'width'          => 'boxed',
				'content'        => 'standard',
				'spacing_top'    => 'none',
				'spacing_bottom' => 'none',
			),
			'conditions'  => array(
				'mode'    => 'basic',
				'include' => array( array( 'rule' => 'entire_site' ) ),
				'exclude' => array(),
				'groups'  => array(),
			),
			'hide_on'     => array(),
			'popup'       => array(
				// Opening.
				'trigger'         => 'click',
				'selector'        => '',
				'delay'           => 3,
				'scroll'          => 400,
				'scroll_unit'     => 'px',
				'scroll_element'  => '',
				'inactivity'      => 30,
				'pages'           => 3,
				'relaunch'        => 'always',
				'relaunch_amount' => 7,
				'relaunch_unit'   => 'days',
				// Closing.
				'close_overlay'   => 1,
				'close_esc'       => 1,
				'close_submit'    => 0,
				'close_selector'  => '',
				'close_delay'     => 0,
				'close_scroll'    => 0,
				// Behaviour.
				'animation'       => 'fade',
				'on_demand'       => 0,
				'scroll_lock'     => 1,
				'focus_trap'      => 1,
				'stop_media'      => 1,
				'label'           => '',
				// Design.
				'size'            => 'medium',
				'width'           => '',
				'max_height'      => '',
				'position'        => 'center',
				'offset'          => 24,
				'shadow'          => 1,
				'padding'         => 0,
				'radius'          => 16,
				'overflow'        => 'scroll',
				'background'      => '',
				'close_position'  => 'inside',
				'close_color'     => '',
				'close_bg'        => '',
				'backdrop'        => 1,
				'backdrop_color'  => '#000000',
				'backdrop_alpha'  => 60,
				'backdrop_blur'   => 0,
			),
		);
	}

	/**
	 * Locations a hook block can be placed at. Extend the theme hooks with the
	 * `atlas_cb_locations` filter (hook name => label).
	 *
	 * @return array
	 */
	public static function locations() {
		$locations = array(
			'wp_body_open'        => __( 'Right after <body>', 'atlas-content-blocks' ),
			'atlas_before_header' => __( 'Before header', 'atlas-content-blocks' ),
			'atlas_after_header'  => __( 'After header', 'atlas-content-blocks' ),
			'atlas_before_footer' => __( 'Before footer', 'atlas-content-blocks' ),
			'atlas_after_footer'  => __( 'After footer', 'atlas-content-blocks' ),
		);

		$locations = (array) apply_filters( 'atlas_cb_locations', $locations );

		$locations['content_start']   = __( 'Start of post content', 'atlas-content-blocks' );
		$locations['after_paragraph'] = __( 'In the post content, after paragraph number', 'atlas-content-blocks' );
		$locations['before_heading']  = __( 'In the post content, before heading number', 'atlas-content-blocks' );
		$locations['content_end']     = __( 'End of post content', 'atlas-content-blocks' );
		$locations['custom']          = __( 'Custom hook', 'atlas-content-blocks' );

		return $locations;
	}

	/**
	 * Locations grouped for the location dropdowns, with shorter labels where
	 * the group already says where. Theme locations added with the
	 * `atlas_cb_locations` filter go in the "Other" group, before the custom hook.
	 *
	 * @return array Group label => [ location => label ].
	 */
	public static function location_groups() {
		$all    = self::locations();
		$short  = array(
			'content_start'   => __( 'Start of content', 'atlas-content-blocks' ),
			'content_end'     => __( 'End of content', 'atlas-content-blocks' ),
			'after_paragraph' => __( 'After paragraph number', 'atlas-content-blocks' ),
			'before_heading'  => __( 'Before heading number', 'atlas-content-blocks' ),
		);
		$layout = array(
			__( 'Page', 'atlas-content-blocks' )    => array( 'wp_body_open' ),
			__( 'Header', 'atlas-content-blocks' )  => array( 'atlas_before_header', 'atlas_after_header' ),
			__( 'Content', 'atlas-content-blocks' ) => array( 'content_start', 'content_end', 'after_paragraph', 'before_heading' ),
			__( 'Footer', 'atlas-content-blocks' )  => array( 'atlas_before_footer', 'atlas_after_footer' ),
		);

		$groups = array();
		$placed = array( 'custom' );
		foreach ( $layout as $group => $keys ) {
			foreach ( $keys as $key ) {
				if ( isset( $all[ $key ] ) ) {
					$groups[ $group ][ $key ] = $short[ $key ] ?? $all[ $key ];
					$placed[]                 = $key;
				}
			}
		}

		$other           = array_diff_key( $all, array_flip( $placed ) );
		$other['custom'] = $all['custom'];

		$groups[ __( 'Other', 'atlas-content-blocks' ) ] = $other;

		return $groups;
	}

	/**
	 * Every condition rule: label, admin group, the fields it uses and the
	 * category used to combine rules in basic mode.
	 *
	 * Fields: ids, taxonomy, terms, role, days, from, to, start, end, operator,
	 * value, name, language.
	 *
	 * @return array Rule => [ 'label', 'group', 'fields', 'category' ].
	 */
	public static function rule_types() {
		static $cache = null;
		if ( null !== $cache ) {
			return $cache;
		}

		$groups = array(
			'general'  => __( 'General', 'atlas-content-blocks' ),
			'posts'    => __( 'Posts and pages', 'atlas-content-blocks' ),
			'types'    => __( 'Post types', 'atlas-content-blocks' ),
			'specific' => __( 'Specific', 'atlas-content-blocks' ),
			'date'     => __( 'Date and time', 'atlas-content-blocks' ),
			'request'  => __( 'Requests', 'atlas-content-blocks' ),
			'visitor'  => __( 'Visitor', 'atlas-content-blocks' ),
			'language' => __( 'Languages', 'atlas-content-blocks' ),
		);

		$rule = function ( $label, $group, array $fields = array(), $category = 'page' ) use ( $groups ) {
			return array(
				'label'    => $label,
				'group'    => $groups[ $group ],
				'fields'   => $fields,
				'category' => $category,
			);
		};

		$types = array(
			'entire_site'      => $rule( __( 'Entire website', 'atlas-content-blocks' ), 'general' ),
			'singular:any'     => $rule( __( 'All singulars', 'atlas-content-blocks' ), 'general' ),
			'archive:any'      => $rule( __( 'All archives', 'atlas-content-blocks' ), 'general' ),
			'front_page'       => $rule( __( 'Front page', 'atlas-content-blocks' ), 'general' ),
			'posts_page'       => $rule( __( 'Blog (latest posts page)', 'atlas-content-blocks' ), 'general' ),
			'search'           => $rule( __( 'Search results', 'atlas-content-blocks' ), 'general' ),
			'not_found'        => $rule( __( '404 page', 'atlas-content-blocks' ), 'general' ),
			'privacy_page'     => $rule( __( 'Privacy policy page', 'atlas-content-blocks' ), 'general' ),
			'author_archive'   => $rule( __( 'Author archives (optional author IDs)', 'atlas-content-blocks' ), 'general', array( 'ids' ) ),
			'archive:post'     => $rule( __( 'Post archives', 'atlas-content-blocks' ), 'posts' ),
			'category_archive' => $rule( __( 'Post category archives', 'atlas-content-blocks' ), 'posts' ),
			'tag_archive'      => $rule( __( 'Post tag archives', 'atlas-content-blocks' ), 'posts' ),
			'singular:post'    => $rule( __( 'Single post', 'atlas-content-blocks' ), 'posts' ),
			'singular:page'    => $rule( __( 'Single page', 'atlas-content-blocks' ), 'posts' ),
		);

		foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $type ) {
			if ( in_array( $type->name, array( ATLAS_CB_POST_TYPE, 'attachment', 'post', 'page' ), true ) ) {
				continue;
			}
			/* translators: %s: post type name */
			$types[ 'singular:' . $type->name ] = $rule( sprintf( __( 'Single: %s', 'atlas-content-blocks' ), $type->labels->singular_name ), 'types' );
			if ( $type->has_archive ) {
				/* translators: %s: post type name */
				$types[ 'archive:' . $type->name ] = $rule( sprintf( __( 'Archive: %s', 'atlas-content-blocks' ), $type->labels->name ), 'types' );
			}
		}

		$types += array(
			'post_ids'      => $rule( __( 'Specific posts, pages or items (IDs)', 'atlas-content-blocks' ), 'specific', array( 'ids' ) ),
			'child_of'      => $rule( __( 'Pages below a parent (IDs)', 'atlas-content-blocks' ), 'specific', array( 'ids' ) ),
			'post_term'     => $rule( __( 'Posts with a taxonomy term', 'atlas-content-blocks' ), 'specific', array( 'taxonomy', 'terms' ) ),
			'post_author'   => $rule( __( 'Posts by author (user IDs)', 'atlas-content-blocks' ), 'specific', array( 'ids' ) ),
			'term_archive'  => $rule( __( 'Taxonomy term archive', 'atlas-content-blocks' ), 'specific', array( 'taxonomy', 'terms' ) ),
			'page_template' => $rule( __( 'Page template (file name)', 'atlas-content-blocks' ), 'specific', array( 'value' ) ),
			'date_range'    => $rule( __( 'Date range', 'atlas-content-blocks' ), 'date', array( 'start', 'end' ), 'date' ),
			'recurring'     => $rule( __( 'Recurring days and times', 'atlas-content-blocks' ), 'date', array( 'days', 'from', 'to' ), 'date' ),
			'url'           => $rule( __( 'Page URL', 'atlas-content-blocks' ), 'request', array( 'operator', 'value' ), 'request' ),
			'referer'       => $rule( __( 'Referrer', 'atlas-content-blocks' ), 'request', array( 'operator', 'value' ), 'request' ),
			'cookie'        => $rule( __( 'Cookie', 'atlas-content-blocks' ), 'request', array( 'name', 'operator', 'value' ), 'request' ),
			'logged_in'     => $rule( __( 'Logged in', 'atlas-content-blocks' ), 'visitor', array(), 'visitor' ),
			'logged_out'    => $rule( __( 'Logged out', 'atlas-content-blocks' ), 'visitor', array(), 'visitor' ),
			'user_role'     => $rule( __( 'User role', 'atlas-content-blocks' ), 'visitor', array( 'role' ), 'visitor' ),
		);

		// Only offered with WPML, but stored rules still evaluate safely without it.
		$types['language'] = $rule( __( 'Language', 'atlas-content-blocks' ), 'language', array( 'language' ), 'language' );

		// Post types are only complete once init has finished.
		if ( did_action( 'wp_loaded' ) ) {
			$cache = $types;
		}

		return $types;
	}

	/**
	 * Rules shown in the admin select (the language rule needs WPML).
	 *
	 * @return array Group label => [ rule => label ].
	 */
	public static function rule_choices() {
		$choices = array();
		foreach ( self::rule_types() as $key => $type ) {
			if ( 'language' === $key && ! self::wpml_active() ) {
				continue;
			}
			$choices[ $type['group'] ][ $key ] = $type['label'];
		}
		return $choices;
	}

	/**
	 * @return bool
	 */
	public static function wpml_active() {
		return defined( 'ICL_SITEPRESS_VERSION' ) || has_filter( 'wpml_active_languages' );
	}

	/**
	 * Operators for the URL, referrer and cookie rules.
	 *
	 * @return array
	 */
	public static function operators() {
		return array(
			'contains' => __( 'contains', 'atlas-content-blocks' ),
			'equals'   => __( 'is exactly', 'atlas-content-blocks' ),
			'starts'   => __( 'starts with', 'atlas-content-blocks' ),
		);
	}

	/**
	 * Settings of one block, merged with the defaults.
	 *
	 * @param int $post_id Block ID.
	 *
	 * @return array
	 */
	public static function get( $post_id ) {
		$stored = get_post_meta( $post_id, ATLAS_CB_META, true );
		return self::merge( is_array( $stored ) ? $stored : array() );
	}

	/**
	 * Merge stored settings with the defaults. Settings saved by version 1.0
	 * (one location, global user and schedule fields, old popup triggers) are
	 * converted on the fly.
	 *
	 * @param array $settings Stored settings.
	 *
	 * @return array
	 */
	public static function merge( array $settings ) {
		$settings = self::upgrade( $settings );
		$defaults = self::defaults();
		$merged   = array_merge( $defaults, $settings );

		foreach ( array( 'container', 'conditions', 'popup' ) as $key ) {
			$merged[ $key ] = array_merge( $defaults[ $key ], isset( $settings[ $key ] ) && is_array( $settings[ $key ] ) ? $settings[ $key ] : array() );
		}

		foreach ( array( 'include', 'exclude', 'groups' ) as $key ) {
			$merged['conditions'][ $key ] = is_array( $merged['conditions'][ $key ] ) ? $merged['conditions'][ $key ] : array();
		}

		$merged['locations'] = is_array( $merged['locations'] ) ? $merged['locations'] : array();
		$merged['hide_on']   = is_array( $merged['hide_on'] ) ? $merged['hide_on'] : array();

		return $merged;
	}

	/**
	 * Convert settings saved in the 1.0 format.
	 *
	 * @param array $s Stored settings.
	 *
	 * @return array
	 */
	private static function upgrade( array $s ) {
		if ( isset( $s['location'] ) && ! isset( $s['locations'] ) ) {
			$s['locations'] = 'manual' === $s['location'] ? array() : array( (string) $s['location'] );
		}
		unset( $s['location'] );

		if ( ! isset( $s['conditions'] ) && ( isset( $s['include'] ) || isset( $s['user'] ) || isset( $s['start'] ) ) ) {
			$include = array();
			foreach ( (array) ( $s['include'] ?? array() ) as $row ) {
				$include[] = self::upgrade_rule( $row );
			}
			$exclude = array();
			foreach ( (array) ( $s['exclude'] ?? array() ) as $row ) {
				$exclude[] = self::upgrade_rule( $row );
			}
			if ( in_array( $s['user'] ?? '', array( 'logged_in', 'logged_out' ), true ) ) {
				$include[] = array( 'rule' => $s['user'] );
			}
			if ( ! empty( $s['start'] ) || ! empty( $s['end'] ) ) {
				$include[] = array(
					'rule'  => 'date_range',
					'start' => (string) ( $s['start'] ?? '' ),
					'end'   => (string) ( $s['end'] ?? '' ),
				);
			}
			$s['conditions'] = array(
				'mode'    => 'basic',
				'include' => $include,
				'exclude' => $exclude,
				'groups'  => array(),
			);
		}
		unset( $s['include'], $s['exclude'], $s['user'], $s['start'], $s['end'] );

		if ( isset( $s['popup'] ) && is_array( $s['popup'] ) && isset( $s['popup']['frequency'] ) && ! isset( $s['popup']['relaunch'] ) ) {
			$p = $s['popup'];
			if ( 'load' === ( $p['trigger'] ?? '' ) && ! empty( $p['delay'] ) ) {
				$p['trigger'] = 'delay';
			} elseif ( 'scroll' === ( $p['trigger'] ?? '' ) ) {
				$p['trigger']     = 'scroll_down';
				$p['scroll_unit'] = '%';
			}
			$p['relaunch'] = 'days' === $p['frequency'] ? 'interval' : $p['frequency'];
			if ( 'days' === $p['frequency'] ) {
				$p['relaunch_amount'] = (int) ( $p['days'] ?? 7 );
				$p['relaunch_unit']   = 'days';
			}
			unset( $p['frequency'], $p['days'] );
			$s['popup'] = $p;
		}

		return $s;
	}

	/**
	 * @param mixed $row 1.0 rule row.
	 *
	 * @return array
	 */
	private static function upgrade_rule( $row ) {
		$rule  = is_array( $row ) ? (string) ( $row['rule'] ?? '' ) : '';
		$value = is_array( $row ) ? (string) ( $row['value'] ?? '' ) : '';

		if ( 'term' === $rule && false !== strpos( $value, ':' ) ) {
			list( $taxonomy, $slug ) = explode( ':', $value, 2 );
			return array(
				'rule'     => 'post_term',
				'taxonomy' => $taxonomy,
				'terms'    => $slug,
			);
		}
		if ( in_array( $rule, array( 'post_ids', 'child_of' ), true ) ) {
			return array(
				'rule' => $rule,
				'ids'  => $value,
			);
		}
		if ( 'page_template' === $rule ) {
			return array(
				'rule'  => $rule,
				'value' => $value,
			);
		}
		return array( 'rule' => $rule );
	}

	/**
	 * Sanitise raw settings from the meta box (or from code). Missing keys take
	 * their default, so a partial array is safe.
	 *
	 * @param array $raw Unslashed input.
	 *
	 * @return array
	 */
	public static function sanitize( array $raw ) {
		$defaults = self::defaults();
		$clean    = array();

		$clean['type'] = in_array( $raw['type'] ?? '', array( 'hook', 'popup' ), true ) ? $raw['type'] : 'hook';

		$locations          = isset( $raw['locations'] ) && is_array( $raw['locations'] ) ? array_map( 'sanitize_key', $raw['locations'] ) : array();
		$clean['locations'] = array_values( array_unique( array_intersect( $locations, array_keys( self::locations() ) ) ) );
		// "Placed by hand only" in the meta box: no automatic locations.
		if ( 'manual' === ( $raw['placement'] ?? '' ) ) {
			$clean['locations'] = array();
		}

		// Hook names may contain characters sanitize_key() strips (slashes, dots).
		$clean['custom_hook'] = preg_replace( '/[^A-Za-z0-9_\-\/\.]/', '', (string) ( $raw['custom_hook'] ?? '' ) );
		if ( '' === $clean['custom_hook'] ) {
			$clean['locations'] = array_values( array_diff( $clean['locations'], array( 'custom' ) ) );
		}
		$clean['priority']  = self::int( $raw['priority'] ?? 10, -1000, 1000 );
		$clean['paragraph'] = self::int( $raw['paragraph'] ?? 2, 1, 100 );
		$clean['heading']   = self::int( $raw['heading'] ?? 1, 1, 100 );

		$container          = isset( $raw['container'] ) && is_array( $raw['container'] ) ? $raw['container'] : array();
		$spacings           = array( 'none', 'small', 'medium', 'large' );
		$clean['container'] = array(
			'structure'      => self::choice( $container['structure'] ?? '', array( 'default', 'none', 'custom' ), 'default' ),
			'width'          => self::choice( $container['width'] ?? '', array( 'boxed', 'wide' ), 'boxed' ),
			'content'        => self::choice( $container['content'] ?? '', array( 'standard', 'narrow' ), 'standard' ),
			'spacing_top'    => self::choice( $container['spacing_top'] ?? '', $spacings, 'none' ),
			'spacing_bottom' => self::choice( $container['spacing_bottom'] ?? '', $spacings, 'none' ),
		);

		$conditions          = isset( $raw['conditions'] ) && is_array( $raw['conditions'] ) ? $raw['conditions'] : array();
		$clean['conditions'] = array(
			'mode'    => self::choice( $conditions['mode'] ?? '', array( 'basic', 'advanced' ), 'basic' ),
			'include' => self::sanitize_rules( $conditions['include'] ?? array(), false ),
			'exclude' => self::sanitize_rules( $conditions['exclude'] ?? array(), false ),
			'groups'  => array(),
		);
		foreach ( (array) ( $conditions['groups'] ?? array() ) as $group ) {
			$rules = self::sanitize_rules( is_array( $group ) ? ( $group['rules'] ?? array() ) : array(), true );
			if ( $rules ) {
				$clean['conditions']['groups'][] = array( 'rules' => $rules );
			}
		}

		$hide_on          = isset( $raw['hide_on'] ) && is_array( $raw['hide_on'] ) ? $raw['hide_on'] : array();
		$clean['hide_on'] = array_values( array_intersect( array( 'mobile', 'tablet', 'desktop' ), $hide_on ) );

		$clean['popup'] = self::sanitize_popup( isset( $raw['popup'] ) && is_array( $raw['popup'] ) ? $raw['popup'] : array(), $defaults['popup'] );

		return $clean;
	}

	/**
	 * @param array $p Raw popup settings.
	 * @param array $d Popup defaults.
	 *
	 * @return array
	 */
	private static function sanitize_popup( array $p, array $d ) {
		$flag = function ( $key ) use ( $p, $d ) {
			return array_key_exists( $key, $p ) ? ( empty( $p[ $key ] ) ? 0 : 1 ) : $d[ $key ];
		};

		$triggers = array( 'click', 'load', 'delay', 'scroll_down', 'scroll_up', 'scroll_element', 'inactivity', 'pages', 'exit' );

		return array(
			'trigger'         => self::choice( $p['trigger'] ?? '', $triggers, $d['trigger'] ),
			'selector'        => self::sanitize_selector( $p['selector'] ?? '' ),
			'delay'           => self::int( $p['delay'] ?? $d['delay'], 0, 3600 ),
			'scroll'          => self::int( $p['scroll'] ?? $d['scroll'], 0, 100000 ),
			'scroll_unit'     => self::choice( $p['scroll_unit'] ?? '', array( 'px', '%' ), $d['scroll_unit'] ),
			'scroll_element'  => self::sanitize_selector( $p['scroll_element'] ?? '' ),
			'inactivity'      => self::int( $p['inactivity'] ?? $d['inactivity'], 1, 3600 ),
			'pages'           => self::int( $p['pages'] ?? $d['pages'], 1, 1000 ),
			'relaunch'        => self::choice( $p['relaunch'] ?? '', array( 'always', 'session', 'interval' ), $d['relaunch'] ),
			'relaunch_amount' => self::int( $p['relaunch_amount'] ?? $d['relaunch_amount'], 1, 1000 ),
			'relaunch_unit'   => self::choice( $p['relaunch_unit'] ?? '', array( 'minutes', 'hours', 'days' ), $d['relaunch_unit'] ),
			'close_overlay'   => $flag( 'close_overlay' ),
			'close_esc'       => $flag( 'close_esc' ),
			'close_submit'    => $flag( 'close_submit' ),
			'close_selector'  => self::sanitize_selector( $p['close_selector'] ?? '' ),
			'close_delay'     => self::int( $p['close_delay'] ?? $d['close_delay'], 0, 600 ),
			'close_scroll'    => $flag( 'close_scroll' ),
			'animation'       => self::choice( $p['animation'] ?? '', array( 'none', 'fade', 'zoom', 'slide-top', 'slide-bottom', 'slide-left', 'slide-right' ), $d['animation'] ),
			'on_demand'       => $flag( 'on_demand' ),
			'scroll_lock'     => $flag( 'scroll_lock' ),
			'focus_trap'      => $flag( 'focus_trap' ),
			'stop_media'      => $flag( 'stop_media' ),
			'label'           => sanitize_text_field( $p['label'] ?? '' ),
			'size'            => self::choice( $p['size'] ?? '', array( 'small', 'medium', 'large', 'full', 'custom' ), $d['size'] ),
			'width'           => self::sanitize_length( $p['width'] ?? '', array( 'px', 'rem', 'em', '%', 'vw' ) ),
			'max_height'      => self::sanitize_length( $p['max_height'] ?? '', array( 'px', 'rem', 'em', '%', 'vh', 'dvh' ) ),
			'position'        => self::choice( $p['position'] ?? '', array( 'top-left', 'top', 'top-right', 'left', 'center', 'right', 'bottom-left', 'bottom', 'bottom-right' ), $d['position'] ),
			'offset'          => self::int( $p['offset'] ?? $d['offset'], 0, 500 ),
			'shadow'          => $flag( 'shadow' ),
			'padding'         => self::int( $p['padding'] ?? $d['padding'], 0, 200 ),
			'radius'          => self::int( $p['radius'] ?? $d['radius'], 0, 200 ),
			'overflow'        => self::choice( $p['overflow'] ?? '', array( 'clip', 'scroll', 'visible' ), $d['overflow'] ),
			'background'      => (string) sanitize_hex_color( $p['background'] ?? '' ),
			'close_position'  => self::choice( $p['close_position'] ?? '', array( 'inside', 'outside' ), $d['close_position'] ),
			'close_color'     => (string) sanitize_hex_color( $p['close_color'] ?? '' ),
			'close_bg'        => (string) sanitize_hex_color( $p['close_bg'] ?? '' ),
			'backdrop'        => $flag( 'backdrop' ),
			'backdrop_color'  => (string) ( sanitize_hex_color( $p['backdrop_color'] ?? '' ) ?: $d['backdrop_color'] ),
			'backdrop_alpha'  => self::int( $p['backdrop_alpha'] ?? $d['backdrop_alpha'], 0, 100 ),
			'backdrop_blur'   => self::int( $p['backdrop_blur'] ?? $d['backdrop_blur'], 0, 50 ),
		);
	}

	/**
	 * Sanitise a list of condition rules, dropping unknown rules and rules that
	 * miss a required value. Each rule keeps only the fields it uses.
	 *
	 * @param mixed $rules    Raw rows.
	 * @param bool  $negation Whether rows may carry a "not" flag (advanced mode).
	 *
	 * @return array
	 */
	public static function sanitize_rules( $rules, $negation ) {
		if ( ! is_array( $rules ) ) {
			return array();
		}

		$types = self::rule_types();
		$clean = array();

		foreach ( $rules as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$rule = (string) ( $row['rule'] ?? '' );

			if ( isset( $types[ $rule ] ) ) {
				$fields = $types[ $rule ]['fields'];
			} elseif ( preg_match( '/^(singular|archive):[a-z0-9_-]+$/', $rule ) ) {
				// Keep rules for post types that are temporarily unregistered.
				$fields = array();
			} else {
				continue;
			}

			$out = array( 'rule' => $rule );
			foreach ( $fields as $field ) {
				$out[ $field ] = self::sanitize_field( $field, $row[ $field ] ?? '' );
			}

			if ( ! self::rule_complete( $rule, $out ) ) {
				continue;
			}

			if ( $negation && ! empty( $row['not'] ) ) {
				$out['not'] = 1;
			}

			$clean[] = $out;
		}

		return $clean;
	}

	/**
	 * @param string $field Field name.
	 * @param mixed  $value Raw value.
	 *
	 * @return mixed
	 */
	private static function sanitize_field( $field, $value ) {
		switch ( $field ) {
			case 'ids':
				return implode( ',', array_filter( wp_parse_id_list( is_array( $value ) ? implode( ',', $value ) : (string) $value ) ) );

			case 'taxonomy':
				$value = sanitize_key( (string) $value );
				return taxonomy_exists( $value ) ? $value : '';

			case 'terms':
				$terms = array_filter( array_map( 'sanitize_title', array_map( 'trim', explode( ',', (string) $value ) ) ), 'strlen' );
				return implode( ',', $terms );

			case 'role':
				$value = sanitize_key( (string) $value );
				return array_key_exists( $value, wp_roles()->get_names() ) ? $value : '';

			case 'days':
				$days = is_array( $value ) ? array_map( 'intval', $value ) : array();
				return array_values( array_unique( array_intersect( array( 1, 2, 3, 4, 5, 6, 7 ), $days ) ) );

			case 'from':
			case 'to':
				$value = trim( (string) $value );
				return preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $value ) ? $value : '';

			case 'start':
			case 'end':
				return self::sanitize_datetime( $value );

			case 'operator':
				return array_key_exists( (string) $value, self::operators() ) ? (string) $value : 'contains';

			case 'name':
				// Cookie names: RFC 6265 token characters.
				return preg_replace( '/[^A-Za-z0-9!#$%&\'*+\-.^_`|~]/', '', (string) $value );

			case 'language':
				return preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $value );

			case 'value':
			default:
				return sanitize_text_field( (string) $value );
		}
	}

	/**
	 * Whether a sanitised rule has the values it needs.
	 *
	 * @param string $rule Rule.
	 * @param array  $row  Sanitised row.
	 *
	 * @return bool
	 */
	private static function rule_complete( $rule, array $row ) {
		switch ( $rule ) {
			case 'post_ids':
			case 'child_of':
			case 'post_author':
				return '' !== $row['ids'];
			case 'post_term':
				return '' !== $row['taxonomy'] && '' !== $row['terms'];
			case 'term_archive':
				return '' !== $row['taxonomy'];
			case 'page_template':
			case 'url':
			case 'referer':
				return '' !== $row['value'];
			case 'cookie':
				return '' !== $row['name'];
			case 'user_role':
				return '' !== $row['role'];
			case 'recurring':
				return ! empty( $row['days'] );
			case 'date_range':
				return '' !== $row['start'] || '' !== $row['end'];
			case 'language':
				return '' !== $row['language'];
		}
		return true;
	}

	/**
	 * @param mixed $value Raw value.
	 * @param int   $min   Minimum.
	 * @param int   $max   Maximum.
	 *
	 * @return int
	 */
	private static function int( $value, $min, $max ) {
		return max( $min, min( $max, (int) $value ) );
	}

	/**
	 * @param mixed  $value   Raw value.
	 * @param array  $allowed Allowed values.
	 * @param string $default Fallback.
	 *
	 * @return string
	 */
	private static function choice( $value, array $allowed, $default ) {
		return in_array( (string) $value, $allowed, true ) ? (string) $value : $default;
	}

	/**
	 * A CSS length such as 720px or 80vh, or nothing.
	 *
	 * @param mixed $value Raw value.
	 * @param array $units Allowed units.
	 *
	 * @return string
	 */
	private static function sanitize_length( $value, array $units ) {
		$value = strtolower( trim( (string) $value ) );
		if ( preg_match( '/^\d{1,4}$/', $value ) ) {
			return $value . 'px';
		}
		$pattern = '/^\d{1,4}(\.\d{1,2})?(' . implode( '|', array_map( 'preg_quote', $units ) ) . ')$/';
		return preg_match( $pattern, $value ) ? $value : '';
	}

	/**
	 * Accept a datetime-local value (Y-m-d\TH:i) or nothing.
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return string
	 */
	private static function sanitize_datetime( $value ) {
		$value = substr( trim( (string) $value ), 0, 16 );
		return preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $value ) ? $value : '';
	}

	/**
	 * Keep a CSS selector list free of markup characters. It is only ever passed
	 * to querySelector / closest in the browser.
	 *
	 * @param string $value Raw selector.
	 *
	 * @return string
	 */
	private static function sanitize_selector( $value ) {
		$value = wp_strip_all_tags( (string) $value );
		return trim( str_replace( array( '<', '>', '{', '}', ';' ), '', $value ) );
	}

	/**
	 * Settings of all published blocks in the current language, cached until a
	 * block changes.
	 *
	 * @return array Block ID => settings.
	 */
	public static function index() {
		$language = (string) apply_filters( 'wpml_current_language', '' );
		$key      = 'atlas_cb_index_' . (int) get_option( 'atlas_cb_cache_version', 1 ) . '_' . sanitize_key( $language );

		$index = get_transient( $key );
		if ( is_array( $index ) ) {
			return $index;
		}

		$ids = get_posts(
			array(
				'post_type'        => ATLAS_CB_POST_TYPE,
				'post_status'      => 'publish',
				'numberposts'      => -1,
				'fields'           => 'ids',
				'orderby'          => 'menu_order title',
				'order'            => 'ASC',
				// Let WPML limit the list to the current language.
				'suppress_filters' => false,
			)
		);

		$index = array();
		foreach ( $ids as $id ) {
			$index[ (int) $id ] = self::get( $id );
		}

		set_transient( $key, $index, DAY_IN_SECONDS );

		return $index;
	}

	/**
	 * Invalidate the cached index for every language.
	 */
	public static function flush_index() {
		update_option( 'atlas_cb_cache_version', (int) get_option( 'atlas_cb_cache_version', 1 ) + 1, false );
	}
}
