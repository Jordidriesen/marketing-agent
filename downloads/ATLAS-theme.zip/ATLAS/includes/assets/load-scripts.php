<?php
/**
 * Load Theme Global Scripts
 */
function load_theme_scripts() {
	wp_enqueue_script(
		'script',
		get_template_directory_uri() . '/js/bundle.min.js',
		[],
		false,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
}
add_action( 'wp_enqueue_scripts', 'load_theme_scripts');

/**
 * Register third part scripts
 * Later load as dependencies
 */
// Example, insert when register block scripts
// wp_enqueue_script(
// 	'acf-gallery',
// 	get_template_directory_uri() . ( is_IE() ? '/parts/blocks/acf-gallery/index.ie.js' : '/parts/blocks/acf-gallery/index.min.js' ),
// 	[ 'splide_script' ],
// 	false,
// 	true
// );

function load_scripts_block_assets() {
	wp_register_script(
		'splide_script',
		get_template_directory_uri() . '/js/lib/splide/index.min.js',
		[],
		'4.1.4',
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
}
add_action( 'enqueue_block_assets', 'load_scripts_block_assets' );