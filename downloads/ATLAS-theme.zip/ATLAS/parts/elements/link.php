<?php 
$link = isset( $link ) ? $link : null;
$class = isset( $class ) ? $class : null;

if ( !empty( $link ) ): 
    $link_url = $link['url'];
    $link_title = $link['title'];
    $link_target = $link['target'] ? $link['target'] : '_self';
    ?>
    <a <?php if ( !empty( $class ) ) { echo 'class= " ' . $class . '"'; } ?> href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
<?php endif;
