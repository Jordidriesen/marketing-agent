<?php
function init_block_pricing() {
    if ( ! function_exists( 'acf_register_block' ) ) {
        return;
    }

    acf_register_block( array(
        'name'              => 'pricing',
        'title'             => __( 'Preise / Pricing', 'ATLAS' ),
        'description'       => __( 'Pricing', 'ATLAS' ),
        'category'          => 'custom_blocks',
        'icon'              => '<svg version="1.1" width="96px" height="96px" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 96 96" style="enable-background:new 0 0 96 96;" xml:space="preserve"><path id="XMLID_11_" fill="#333333" class="st0" d="M40.7,67h14.6V29H40.7V67z M23.2,67h14.6V29H23.2V67z M58.2,29V67h14.6V29H58.2z"/></svg>',
        'mode'              => 'auto',
        'keywords'          => array( 'columns', 'pricing' ),
        'align'             => 'full',
        'supports'          => array(
			'align' => false,
        ),
		'example'         => [
            'attributes' => [
                'mode' => 'auto',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-pricing/index.php',
        'enqueue_assets'  => function () {
			wp_enqueue_script(
				'ATLAS/acf-pricing',
                get_template_directory_uri() . ( is_IE() ? '/parts/blocks/acf-pricing/index.ie.js#asyncload' : '/parts/blocks/acf-pricing/index.min.js#asyncload' ),
                [],
                false,
                true
			);
		}
    ));
}

add_action( 'acf/init', 'init_block_pricing' );