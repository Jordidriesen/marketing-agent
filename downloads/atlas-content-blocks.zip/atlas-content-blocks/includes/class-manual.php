<?php
/**
 * Manual placement: the [atlas_content_block id="123"] shortcode and the
 * "Content Block" editor block.
 *
 * A hook block placed by hand renders where it is placed. A popup placed by
 * hand renders nothing in place; it is printed on the page so its triggers
 * work there, whatever its own display conditions.
 *
 * @package AtlasContentBlocks
 */

defined( 'ABSPATH' ) || exit;

class Atlas_CB_Manual {

	public static function init() {
		add_shortcode( 'atlas_content_block', array( __CLASS__, 'shortcode' ) );
		add_action( 'init', array( __CLASS__, 'register_block' ) );
	}

	/**
	 * @param array $atts Shortcode attributes.
	 *
	 * @return string
	 */
	public static function shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'id'         => 0,
				'conditions' => 'no',
			),
			$atts,
			'atlas_content_block'
		);

		return self::output( (int) $atts['id'], 'yes' === $atts['conditions'] );
	}

	public static function register_block() {
		wp_register_script(
			'atlas-cb-block-editor',
			ATLAS_CB_URL . 'assets/js/block-editor.js',
			array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-data', 'wp-i18n', 'wp-server-side-render' ),
			ATLAS_CB_VERSION,
			true
		);
		wp_set_script_translations( 'atlas-cb-block-editor', 'atlas-content-blocks' );

		register_block_type(
			'atlas/content-block',
			array(
				'api_version'     => 3,
				'title'           => __( 'Content Block', 'atlas-content-blocks' ),
				'category'        => 'widgets',
				'icon'            => 'screenoptions',
				'editor_script'   => 'atlas-cb-block-editor',
				'attributes'      => array(
					'id'         => array(
						'type'    => 'number',
						'default' => 0,
					),
					'conditions' => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
				'supports'        => array( 'html' => false ),
				'render_callback' => array( __CLASS__, 'render_block' ),
			)
		);
	}

	/**
	 * @param array $attributes Block attributes.
	 *
	 * @return string
	 */
	public static function render_block( $attributes ) {
		$id = isset( $attributes['id'] ) ? (int) $attributes['id'] : 0;

		// In the editor preview, show a popup's content instead of nothing.
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return self::editor_preview( $id );
		}

		return self::output( $id, ! empty( $attributes['conditions'] ) );
	}

	/**
	 * @param int  $id         Block ID.
	 * @param bool $conditions Respect the block's display conditions.
	 *
	 * @return string
	 */
	private static function output( $id, $conditions ) {
		$id = self::translated_id( $id );

		if ( ! $id || 'publish' !== get_post_status( $id ) || ATLAS_CB_POST_TYPE !== get_post_type( $id ) ) {
			return '';
		}

		$settings = Atlas_CB_Settings::get( $id );

		if ( $conditions && ! Atlas_CB_Conditions::matches( $settings ) ) {
			return '';
		}

		if ( 'popup' === $settings['type'] ) {
			Atlas_CB_Popups::add( $id, $settings );
			return '';
		}

		return Atlas_CB_Renderer::render( $id, $settings );
	}

	/**
	 * @param int $id Block ID.
	 *
	 * @return string
	 */
	private static function editor_preview( $id ) {
		$id = self::translated_id( $id );

		if ( ! $id || ATLAS_CB_POST_TYPE !== get_post_type( $id ) || ! current_user_can( 'edit_post', $id ) ) {
			return '';
		}

		$settings = Atlas_CB_Settings::get( $id );
		$content  = Atlas_CB_Renderer::render( $id, $settings, false );

		if ( 'popup' === $settings['type'] ) {
			$note = '<p style="padding:8px 12px;background:#f0f6fc;border-left:4px solid #2271b1;font-size:13px">'
				. esc_html__( 'Popup: not shown in the page. It opens through its triggers on pages where this block is placed.', 'atlas-content-blocks' )
				. '</p>';
			return $note . $content;
		}

		return $content;
	}

	/**
	 * The block in the current language, if WPML has a translation.
	 *
	 * @param int $id Block ID.
	 *
	 * @return int
	 */
	private static function translated_id( $id ) {
		return $id ? (int) apply_filters( 'wpml_object_id', $id, ATLAS_CB_POST_TYPE, true ) : 0;
	}
}
