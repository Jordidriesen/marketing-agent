<?php

function my_custom_login_stylesheet() {
	
	if (function_exists('get_field')) {
		$logo = get_field( 'login_screen_logo', 'options' ) ?? null;
		$logo_url =  wp_get_attachment_url($logo);
	}

	$logo_url = $logo_url ??  get_template_directory_uri() . '/images/admin-logo.png';

	if ( ! empty( $logo_url ) ) {
		
		?>
        <style type="text/css">
            body.login div#login h1 a {
                background-image: url(<?php echo $logo_url; ?>);
                padding-bottom: 30px;
            }
        </style>
		<?php
	}
	wp_enqueue_style( 'custom-login', get_stylesheet_directory_uri() . '/css/style-login.css' );
	wp_enqueue_script( 'custom-login', get_stylesheet_directory_uri() . '/js/script-login.js', [ 'jquery' ] );
}

add_action( 'login_enqueue_scripts', 'my_custom_login_stylesheet' );
