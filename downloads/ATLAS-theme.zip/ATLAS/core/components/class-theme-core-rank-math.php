<?php
/**
 * Rank Math Integration
 * ---------------------------------------------------------------------------------------
 *
 * This component customizes Rank Math's breadcrumb trail for custom post types
 * that don't map onto Rank Math's default archive/taxonomy based hierarchy.
 *
 * @package WordPress
 */

defined( 'ABSPATH' ) or die();

class Theme_Core_Rank_Math extends Theme_Core_Component {

	/**
	 * Post types that build their breadcrumb trail from a "Breadcrumbs Page"
	 * ACF field, mapped to the name of that field.
	 */
	protected $breadcrumb_fields = array(
		'event'    => 'event_breadcrumbs',
		'webinar'  => 'webinar_breadcrumbs',
		'download' => 'download_breadcrumbs',
	);

	protected function init() {
		add_filter( 'rank_math/frontend/breadcrumb/items', array( $this, 'filter_event_breadcrumbs' ) );
	}

	/**
	 * Build the breadcrumb trail for single events, webinars and downloads from the page
	 * selected in the "Breadcrumbs Page" ACF field, using that page's ancestors
	 * (e.g. Ressources > Events) so editors only have to pick the immediate parent page.
	 */
	public function filter_event_breadcrumbs( $crumbs ) {
		$post_type = get_post_type();

		if ( ! is_singular( array_keys( $this->breadcrumb_fields ) ) || ! isset( $this->breadcrumb_fields[ $post_type ] ) ) {
			return $crumbs;
		}

		$parent_page_url = get_field( $this->breadcrumb_fields[ $post_type ] );
		if ( ! $parent_page_url ) {
			return $crumbs;
		}

		// The "page_link" ACF field type returns a URL, not a post ID.
		$parent_page_id = url_to_postid( $parent_page_url );
		if ( ! $parent_page_id ) {
			return $crumbs;
		}

		$home      = $crumbs[0];
		$ancestors = array_reverse( get_post_ancestors( $parent_page_id ) );

		$new_crumbs = array( $home );
		foreach ( $ancestors as $ancestor_id ) {
			$new_crumbs[] = array( get_the_title( $ancestor_id ), get_permalink( $ancestor_id ) );
		}
		$new_crumbs[] = array( get_the_title( $parent_page_id ), get_permalink( $parent_page_id ) );
		$new_crumbs[] = array( get_the_title(), '' );

		return $new_crumbs;
	}
}
