document.addEventListener('DOMContentLoaded', function() {
    if (window.innerWidth < 1200) {
    const firstLi = document.querySelector('.block-subnav__list li:first-child');
    const otherLis = document.querySelectorAll('.block-subnav__list li:not(:first-child)');

    firstLi.addEventListener('click', function(event) {
        event.preventDefault(); // Prevent the default action (scrolling)
        otherLis.forEach(li => {
        li.classList.toggle('open');
        });
    });

    otherLis.forEach(li => {
        li.addEventListener('click', function() {
        otherLis.forEach(li => {
            li.classList.remove('open');
        });
        });
    });
    }
});