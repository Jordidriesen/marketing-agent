<?php
$block_object = new Block( $block );
$name = $block_object->block_name();

$class = $block_object->block_class();

$subnav_button = get_field('subnav_button');

loadAcfBlockPreviewImage(__DIR__);

?>
<div class="<?php echo $class; ?>">
	<div class="block-subnav__row container">

		<?php
		$content = get_the_content();
		if (function_exists('generateIndexSubheading') && !empty($content)) :
			$result = generateIndexSubheading($content);
		?>
		<div class="block-subnav__nav">
			<?php echo $result['index']; ?>
		</div>
		<?php endif; 
		
		if (!empty($subnav_button)) :
			$link = $subnav_button;
			$link_url = $link['url'];
			$link_title = $link['title'];
			$link_target = $link['target'] ? $link['target'] : '_self';
		?>
			<div class="wp-block-button block-subnav__button"><a class="wp-block-button__link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a></div>
		<?php endif; ?>
	</div>
</div>