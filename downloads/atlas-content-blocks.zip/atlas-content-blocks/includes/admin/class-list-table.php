<?php
/**
 * Extra columns and the "Duplicate" row action on the content block list
 * screen.
 *
 * @package AtlasContentBlocks
 */

defined( 'ABSPATH' ) || exit;

class Atlas_CB_List_Table {

	const DUPLICATE = 'atlas_cb_duplicate';

	public static function init() {
		add_filter( 'manage_' . ATLAS_CB_POST_TYPE . '_posts_columns', array( __CLASS__, 'columns' ) );
		add_action( 'manage_' . ATLAS_CB_POST_TYPE . '_posts_custom_column', array( __CLASS__, 'column' ), 10, 2 );
		add_filter( 'post_row_actions', array( __CLASS__, 'row_actions' ), 10, 2 );
		add_action( 'admin_post_' . self::DUPLICATE, array( __CLASS__, 'duplicate' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
	}

	/**
	 * @param array $columns Columns.
	 *
	 * @return array
	 */
	public static function columns( $columns ) {
		$date = $columns['date'] ?? null;
		unset( $columns['date'] );

		$columns['atlas_cb_type']       = __( 'Type', 'atlas-content-blocks' );
		$columns['atlas_cb_placement']  = __( 'Placement / trigger', 'atlas-content-blocks' );
		$columns['atlas_cb_conditions'] = __( 'Shown on', 'atlas-content-blocks' );
		$columns['atlas_cb_shortcode']  = __( 'Shortcode', 'atlas-content-blocks' );

		if ( $date ) {
			$columns['date'] = $date;
		}

		return $columns;
	}

	/**
	 * @param string $column  Column key.
	 * @param int    $post_id Block ID.
	 */
	public static function column( $column, $post_id ) {
		$s = Atlas_CB_Settings::get( $post_id );

		switch ( $column ) {
			case 'atlas_cb_type':
				echo 'popup' === $s['type'] ? esc_html__( 'Popup', 'atlas-content-blocks' ) : esc_html__( 'Content block', 'atlas-content-blocks' );
				break;

			case 'atlas_cb_placement':
				echo esc_html( self::placement( $s ) );
				break;

			case 'atlas_cb_conditions':
				echo esc_html( self::conditions( $s ) );
				break;

			case 'atlas_cb_shortcode':
				printf( '<code>[atlas_content_block id="%d"]</code>', (int) $post_id );
				break;
		}
	}

	/**
	 * @param array $s Settings.
	 *
	 * @return string
	 */
	private static function placement( array $s ) {
		if ( 'popup' === $s['type'] ) {
			$p        = $s['popup'];
			$triggers = array(
				'click'          => __( 'On click', 'atlas-content-blocks' ),
				'load'           => __( 'On page load', 'atlas-content-blocks' ),
				/* translators: %d: seconds */
				'delay'          => sprintf( __( 'After %d s', 'atlas-content-blocks' ), $p['delay'] ),
				/* translators: 1: amount, 2: unit (px or %) */
				'scroll_down'    => sprintf( __( 'After scrolling %1$d%2$s', 'atlas-content-blocks' ), $p['scroll'], $p['scroll_unit'] ),
				'scroll_up'      => __( 'On scroll up', 'atlas-content-blocks' ),
				/* translators: %s: CSS selector */
				'scroll_element' => sprintf( __( 'When %s is in view', 'atlas-content-blocks' ), $p['scroll_element'] ),
				/* translators: %d: seconds */
				'inactivity'     => sprintf( __( 'After %d s inactive', 'atlas-content-blocks' ), $p['inactivity'] ),
				/* translators: %d: number of pages */
				'pages'          => sprintf( __( 'After %d pages', 'atlas-content-blocks' ), $p['pages'] ),
				'exit'           => __( 'On exit intent', 'atlas-content-blocks' ),
			);
			return $triggers[ $p['trigger'] ] ?? '';
		}

		if ( ! $s['locations'] ) {
			return __( 'Placed by hand only', 'atlas-content-blocks' );
		}

		$labels = Atlas_CB_Settings::locations();
		$names  = array();
		foreach ( $s['locations'] as $location ) {
			if ( 'custom' === $location ) {
				$names[] = $s['custom_hook'];
			} elseif ( 'after_paragraph' === $location ) {
				/* translators: %d: paragraph number */
				$names[] = sprintf( __( 'After paragraph %d', 'atlas-content-blocks' ), $s['paragraph'] );
			} elseif ( 'before_heading' === $location ) {
				/* translators: %d: heading number */
				$names[] = sprintf( __( 'Before heading %d', 'atlas-content-blocks' ), $s['heading'] );
			} else {
				$names[] = $labels[ $location ] ?? $location;
			}
		}
		return implode( ', ', $names );
	}

	/**
	 * @param array $s Settings.
	 *
	 * @return string
	 */
	private static function conditions( array $s ) {
		$c     = $s['conditions'];
		$types = Atlas_CB_Settings::rule_types();

		$describe = function ( $rule ) use ( $types ) {
			$label = $types[ $rule['rule'] ]['label'] ?? $rule['rule'];
			foreach ( array( 'ids', 'terms', 'role', 'value', 'name', 'language' ) as $key ) {
				if ( isset( $rule[ $key ] ) && '' !== $rule[ $key ] ) {
					$label .= ': ' . $rule[ $key ];
					break;
				}
			}
			return ! empty( $rule['not'] ) ? __( 'not', 'atlas-content-blocks' ) . ' ' . $label : $label;
		};

		if ( 'advanced' === $c['mode'] ) {
			if ( ! $c['groups'] ) {
				return __( 'Nowhere (no rules)', 'atlas-content-blocks' );
			}
			$groups = array();
			foreach ( $c['groups'] as $group ) {
				$groups[] = '(' . implode( ' + ', array_map( $describe, $group['rules'] ) ) . ')';
			}
			return implode( ' ' . __( 'or', 'atlas-content-blocks' ) . ' ', $groups );
		}

		if ( ! $c['include'] ) {
			return __( 'Nowhere (no rules)', 'atlas-content-blocks' );
		}

		$text = implode( ', ', array_map( $describe, $c['include'] ) );

		if ( $c['exclude'] ) {
			/* translators: %s: list of excluded rules */
			$text .= ' ' . sprintf( __( '(except %s)', 'atlas-content-blocks' ), implode( ', ', array_map( $describe, $c['exclude'] ) ) );
		}

		return $text;
	}

	/**
	 * @param array   $actions Row actions.
	 * @param WP_Post $post    Post.
	 *
	 * @return array
	 */
	public static function row_actions( $actions, $post ) {
		if ( ATLAS_CB_POST_TYPE !== $post->post_type || ! self::can_duplicate( $post->ID ) ) {
			return $actions;
		}

		$url = wp_nonce_url(
			add_query_arg(
				array(
					'action' => self::DUPLICATE,
					'post'   => $post->ID,
				),
				admin_url( 'admin-post.php' )
			),
			self::DUPLICATE . '_' . $post->ID
		);

		$actions['atlas_cb_duplicate'] = sprintf(
			'<a href="%s" aria-label="%s">%s</a>',
			esc_url( $url ),
			/* translators: %s: block title */
			esc_attr( sprintf( __( 'Duplicate &#8220;%s&#8221;', 'atlas-content-blocks' ), get_the_title( $post ) ) ),
			esc_html__( 'Duplicate', 'atlas-content-blocks' )
		);

		return $actions;
	}

	/**
	 * @param int $post_id Block ID.
	 *
	 * @return bool
	 */
	private static function can_duplicate( $post_id ) {
		$type = get_post_type_object( ATLAS_CB_POST_TYPE );
		return $type && current_user_can( 'edit_post', $post_id ) && current_user_can( $type->cap->create_posts );
	}

	/**
	 * Copy a block (title with " (copy)", content, order and settings) as a
	 * draft, then open the copy.
	 */
	public static function duplicate() {
		$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;

		check_admin_referer( self::DUPLICATE . '_' . $post_id );

		$post = get_post( $post_id );
		if ( ! $post || ATLAS_CB_POST_TYPE !== $post->post_type ) {
			wp_die( esc_html__( 'Content block not found.', 'atlas-content-blocks' ), 404 );
		}
		if ( ! self::can_duplicate( $post_id ) ) {
			wp_die( esc_html__( 'You are not allowed to duplicate this content block.', 'atlas-content-blocks' ), 403 );
		}

		$copy_id = wp_insert_post(
			wp_slash(
				array(
					'post_type'    => ATLAS_CB_POST_TYPE,
					'post_status'  => 'draft',
					/* translators: %s: original title */
					'post_title'   => sprintf( __( '%s (copy)', 'atlas-content-blocks' ), $post->post_title ),
					'post_content' => $post->post_content,
					'post_excerpt' => $post->post_excerpt,
					'menu_order'   => $post->menu_order,
					'post_author'  => get_current_user_id(),
				)
			),
			true
		);

		if ( is_wp_error( $copy_id ) ) {
			wp_die( esc_html( $copy_id->get_error_message() ) );
		}

		// update_post_meta() unslashes, so slash to keep backslashes in selectors.
		update_post_meta( $copy_id, ATLAS_CB_META, wp_slash( Atlas_CB_Settings::get( $post_id ) ) );
		Atlas_CB_Settings::flush_index();

		wp_safe_redirect( add_query_arg( 'atlas_cb_duplicated', 1, get_edit_post_link( $copy_id, 'raw' ) ) );
		exit;
	}

	public static function notice() {
		// phpcs:ignore WordPress.Security.NonceVerification -- display only.
		if ( empty( $_GET['atlas_cb_duplicated'] ) ) {
			return;
		}
		$screen = get_current_screen();
		if ( ! $screen || ATLAS_CB_POST_TYPE !== $screen->post_type ) {
			return;
		}
		printf( '<div class="notice notice-success is-dismissible"><p>%s</p></div>', esc_html__( 'Content block duplicated. This is the copy, saved as a draft.', 'atlas-content-blocks' ) );
	}
}
