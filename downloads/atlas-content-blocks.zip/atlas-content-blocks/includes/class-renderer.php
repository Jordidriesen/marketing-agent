<?php
/**
 * Resolves which blocks apply to the current request, outputs hook blocks at
 * their locations and adds the "Content Blocks" menu to the admin toolbar.
 *
 * @package AtlasContentBlocks
 */

defined( 'ABSPATH' ) || exit;

class Atlas_CB_Renderer {

	/** @var array Matching hook blocks: ID => settings. */
	private static $hook_blocks = array();

	/** @var array Matching popups: ID => settings. */
	private static $popups = array();

	/** @var int[] Blocks being rendered, to stop a block rendering itself. */
	private static $stack = array();

	/** @var int Nesting depth of the_content, to inject only into the outermost call. */
	private static $content_depth = 0;

	/** @var array Blocks output on this page (any placement): ID => true. */
	private static $rendered = array();

	public static function init() {
		add_action( 'wp', array( __CLASS__, 'resolve' ) );
		add_action( 'wp_head', array( __CLASS__, 'print_css' ), 20 );
	}

	/**
	 * Whether this request renders a front-end page.
	 *
	 * @return bool
	 */
	public static function is_front_request() {
		return ! ( is_admin() || is_feed() || is_embed() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) );
	}

	/**
	 * Decide which blocks show on this request and attach them to their hooks.
	 * Runs once the main query is known.
	 */
	public static function resolve() {
		if ( ! self::is_front_request() ) {
			return;
		}

		self::setup_admin_bar();

		foreach ( Atlas_CB_Settings::index() as $id => $settings ) {
			if ( 'hook' === $settings['type'] && ! $settings['locations'] ) {
				continue;
			}
			if ( ! Atlas_CB_Conditions::matches( $settings ) ) {
				continue;
			}

			if ( 'popup' === $settings['type'] ) {
				self::$popups[ $id ] = $settings;
				continue;
			}

			self::$hook_blocks[ $id ] = $settings;
			foreach ( $settings['locations'] as $location ) {
				self::attach( $id, $settings, $location );
			}
		}

		if ( self::$hook_blocks ) {
			// Track the_content nesting for the in-content locations.
			add_filter( 'the_content', array( __CLASS__, 'content_enter' ), -1000 );
			add_filter( 'the_content', array( __CLASS__, 'content_leave' ), PHP_INT_MAX );
		}

		do_action( 'atlas_cb_resolved', self::$hook_blocks, self::$popups );
	}

	/**
	 * @param int    $id       Block ID.
	 * @param array  $settings Block settings.
	 * @param string $location Location key.
	 */
	private static function attach( $id, array $settings, $location ) {
		$priority = (int) $settings['priority'];

		if ( in_array( $location, Atlas_CB_Settings::CONTENT_LOCATIONS, true ) ) {
			add_filter(
				'the_content',
				function ( $content ) use ( $id, $settings, $location ) {
					if ( ! self::is_main_content() ) {
						return $content;
					}

					// Find the insertion point first, so a skipped block is not rendered (or listed).
					$offset = null;
					if ( 'after_paragraph' === $location || 'before_heading' === $location ) {
						$offset = Atlas_CB_Content_Inserter::offset( $content, $location, 'after_paragraph' === $location ? $settings['paragraph'] : $settings['heading'] );
						if ( null === $offset && 'before_heading' === $location ) {
							return $content;
						}
					}

					$block = self::render( $id, $settings );
					if ( '' === $block ) {
						return $content;
					}

					if ( 'content_start' === $location ) {
						return $block . $content;
					}
					if ( null === $offset ) {
						// End of content, or fewer paragraphs than asked for.
						return $content . $block;
					}
					return substr( $content, 0, $offset ) . $block . substr( $content, $offset );
				},
				// Always after blocks and shortcodes have been rendered (priority 11).
				max( 12, 20 + $priority )
			);
			return;
		}

		$hook = 'custom' === $location ? $settings['custom_hook'] : $location;
		if ( '' === $hook ) {
			return;
		}

		add_action(
			$hook,
			function () use ( $id, $settings ) {
				echo self::render( $id, $settings ); // phpcs:ignore WordPress.Security.EscapeOutput -- post content, filtered like the_content.
			},
			$priority
		);
	}

	/**
	 * Whether the current the_content call is the main post's own content.
	 *
	 * @return bool
	 */
	private static function is_main_content() {
		return 1 === self::$content_depth
			&& empty( self::$stack )
			&& is_singular()
			&& in_the_loop()
			&& is_main_query()
			&& get_the_ID() === get_queried_object_id();
	}

	/**
	 * @param string $content Content.
	 *
	 * @return string
	 */
	public static function content_enter( $content ) {
		self::$content_depth++;
		return $content;
	}

	/**
	 * @param string $content Content.
	 *
	 * @return string
	 */
	public static function content_leave( $content ) {
		self::$content_depth = max( 0, self::$content_depth - 1 );
		return $content;
	}

	/**
	 * Render a block's content, by default inside its wrapper.
	 *
	 * Content goes through the_content, so blocks, shortcodes, embeds and the
	 * theme's per-block style loader work as in a page.
	 *
	 * @param int   $id       Block ID.
	 * @param array $settings Block settings.
	 * @param bool  $wrap     Wrap in the block container.
	 *
	 * @return string
	 */
	public static function render( $id, array $settings, $wrap = true ) {
		if ( in_array( $id, self::$stack, true ) ) {
			return '';
		}

		$post = get_post( $id );
		if ( ! $post || ATLAS_CB_POST_TYPE !== $post->post_type ) {
			return '';
		}

		self::$stack[] = $id;
		$content       = apply_filters( 'the_content', $post->post_content );
		array_pop( self::$stack );

		$content = (string) apply_filters( 'atlas_cb_content', $content, $id, $settings );

		if ( '' === trim( $content ) ) {
			return '';
		}

		self::track( $id );

		if ( ! $wrap ) {
			return $content;
		}

		$container = $settings['container'];
		$classes   = array( 'atlas-cb', 'atlas-cb-' . $id );

		if ( 'default' !== $container['structure'] ) {
			$classes[] = 'atlas-cb--' . $container['structure'];
		}
		if ( 'none' !== $container['structure'] ) {
			if ( 'none' !== $container['spacing_top'] ) {
				$classes[] = 'atlas-cb--pt-' . $container['spacing_top'];
			}
			if ( 'none' !== $container['spacing_bottom'] ) {
				$classes[] = 'atlas-cb--pb-' . $container['spacing_bottom'];
			}
		}
		foreach ( $settings['hide_on'] as $device ) {
			$classes[] = 'atlas-cb--hide-' . $device;
		}

		if ( 'custom' === $container['structure'] ) {
			// The theme's own grid: .container is boxed, .container--full spans the width.
			$content = sprintf(
				'<div class="%s"><div class="%s">%s</div></div>',
				esc_attr( 'wide' === $container['width'] ? 'container container--full' : 'container' ),
				esc_attr( 'narrow' === $container['content'] ? 'atlas-cb__inner atlas-cb__inner--narrow' : 'atlas-cb__inner' ),
				$content
			);
		}

		return sprintf(
			'<div class="%s" data-atlas-cb="%d">%s</div>',
			esc_attr( implode( ' ', $classes ) ),
			(int) $id,
			$content
		);
	}

	/**
	 * Remember that a block was output, for the admin toolbar menu.
	 *
	 * @param int $id Block ID.
	 */
	public static function track( $id ) {
		self::$rendered[ (int) $id ] = true;
	}

	/**
	 * Device, structure and spacing classes, inline in the head so they apply
	 * before first paint. Printed when any published block uses them, since
	 * manually placed blocks are only known after the head. Device breakpoints
	 * follow the theme: desktop from 1200px, mobile below 768px. Spacing uses
	 * the theme's spacing scale (Theme settings, spacing small/medium/large).
	 */
	public static function print_css() {
		if ( ! self::is_front_request() ) {
			return;
		}

		$devices   = false;
		$structure = false;
		foreach ( Atlas_CB_Settings::index() as $settings ) {
			$devices   = $devices || $settings['hide_on'];
			$structure = $structure || 'default' !== $settings['container']['structure'] || 'none' !== $settings['container']['spacing_top'] || 'none' !== $settings['container']['spacing_bottom'];
		}

		$css = '';

		if ( $devices ) {
			$css .= '@media (max-width:767px){.atlas-cb--hide-mobile{display:none!important}}'
				. '@media (min-width:768px) and (max-width:1199px){.atlas-cb--hide-tablet{display:none!important}}'
				. '@media (min-width:1200px){.atlas-cb--hide-desktop{display:none!important}}';
		}

		if ( $structure ) {
			$space = self::spacing_scale();
			$css  .= sprintf( ':root{--atlas-cb-space-small:%s;--atlas-cb-space-medium:%s;--atlas-cb-space-large:%s}', $space['small'], $space['medium'], $space['large'] );
			foreach ( array( 'small', 'medium', 'large' ) as $size ) {
				$css .= sprintf( '.atlas-cb--pt-%1$s{padding-top:var(--atlas-cb-space-%1$s)}.atlas-cb--pb-%1$s{padding-bottom:var(--atlas-cb-space-%1$s)}', $size );
			}
			$css .= '.atlas-cb--none{margin:0;padding:0}'
				. '.atlas-cb--none>:first-child{margin-top:0}.atlas-cb--none>:last-child{margin-bottom:0}'
				. '.atlas-cb__inner--narrow{max-width:710px;margin-right:auto;margin-left:auto}';
		}

		if ( '' !== $css ) {
			echo '<style id="atlas-cb-css">' . $css . "</style>\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- fixed CSS and sanitised lengths.
		}
	}

	/**
	 * The theme's spacing scale (see includes/gutenberg/spacings.php in ATLAS):
	 * 4, 8 and 12rem unless changed in the theme options.
	 *
	 * @return array
	 */
	private static function spacing_scale() {
		$scale = array(
			'small'  => '4rem',
			'medium' => '8rem',
			'large'  => '12rem',
		);

		if ( function_exists( 'get_field' ) ) {
			foreach ( $scale as $size => $default ) {
				$value = get_field( 'spacing_' . $size, 'options' );
				if ( is_numeric( $value ) && $value > 0 ) {
					$scale[ $size ] = ( (float) $value / 10 ) . 'rem';
				}
			}
		}

		return $scale;
	}

	/**
	 * @return array Matching popups: ID => settings.
	 */
	public static function popups() {
		return self::$popups;
	}

	/**
	 * Core prints the toolbar at wp_body_open, before most blocks render. For
	 * people who can edit blocks, print it in the footer instead (it is fixed
	 * in place, so it looks the same) so the menu can list every block output
	 * on the page.
	 */
	private static function setup_admin_bar() {
		$type = get_post_type_object( ATLAS_CB_POST_TYPE );
		if ( ! $type || ! is_admin_bar_showing() || ! current_user_can( $type->cap->edit_posts ) ) {
			return;
		}

		remove_action( 'wp_body_open', 'wp_admin_bar_render', 0 );
		add_action( 'admin_bar_menu', array( __CLASS__, 'admin_bar' ), 999 );
	}

	/**
	 * "Content Blocks (N)" with an edit link per block output on the page.
	 *
	 * @param WP_Admin_Bar $bar Toolbar.
	 */
	public static function admin_bar( $bar ) {
		if ( ! self::$rendered ) {
			return;
		}

		$bar->add_node(
			array(
				'id'    => 'atlas-cb',
				/* translators: %d: number of content blocks */
				'title' => esc_html( sprintf( __( 'Content Blocks (%d)', 'atlas-content-blocks' ), count( self::$rendered ) ) ),
				// Core escapes href when it prints the toolbar.
				'href'  => admin_url( 'edit.php?post_type=' . ATLAS_CB_POST_TYPE ),
			)
		);

		foreach ( array_keys( self::$rendered ) as $id ) {
			if ( ! current_user_can( 'edit_post', $id ) ) {
				continue;
			}
			$settings = Atlas_CB_Settings::get( $id );
			$title    = get_the_title( $id );
			$bar->add_node(
				array(
					'parent' => 'atlas-cb',
					'id'     => 'atlas-cb-' . $id,
					'title'  => esc_html( ( '' !== $title ? $title : '#' . $id ) . ( 'popup' === $settings['type'] ? ' (' . __( 'popup', 'atlas-content-blocks' ) . ')' : '' ) ),
					'href'   => (string) get_edit_post_link( $id, 'raw' ),
				)
			);
		}
	}
}
