<?php
/**
 * Loop for home page.
 *
 * @package    WordPress
 * @subpackage ATLAS
 * @since      ATLAS 1.0
 */

?>
<section class="posts-content search-result__posts">
	<div class="row">
	<?php 
	while ( have_posts() ) : the_post(); 
		$id = get_the_ID();
		if ( get_post_type( $id ) === 'product' ) {
			continue;
		}
	?>
		<div class="search-result__post col col-12"><?php get_theme_part('components/single-search/index', ['id' => $id, 'btn_txt'=> __('Mehr erfahren', 'ATLAS')]); ?></div>
	<?php endwhile; ?>
	</div>
</section>
