import controller from './app/__init/controller';
import detectTabNav from './app/__constants/detectTabNav';
let handled = false;

controller.init();

window.onload = () => {
	controller.loaded();
};
window.onresize = () => {
	controller.resized();
};
window.onscroll = (e) => {
	controller.scrolled(e);
};
window.keydown = (e) => {
	detectTabNav(e);
};
const onMouseUp = (e) => {
	if (e.type === "touchend") {
		handled = true;
		controller.mouseUp(e);
	} else if (e.type === "mouseup" && !handled) {
		controller.mouseUp(e);
	} else {
		handled = false;
	}
};
document.addEventListener("mouseup", onMouseUp);
document.addEventListener("touchend", onMouseUp);
