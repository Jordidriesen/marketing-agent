<?php
add_filter( 'render_block', 'wrap_image_block', 10, 2 );
function wrap_image_block( $block_content, $block ) {
	if ( 'core/image' === $block['blockName'] ) {
		$block_content = '<div data-styles-id="core-image"></div>' . $block_content;
	}
	return $block_content;
}
