<?php
function init_block_icon_text() {
    if ( ! function_exists( 'acf_register_block' ) ) {
        return;
    }

    acf_register_block( array(
        'name'              => 'icon-text',
        'title'             => __( 'Icon - Text', 'ATLAS' ),
        'description'       => __( 'icon-text block', 'ATLAS' ),
        'category'          => 'custom_blocks',
        'icon'              => 'media-document',
        'mode'              => 'auto',
        'keywords'          => array( 'icon', 'text' ),
        'supports'          => array(
            'align' => false,
        ),
		'example'         => [
            'attributes' => [
                'mode' => 'preview',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-icon-text/index.php',
    ));
}

add_action( 'acf/init', 'init_block_icon_text' );

// function extend_block_teser_script() {
//     wp_enqueue_script(
//         'ATLAS/block_teser_script',
//         get_template_directory_uri() . '/parts/blocks/acf-icon-text/admin.min.js',
//         array( 'wp-i18n', 'wp-dom-ready', 'wp-editor', 'wp-blocks' )
//     );
// }
// add_action( 'enqueue_block_editor_assets', 'extend_block_teser_script' );