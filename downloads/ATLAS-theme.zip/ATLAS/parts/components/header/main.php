<?php
$desktop_logo = get_field('desktop_logo', 'options');
$mobile_logo = get_field('mobile_logo', 'options');

$primion_labs_logo = get_field('primion_labs_logo', 'options');
$primion_labs_parent = get_field('primion_labs_parent', 'options');

$landing_header = get_field('show_landing_header');
$class = $landing_header ? 'main-header main-header--landing' : 'main-header';

$link_login = get_field('header_link_login', 'options');

if ( $primion_labs_parent && ( is_page( $primion_labs_parent ) || is_singular('primion-lab') ) ) {
	$class .= ' main-header--labs';
}

?>
<header class="<?php echo $class; ?> main-header__fixed-header <?php echo is_singular('landingpage') ? 'main-header--landing' : ''; ?>">
	<?php echo loadStyles(__DIR__, 'header'); ?>

	<div class="main-header__main main-header__fixed">
		<div class="main-header__content-wrapper">
			<div class="main-header__logo-wrapper">
				
				<?php if ( !empty($primion_labs_logo) && $primion_labs_parent && ( is_page( $primion_labs_parent ) || is_singular('primion-lab') ) ) : ?>
					<a href="<?php echo get_permalink( $primion_labs_parent ); ?>" class="header-logo__link" aria-label="primion labs Logo">
						<figure class="main-header__logo">
							<?php echo get_svg( $primion_labs_logo, 'full' ); ?>
						</figure>
					</a>
				<?php elseif ( !empty($desktop_logo) ) : ?>
					<a href="<?php echo get_bloginfo( 'url' ); ?>" class="header-logo__link" aria-label="primion Logo">
						<figure class="main-header__logo">
							<?php echo get_svg( $desktop_logo, 'full' ); ?>
						</figure>
					</a>
				<?php endif; ?>
				
			</div>

			<div class="main-header__content">
				<div class="main-header__content-items">

				<?php 
					if( has_nav_menu( 'primary' ) ): 
						wp_nav_menu(
							array(
								'theme_location'  => 'primary',
								'container'       => 'nav',
								'container_class' => 'main-nav',
								'walker'          => new Custom_Nav_Menu_Walker()
							)
						);
					endif; 
				?>	
				</div>

			</div>

			<div class="main-header__meta">
				<div class="main-header__meta--icons main-header__meta--desktop">
					<div id="search-icon" class="main-header-search">
						<span></span>
					</div>

					<?php 
					if( $link_login ): 
						$link_login_url = $link_login['url'];
						$link_login_title = $link_login['title'];
						$link_login_target = $link_login['target'] ? $link_login['target'] : '_self';
					?>
					<div class="main-header__login">
						<a href="<?php echo esc_url( $link_login_url ); ?>" target="<?php echo esc_attr( $link_login_target ); ?>" class="main-header__link"></a>
					</div>
					<?php endif; ?>
				</div>

				<div class="main-header__icons-language main-header__meta--desktop">
					<div id="language-icon"></div>
					<div class="main-header__icons-language-list">
						<label for="uc-language-selector-mobile" style="display:none;"><?php echo __('Language Switch', 'ATLAS'); ?></label>
						<?php echo do_shortcode('[wpml_language_selector_widget]'); ?>
					</div>
				</div>

				<div class="main-header__icons-theme main-header__meta--desktop">
					<div class="theme-toggle" id="theme-controls">
						<button class="button" data-set-theme="light" aria-label="Activate Light Mode">
							<div class="icon" style="mask-image: url('<?php echo get_template_directory_uri(); ?>/images/header/primion-icon-theme-light.svg');" alt="Light Mode"></div>
						</button>
						<button class="button" data-set-theme="dark" aria-label="Activate Dark Mode">
							<div class="icon" style="mask-image: url('<?php echo get_template_directory_uri(); ?>/images/header/primion-icon-theme-dark.svg');" alt="Dark Mode"></div>
						</button>
					</div>
				</div>

				<?php
				$header_show_button = get_field('header_show_button', 'options') ?? '';
				$header_button = get_field('header_button', 'options') ?? '';
				
				if( $header_show_button && $header_button && is_front_page() ): 
					$link_url = $header_button['url'];
					$link_title = $header_button['title'];
					$link_target = $header_button['target'] ? $header_button['target'] : '_self';
					$name = 'core-button';
				?>
					<?php loadStylesDep('blocks/core-button', $name); ?>
					<div class="wp-block-button main-header-button main-header-button__desktop">
						<a class="wp-block-button__link main-header-button__link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a>
					</div>
				<?php endif; ?>


				
				<button id="hamburger-trigger" aria-label="Menu Trigger" class="hamburger-trigger main-header__mobile-open mobile-menu-js__open">
					<div class="hamburger">
						<span></span>
						<span></span>
						<span></span>
					</div>
				</button>
			</div>

			

			<div class="main-header__mobile main-header__mobile--main">
				
				<div class="mega-menu-meta">
					<div id="search-icon-mobile" class="main-header-search main-header-search-mobile">
					<form class="search-form" method="get" action="<?php bloginfo( 'url' ); ?>">
						<input type="text" name="s" id="s" placeholder="<?php echo __( 'Search ...', 'ATLAS' ); ?>"/>
						<button type="submit" class="search-submit"></button>
					</form>
					</div>
				</div>
			
				<div class="mega-menu-header">
					<button class="mega-menu-header__btn mobile-submenu-back">
						<span class="mobile-submenu-back__icon"></span>
					</button>
					<div class="mega-menu-header__link">
						<a href="#" target="">test</a>
					</div>
				</div>

				<button aria-label="Menu Close" class="hamburger-trigger main-header__mobile-close mobile-menu-js__close">
					<div class="hamburger">
						<span></span>
						<span></span>
						<span></span>
					</div>
				</button>

				<?php if ( !is_singular('landingpage') ) : ?>
				<nav class="main-nav-mobile">
				<?php 
					if( has_nav_menu( 'primary' ) ): 
						wp_nav_menu(
							array(
								'theme_location'  => 'primary',
								'container'       => false,
								'walker'          => new Custom_Nav__Mobile_Menu_Walker()
							)
						);
					endif; 
					?>
				</nav>
				<?php endif; ?>

				<div class="main-header__meta--icons main-header__meta--mobile">
					<?php 
					if( $link_login ): 
						$link_login_url = $link_login['url'];
						$link_login_title = $link_login['title'];
						$link_login_target = $link_login['target'] ? $link_login['target'] : '_self';
					?>
					<div class="main-header__login">
						<a href="<?php echo esc_url( $link_login_url ); ?>" target="<?php echo esc_attr( $link_login_target ); ?>" class="main-header__link main-header__login-title"><?php echo __('Login', 'ATLAS');?></a>
					</div>
					<?php endif; ?>

					
					<div class="main-header__icons-language">
						<div id="language-icon">
							<span class="main-header__icons-language-title"><?php echo __('Language', 'ATLAS');?></span>
						</div>
						
						<div class="main-header__icons-language-list">
							<label for="uc-language-selector-mobile" style="display:none;"><?php echo __('Language Switch', 'ATLAS'); ?></label>
							<?php echo do_shortcode('[wpml_language_selector_widget]'); ?>
						</div>						
					</div>

					<div class="main-header__icons-theme">
						<div class="theme-toggle" id="theme-controls">
							<button class="button" data-set-theme="light">
								<div class="icon" style="mask-image: url('<?php echo get_template_directory_uri(); ?>/images/header/primion-icon-theme-light.svg');" alt="Light Mode"></div>
							</button>
							<button class="button" data-set-theme="dark">
								<div class="icon" style="mask-image: url('<?php echo get_template_directory_uri(); ?>/images/header/primion-icon-theme-dark.svg');" alt="Dark Mode"></div>
							</button>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>

</header>

<div class="main-header__search">
	<div class="main-header__search-wrapper">
		<?php get_search_form(); ?>
	</div>
</div>