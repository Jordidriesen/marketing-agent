<?php

/**
 * The single post page template.
 *
 * @package    WordPress
 * @subpackage ATLAS
 * @since      ATLAS 1.0
 */

get_header();
the_post();
loadStylesComponents('download-overview');
?>
<main class="page-content page-content--single page-content--download">
	<div class="page-entry">

		<?php loadStylesDep('blocks/custom-container', 'custom-container'); ?>
		<section class="wp-block-custom-container alignwide block-content has-dark-grey-background-color block-content--spacing-top block-content--spacing-bottom block-content--margin-top">
			<div class="container container-wide">
				<div class="container__body">

					<div class="wp-block-custom-columns columns-row row">
						<?php loadStylesDep('blocks/custom-columns', 'custom-columns'); ?>
						<?php loadStylesDep('blocks/core-image', 'core-image'); ?>
						<div class="wp-block-custom-column col col-12 col-xl-7">

							<?php
							$title = get_the_title();
							$short_desc = get_the_excerpt();

							//File as Array (url, filename, filesize, subtype, ...)
							$download_file = get_field('download_file');
							$download_pages = get_field('download_pages');
							$download_topic = get_field('download_topic');

							$download_about = get_field('download_about');
							//What's inside as Repeater
							$download_content = get_field('download_content');

							$download_hs_form = get_field('download_hs_form');

							// Taxonomy terms (always arrays, so they can safely be checked further down)
							$download_type_names = get_webinar_term_names(get_the_ID(), 'download-type');

							// With a form the file is gated, without one it is offered directly
							$download_is_gated = !empty($download_hs_form);

							// "PDF · 4.2 MB · 12 pages" — built from whatever information is available
							$download_file_meta = [];
							if (!empty($download_file['subtype'])) {
								$download_file_meta[] = strtoupper($download_file['subtype']);
							}
							if (!empty($download_file['filesize'])) {
								$download_file_meta[] = size_format($download_file['filesize'], 1);
							}
							if (!empty($download_pages)) {
								$download_file_meta[] = sprintf(_n('%s page', '%s pages', $download_pages, 'ATLAS'), $download_pages);
							}

							// Same, but without the file size, for the "At a glance" box
							$download_format = [];
							if (!empty($download_file['subtype'])) {
								$download_format[] = strtoupper($download_file['subtype']);
							}
							if (!empty($download_pages)) {
								$download_format[] = sprintf(_n('%s page', '%s pages', $download_pages, 'ATLAS'), $download_pages);
							}
							?>
							<?php if (function_exists("rank_math_the_breadcrumbs")) rank_math_the_breadcrumbs(); ?>

							<?php if (!empty($download_type_names)) : ?>
								<div class="single-download__taxonomies">
									<p class="single-download__download-types"><?php echo esc_html(implode(', ', $download_type_names)); ?></p>
								</div>
							<?php endif; ?>

							<h1 class="single-download__title"><?php echo $title; ?></h1>
							<?php if (!empty($short_desc)) : ?>
								<span class="single-download__desc"><?php echo $short_desc; ?></span>
							<?php endif; ?>

							<?php if (!empty($download_content)) : ?>
								<div class="single-download__content">
									<h2 class="wp-block-heading"><?php echo __("What's inside", 'ATLAS'); ?></h2>
									<?php foreach ($download_content as $content_item) : ?>
										<?php if (empty($content_item['content_headline'])) continue; ?>
										<div class="single-download__content-item">
											<figure class="single-download__content-item-icon">
												<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-check-circle"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
											</figure>
											<p class="single-download__content-item-headline"><?php echo $content_item['content_headline']; ?></p>
										</div>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>
						</div>

						<div class="wp-block-custom-column col col-12 col-xl-5">
							<section class="wp-block-custom-container alignwide block-content has-white-black-background-color" style="background-color:#000000">
								<div class="container container--wide">
									<div class="download-form container__body">

										<?php if ($download_is_gated) : ?>
											<h2 class="wp-block-heading has-dark-grey-light-grey-color has-text-color"><?php echo __('Download your free copy', 'ATLAS'); ?></h2>

											<?php echo $download_hs_form; ?>

										<?php elseif (!empty($download_file['url'])) : ?>
											<h2 class="wp-block-heading has-dark-grey-light-grey-color has-text-color"><?php echo __('Your free download', 'ATLAS'); ?></h2>

											<div class="single-download__file">
												<figure class="single-download__file-icon">
													<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file-text"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
												</figure>
												<div class="single-download__file-details">
													<span class="single-download__file-name"><?php echo esc_html(!empty($download_file['filename']) ? $download_file['filename'] : $title); ?></span>
													<?php if (!empty($download_file_meta)) : ?>
														<span class="single-download__file-meta"><?php echo esc_html(implode(' · ', $download_file_meta)); ?></span>
													<?php endif; ?>
												</div>
											</div>

											<?php loadStylesDep('blocks/core-button', 'core-button'); ?>
											<div class="single-download__buttons">
												<div class="wp-block-button single-download__button"><a class="wp-block-button__link" href="<?php echo esc_url($download_file['url']); ?>" target="_blank" rel="noopener noreferrer" download><?php echo __('Download now', 'ATLAS'); ?><img src="<?php echo esc_url(get_template_directory_uri() . '/images/svg/icon_download_white.svg'); ?>" alt="" aria-hidden="true"></a></div>
											</div>

										<?php else : ?>
											<h2 class="wp-block-heading has-dark-grey-light-grey-color has-text-color"><?php echo __('Get this download', 'ATLAS'); ?></h2>

											<p><?php echo __('Please contact us to receive this download.', 'ATLAS'); ?></p>
										<?php endif; ?>

									</div>
								</div>
							</section>
						</div>
					</div>



				</div>
			</div>
		</section>

		<section class="wp-block-custom-container alignwide block-content  block-content--spacing-top block-content--spacing-bottom">
			<div class="container container--wide">
				<div class="container__body">
					<div class="wp-block-custom-columns columns-row row">

						<div class="wp-block-custom-column col col-12 col-xl-8">
							<?php if (!empty($download_about)) : ?>
								<div class="single-download__about">
									<h2 class="wp-block-heading"><?php echo __('About this download', 'ATLAS'); ?></h2>
									<?php echo $download_about; ?>
								</div>
							<?php endif; ?>

						</div>



						<div class="wp-block-custom-column col col-12 col-xl-4">

							<?php if (!empty($download_type_names) || !empty($download_format) || !empty($download_topic)) : ?>
								<section class="wp-block-custom-container alignwide block-content has-dark-grey-background-color block-content--margin-bottom" style="background-color:#000000">
									<div class="container container--wide">
										<div class="download-info container__body">
											<h2 class="wp-block-heading has-white-color has-text-color"><?php echo __('At a glance', 'ATLAS'); ?></h2>

											<?php if (!empty($download_type_names)) : ?>
											<p>
												<?php echo __('Type:', 'ATLAS'); ?><br>
												<?php echo esc_html(implode(', ', $download_type_names)); ?>
											</p>
											<?php endif; ?>

											<?php if (!empty($download_format)) : ?>
											<p>
												<?php echo __('Format:', 'ATLAS'); ?><br>
												<?php echo esc_html(implode(' · ', $download_format)); ?>
											</p>
											<?php endif; ?>

											<?php if (!empty($download_topic)) : ?>
											<p>
												<?php echo __('Topic:', 'ATLAS'); ?><br>
												<?php echo esc_html($download_topic); ?>
											</p>
											<?php endif; ?>

										</div>
									</div>
								</section>
							<?php endif; ?>


							<?php // Related downloads ?>
							<?php
							$related_downloads_query = get_latest_downloads(3, get_the_ID());
							if ($related_downloads_query->have_posts()) :
								?>
								<h2><?php echo __('Related downloads', 'ATLAS'); ?></h2>
								<?php while ($related_downloads_query->have_posts()) : $related_downloads_query->the_post();
									$related_download_title = get_the_title();
									$related_download_permalink = get_permalink();
									$related_download_thumbnail = get_the_post_thumbnail_url(get_the_ID(), 'thumbnail');
									?>
									<div class="single-download__related-download--item">
										<a class="single-download__related-download" href="<?php echo esc_url($related_download_permalink); ?>">
											<?php if ($related_download_thumbnail) : ?>
												<img class="single-download__related-download-image" src="<?php echo esc_url($related_download_thumbnail); ?>" alt="<?php echo esc_attr($related_download_title); ?>">
											<?php endif; ?>
											<div class="single-download__related-download-info">
												<h4 class="single-download__related-download-title"><?php echo esc_html($related_download_title); ?></h4>

												<div class="wp-block-button is-style-link-only single-download__related-download-button">
													<div class="wp-block-button__link">
														<?php echo __('View download', 'ATLAS'); ?>
													</div>
												</div>

											</div>
										</a>
									</div>
								<?php endwhile; ?>
								<?php wp_reset_postdata(); ?>
							<?php endif; ?>


						</div>
					</div>
				</div>
			</div>
		</section>

	</div>
</main>
<?php
get_footer();
