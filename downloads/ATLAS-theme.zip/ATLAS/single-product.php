<?php
/**
 * The single post page template.
 *
 * @package    WordPress
 * @subpackage ATLAS
 * @since      ATLAS 1.0
 */

get_header();
the_post();
?>
	<main style="margin-top:120px"  class="page-content page-content--single">
		<div class="page-entry">
			<?php if ( get_the_content() ) : 
				the_content();
				?>
				<?php else : ?>
					<?php loadStylesDep('blocks/custom-container', 'custom-container'); ?>
					<div class="wp-block-custom-container alignwide block-content  block-content--spacing-top block-content--spacing-bottom">
						<div class="container container-wide">
						<?php
							$title = get_the_title();
							$short_desc = get_the_excerpt();
							
							$content_post = get_post();
							$content = $content_post->post_content;
							$content = apply_filters('the_content', $content);
							$content = str_replace(']]>', ']]&gt;', $content);

							$download_url = get_field('product_download');
						?>
							<h1 class="single-product__title"><?php echo $title; ?></h1>
							<?php if (!empty($short_desc)) : ?>
								<span class="single-product__desc"><?php echo $short_desc; ?></span>
							<?php endif; ?>
							<div class="single-product__content">
								<?php echo $content; ?>

								<?php if( !empty($download_url) ) : ?>
								<?php $name = 'core-button';?>
								<?php loadStylesDep('blocks/core-button', $name); ?>
								<div style="margin-top: 20px;" class="wp-block-button single-product__button"><a class="wp-block-button__link" target="_BLANK" href="<?php echo $download_url; ?>"><?php echo _e( 'Product data sheet', 'ATLAS' ); ?></a></div>
								<?php endif; ?>
							</div>
						</div>
					</div>
				<?php 
				endif;
				?>
		</div>
	</main>
<?php
get_footer();
