<?php
/**
 * The main template file.
 *
 * @package    WordPress
 * @subpackage ATLAS
 * @since      ATLAS 1.0
 */

get_header();
$heading_text = get_blog_heading();
?>
	<main class="page-content page-content--search" style="margin-top: 96px">
    <section class="wp-block-custom-container alignwide block-content  block-content--spacing-top block-content--spacing-bottom block-content--margin-bottom">
        <style>.block-content{position:relative}.block-content--spacing-top{padding-top:6rem}@media (min-width: 992px){.block-content--spacing-top{padding-top:12rem}}.block-content--spacing-bottom{padding-bottom:6rem}@media (min-width: 992px){.block-content--spacing-bottom{padding-bottom:12rem}}.block-content--margin-top{margin-top:5rem}@media (min-width: 992px){.block-content--margin-top{margin-top:10rem}}.block-content--margin-bottom{margin-bottom:5rem}@media (min-width: 992px){.block-content--margin-bottom{margin-bottom:10rem}}.block-content .container{position:relative;z-index:1}.block-content .container--full{padding:0}.block-content .container .block-content{overflow:hidden;border-radius:1.2rem}.block-content .container .container{padding:2rem}@media (min-width: 1024px){.block-content .container .container{padding:4rem}}@media (min-width: 1380px){.block-content .container .container{padding:6rem 5rem}}.block-content .container-overlay{position:absolute;z-index:0;top:0;right:0;bottom:0;left:0}.block-content.keine-welle::after{background:transparent !important}.block-content.has-text-light-background-color{position:relative}.block-content.has-text-light-background-color::after{content:'';position:absolute;right:0;bottom:2px;left:0;width:100%;height:100%;pointer-events:none;bottom:100%;background-size:contain;background-repeat:no-repeat;background-position:bottom center;background-image:url("//localhost:3000/smart-301_empera/web/app/themes/ATLAS/images/svg/welle_weiss.svg");z-index:2}</style>
        <div class="container container--wide">
        <?php
            $id = get_the_ID();
            if ( have_posts() & get_post_type( $id ) !== 'product' ) :
                if ( $heading_text ) :
        ?>
            <h1><?php echo $heading_text; ?></h1>
        <?php
                endif;
                get_theme_part( 'archive/loop-search' );
            else :
                $search_editor = get_field( 'search_editor', 'options' );
                $search_button = get_field( 'search_button', 'options' );
                if ( $search_editor ) :
                    echo $search_editor;
                else:
        ?>

            <h2><?php _e( 'Sorry, unfortunately nothing was found.', 'ATLAS' ); ?></h2>
        <?php
                endif;
                if( $search_button ): 
                    $search_button_url = $search_button['url'];
                    $search_button_title = $search_button['title'];
                    $search_button_target = $search_button['target'] ? $search_button['target'] : '_self';
                    $name = 'core-button';
                    ?>
                    <?php loadStylesDep('blocks/core-button', $name); ?>
                    <div class="wp-block-button"><a class="wp-block-button__link" href="<?php echo esc_url( $search_button_url ); ?>" target="<?php echo esc_attr( $search_button_target ); ?>"><?php echo esc_html( $search_button_title ); ?></a></div>
                <?php 
                endif; 
            endif;

            $args = array(
                'mid_size'           => 3,
                'prev_text'          => __( 'Prev' ),
                'next_text'          => __( 'Next' ),
                'screen_reader_text' => __( 'Posts navigation' ),
            );

            the_posts_pagination( $args );
        ?>
            </div>
        </section>
	</main>
<?php
get_footer();
