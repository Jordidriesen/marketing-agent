<?php
function init_block_gallery() {
    if ( ! function_exists( 'acf_register_block' ) ) {
        return;
    }

    acf_register_block( array(
        'name'              => 'gallery',
        'title'             => __( 'Galerie / Gallery', 'ATLAS' ),
        'description'       => __( 'Gallery block', 'ATLAS' ),
        'category'          => 'custom_blocks',
        'icon'              => 'format-gallery',
        'mode'              => 'auto',
        'keywords'          => array( 'gallery', 'images', 'slider', 'slick', 'galerie' ),
        'align'             => 'full',
        'example'           => [
            'attributes' => [
                'mode' => 'preview',
            ]
        ],
        'supports'          => array(
			'align' => false,
		),
        'render_template'   => get_template_directory() . '/parts/blocks/acf-gallery/index.php',
		'enqueue_assets'  => function () {
			wp_enqueue_script(
				'ATLAS/acf-gallery/',
                get_template_directory_uri() . '/parts/blocks/acf-gallery/index.min.js', 
                [ 'splide_script' ],
                false,
                array(
                    'in_footer' => true,
                    'strategy'  => 'defer',
                ) 
			);
		}
    ));
}
add_action( 'acf/init', 'init_block_gallery' );
