/**
 * --------------------------------------------------------------------------
 * Lock screen
 * Function locking screen scrolling, e.g for modals, menus or other
 * --------------------------------------------------------------------------
 */

// --------------------------------------------------------------------------
// Cache DOM

const html = document.documentElement;
const { body } = document;

let scrollTop;

// --------------------------------------------------------------------------
// Functions

const ScreenLock = {
	lock() {
		// Same value as jQuery's $(window).height()
		const windowHeight = document.documentElement.clientHeight;

		scrollTop = window.pageYOffset;

		html.style.height = `${windowHeight}px`;
		html.style.overflow = 'hidden';

		body.style.height = `${windowHeight + scrollTop}px`;
		body.style.overflow = 'hidden';
		body.style.marginTop = `-${scrollTop}px`;
	},
	unlock() {
		html.setAttribute('style', '');
		body.setAttribute('style', '');
		window.scrollTo(window.pageXOffset, scrollTop);
	},
};

export default ScreenLock;
