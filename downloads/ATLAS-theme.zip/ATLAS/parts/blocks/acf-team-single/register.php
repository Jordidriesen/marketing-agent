<?php
// Register CPT Team if doesn't exists
custom_register_team_cpt();

// Register block
function init_block_team_single() {
    if ( ! function_exists( 'acf_register_block' ) ) {
        return;
    }

    acf_register_block( array(
        'name'              => 'team-single',
        'title'             => __( 'Einzelner Mitarbeiter / Team Member Single', 'ATLAS' ),
        'description'       => __( 'Team Member Single', 'ATLAS' ),
        'category'          => 'custom_blocks',
        'icon'              => 'id',
        'mode'              => 'auto',
        'keywords'          => array( 'team', 'team single', 'member', 'single', 'einzeln', 'mitarbeiter' ),
        'supports'          => array(
			'align' => false,
        ),
		'example'         => [
            'attributes' => [
                'mode' => 'auto',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-team-single/index.php',
    ));
}

add_action( 'acf/init', 'init_block_team_single' );