<?php
/**
 * Settings meta box on the content block edit screen.
 *
 * @package AtlasContentBlocks
 */

defined( 'ABSPATH' ) || exit;

class Atlas_CB_Meta_Box {

	const NONCE = 'atlas_cb_settings_nonce';

	public static function init() {
		add_action( 'add_meta_boxes_' . ATLAS_CB_POST_TYPE, array( __CLASS__, 'add' ) );
		add_action( 'save_post_' . ATLAS_CB_POST_TYPE, array( __CLASS__, 'save' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	public static function add() {
		add_meta_box(
			'atlas-cb-settings',
			__( 'Display settings', 'atlas-content-blocks' ),
			array( __CLASS__, 'render' ),
			ATLAS_CB_POST_TYPE,
			'normal',
			'high'
		);
	}

	/**
	 * @param string $hook Admin page hook.
	 */
	public static function assets( $hook ) {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) || ATLAS_CB_POST_TYPE !== get_current_screen()->post_type ) {
			return;
		}
		wp_enqueue_style( 'atlas-cb-admin', ATLAS_CB_URL . 'assets/css/admin.css', array(), ATLAS_CB_VERSION );
		wp_enqueue_script( 'atlas-cb-admin', ATLAS_CB_URL . 'assets/js/admin.js', array(), ATLAS_CB_VERSION, true );
	}

	/**
	 * @param WP_Post $post Block being edited.
	 */
	public static function render( $post ) {
		$s     = Atlas_CB_Settings::get( $post->ID );
		$popup = $s['popup'];

		wp_nonce_field( 'atlas_cb_save_' . $post->ID, self::NONCE );
		?>
		<div class="atlas-cb-settings" data-type="<?php echo esc_attr( $s['type'] ); ?>" data-location="<?php echo esc_attr( $s['location'] ); ?>">

			<fieldset class="atlas-cb-section">
				<legend><?php esc_html_e( 'Type', 'atlas-content-blocks' ); ?></legend>
				<label><input type="radio" name="atlas_cb[type]" value="hook" <?php checked( $s['type'], 'hook' ); ?>> <?php esc_html_e( 'Content block (placed at a location in the page)', 'atlas-content-blocks' ); ?></label><br>
				<label><input type="radio" name="atlas_cb[type]" value="popup" <?php checked( $s['type'], 'popup' ); ?>> <?php esc_html_e( 'Popup', 'atlas-content-blocks' ); ?></label>
			</fieldset>

			<fieldset class="atlas-cb-section atlas-cb-only-hook">
				<legend><?php esc_html_e( 'Placement', 'atlas-content-blocks' ); ?></legend>
				<p>
					<label for="atlas-cb-location"><?php esc_html_e( 'Location', 'atlas-content-blocks' ); ?></label><br>
					<select id="atlas-cb-location" name="atlas_cb[location]">
						<?php foreach ( Atlas_CB_Settings::locations() as $value => $label ) : ?>
							<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $s['location'], $value ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</p>
				<p class="atlas-cb-only-custom">
					<label for="atlas-cb-custom-hook"><?php esc_html_e( 'Hook name', 'atlas-content-blocks' ); ?></label><br>
					<input type="text" id="atlas-cb-custom-hook" class="regular-text code" name="atlas_cb[custom_hook]" value="<?php echo esc_attr( $s['custom_hook'] ); ?>" placeholder="my_theme_hook">
				</p>
				<p class="atlas-cb-not-manual">
					<label for="atlas-cb-priority"><?php esc_html_e( 'Order (lower runs first)', 'atlas-content-blocks' ); ?></label><br>
					<input type="number" id="atlas-cb-priority" class="small-text" name="atlas_cb[priority]" value="<?php echo esc_attr( $s['priority'] ); ?>" min="-1000" max="1000">
				</p>
			</fieldset>

			<fieldset class="atlas-cb-section atlas-cb-only-popup">
				<legend><?php esc_html_e( 'Popup', 'atlas-content-blocks' ); ?></legend>
				<p>
					<label for="atlas-cb-trigger"><?php esc_html_e( 'Opens', 'atlas-content-blocks' ); ?></label><br>
					<select id="atlas-cb-trigger" name="atlas_cb[popup][trigger]">
						<option value="click" <?php selected( $popup['trigger'], 'click' ); ?>><?php esc_html_e( 'Only on click', 'atlas-content-blocks' ); ?></option>
						<option value="load" <?php selected( $popup['trigger'], 'load' ); ?>><?php esc_html_e( 'After a delay on page load', 'atlas-content-blocks' ); ?></option>
						<option value="scroll" <?php selected( $popup['trigger'], 'scroll' ); ?>><?php esc_html_e( 'After scrolling part of the page', 'atlas-content-blocks' ); ?></option>
						<option value="exit" <?php selected( $popup['trigger'], 'exit' ); ?>><?php esc_html_e( 'When the visitor is about to leave (desktop)', 'atlas-content-blocks' ); ?></option>
					</select>
				</p>
				<p class="atlas-cb-only-trigger-load">
					<label for="atlas-cb-delay"><?php esc_html_e( 'Delay (seconds)', 'atlas-content-blocks' ); ?></label><br>
					<input type="number" id="atlas-cb-delay" class="small-text" name="atlas_cb[popup][delay]" value="<?php echo esc_attr( $popup['delay'] ); ?>" min="0" max="600">
				</p>
				<p class="atlas-cb-only-trigger-scroll">
					<label for="atlas-cb-scroll"><?php esc_html_e( 'Scrolled (% of the page)', 'atlas-content-blocks' ); ?></label><br>
					<input type="number" id="atlas-cb-scroll" class="small-text" name="atlas_cb[popup][scroll]" value="<?php echo esc_attr( $popup['scroll'] ); ?>" min="1" max="100">
				</p>
				<p>
					<label for="atlas-cb-selector"><?php esc_html_e( 'Also open on click of (CSS selector, optional)', 'atlas-content-blocks' ); ?></label><br>
					<input type="text" id="atlas-cb-selector" class="regular-text code" name="atlas_cb[popup][selector]" value="<?php echo esc_attr( $popup['selector'] ); ?>" placeholder="#ebookwfm, .open-demo-form">
					<span class="description">
						<?php
						printf(
							/* translators: 1: class name, 2: link target */
							esc_html__( 'Always opens from elements with the class %1$s or links to %2$s.', 'atlas-content-blocks' ),
							'<code>atlas-popup-' . (int) $post->ID . '</code>',
							'<code>#atlas-popup-' . (int) $post->ID . '</code>'
						);
						?>
					</span>
				</p>
				<p class="atlas-cb-not-trigger-click">
					<label for="atlas-cb-frequency"><?php esc_html_e( 'Show automatically', 'atlas-content-blocks' ); ?></label><br>
					<select id="atlas-cb-frequency" name="atlas_cb[popup][frequency]">
						<option value="always" <?php selected( $popup['frequency'], 'always' ); ?>><?php esc_html_e( 'On every page view', 'atlas-content-blocks' ); ?></option>
						<option value="session" <?php selected( $popup['frequency'], 'session' ); ?>><?php esc_html_e( 'Once per visit', 'atlas-content-blocks' ); ?></option>
						<option value="days" <?php selected( $popup['frequency'], 'days' ); ?>><?php esc_html_e( 'Once every number of days', 'atlas-content-blocks' ); ?></option>
					</select>
					<input type="number" class="small-text atlas-cb-only-frequency-days" name="atlas_cb[popup][days]" value="<?php echo esc_attr( $popup['days'] ); ?>" min="1" max="365" aria-label="<?php esc_attr_e( 'Days', 'atlas-content-blocks' ); ?>">
				</p>
				<p>
					<label for="atlas-cb-size"><?php esc_html_e( 'Size', 'atlas-content-blocks' ); ?></label><br>
					<select id="atlas-cb-size" name="atlas_cb[popup][size]">
						<option value="small" <?php selected( $popup['size'], 'small' ); ?>><?php esc_html_e( 'Small (420px)', 'atlas-content-blocks' ); ?></option>
						<option value="medium" <?php selected( $popup['size'], 'medium' ); ?>><?php esc_html_e( 'Medium (640px)', 'atlas-content-blocks' ); ?></option>
						<option value="large" <?php selected( $popup['size'], 'large' ); ?>><?php esc_html_e( 'Large (960px)', 'atlas-content-blocks' ); ?></option>
						<option value="full" <?php selected( $popup['size'], 'full' ); ?>><?php esc_html_e( 'Full screen', 'atlas-content-blocks' ); ?></option>
					</select>
				</p>
				<p>
					<label><input type="checkbox" name="atlas_cb[popup][close_overlay]" value="1" <?php checked( $popup['close_overlay'], 1 ); ?>> <?php esc_html_e( 'Close when the dark background is clicked', 'atlas-content-blocks' ); ?></label>
				</p>
				<p>
					<label for="atlas-cb-label"><?php esc_html_e( 'Name for screen readers', 'atlas-content-blocks' ); ?></label><br>
					<input type="text" id="atlas-cb-label" class="regular-text" name="atlas_cb[popup][label]" value="<?php echo esc_attr( $popup['label'] ); ?>" placeholder="<?php echo esc_attr( get_the_title( $post ) ); ?>">
					<span class="description"><?php esc_html_e( 'Defaults to the block title.', 'atlas-content-blocks' ); ?></span>
				</p>
			</fieldset>

			<fieldset class="atlas-cb-section atlas-cb-not-manual">
				<legend><?php esc_html_e( 'Display conditions', 'atlas-content-blocks' ); ?></legend>
				<p class="description"><?php esc_html_e( 'Shown where any "Show on" rule matches, unless a "Hide on" rule matches.', 'atlas-content-blocks' ); ?></p>
				<?php self::rules_table( 'include', __( 'Show on', 'atlas-content-blocks' ), $s['include'] ); ?>
				<?php self::rules_table( 'exclude', __( 'Hide on', 'atlas-content-blocks' ), $s['exclude'] ); ?>

				<p>
					<label for="atlas-cb-user"><?php esc_html_e( 'Visitors', 'atlas-content-blocks' ); ?></label><br>
					<select id="atlas-cb-user" name="atlas_cb[user]">
						<option value="all" <?php selected( $s['user'], 'all' ); ?>><?php esc_html_e( 'Everyone', 'atlas-content-blocks' ); ?></option>
						<option value="logged_out" <?php selected( $s['user'], 'logged_out' ); ?>><?php esc_html_e( 'Logged-out visitors only', 'atlas-content-blocks' ); ?></option>
						<option value="logged_in" <?php selected( $s['user'], 'logged_in' ); ?>><?php esc_html_e( 'Logged-in users only', 'atlas-content-blocks' ); ?></option>
					</select>
				</p>

				<p>
					<?php esc_html_e( 'Schedule (site time zone, optional)', 'atlas-content-blocks' ); ?><br>
					<label><?php esc_html_e( 'From', 'atlas-content-blocks' ); ?> <input type="datetime-local" name="atlas_cb[start]" value="<?php echo esc_attr( $s['start'] ); ?>"></label>
					<label><?php esc_html_e( 'until', 'atlas-content-blocks' ); ?> <input type="datetime-local" name="atlas_cb[end]" value="<?php echo esc_attr( $s['end'] ); ?>"></label>
				</p>
			</fieldset>

			<fieldset class="atlas-cb-section">
				<legend><?php esc_html_e( 'Hide on devices', 'atlas-content-blocks' ); ?></legend>
				<?php
				$devices = array(
					'mobile'  => __( 'Mobile (below 768px)', 'atlas-content-blocks' ),
					'tablet'  => __( 'Tablet (768 to 1199px)', 'atlas-content-blocks' ),
					'desktop' => __( 'Desktop (1200px and wider)', 'atlas-content-blocks' ),
				);
				foreach ( $devices as $device => $label ) :
					?>
					<label><input type="checkbox" name="atlas_cb[hide_on][]" value="<?php echo esc_attr( $device ); ?>" <?php checked( in_array( $device, $s['hide_on'], true ) ); ?>> <?php echo esc_html( $label ); ?></label><br>
				<?php endforeach; ?>
			</fieldset>

			<?php if ( 'publish' === $post->post_status ) : ?>
				<p class="atlas-cb-manual-hint">
					<?php esc_html_e( 'Place by hand with the "Content Block" block or:', 'atlas-content-blocks' ); ?>
					<code>[atlas_content_block id="<?php echo (int) $post->ID; ?>"]</code>
				</p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * @param string $key   include or exclude.
	 * @param string $label Table caption.
	 * @param array  $rules Stored rules.
	 */
	private static function rules_table( $key, $label, array $rules ) {
		$name = 'atlas_cb[' . $key . ']';
		?>
		<table class="atlas-cb-rules widefat striped" data-name="<?php echo esc_attr( $name ); ?>">
			<caption><?php echo esc_html( $label ); ?></caption>
			<tbody>
				<?php foreach ( $rules as $i => $rule ) : ?>
					<?php self::rule_row( $name, (string) $i, $rule ); ?>
				<?php endforeach; ?>
			</tbody>
			<tfoot>
				<tr><td colspan="3"><button type="button" class="button atlas-cb-add-rule"><?php esc_html_e( 'Add rule', 'atlas-content-blocks' ); ?></button></td></tr>
			</tfoot>
		</table>
		<template class="atlas-cb-rule-template"><?php self::rule_row( $name, '__i__', array( 'rule' => 'entire_site', 'value' => '' ) ); ?></template>
		<?php
	}

	/**
	 * @param string $name  Field name prefix.
	 * @param string $index Row index.
	 * @param array  $rule  Rule.
	 */
	private static function rule_row( $name, $index, array $rule ) {
		$value_rules = Atlas_CB_Settings::value_rules();
		$current     = $rule['rule'] ?? 'entire_site';
		?>
		<tr class="atlas-cb-rule">
			<td>
				<select name="<?php echo esc_attr( $name . '[' . $index . '][rule]' ); ?>" class="atlas-cb-rule-select" aria-label="<?php esc_attr_e( 'Rule', 'atlas-content-blocks' ); ?>">
					<?php foreach ( Atlas_CB_Settings::rule_choices() as $group => $choices ) : ?>
						<optgroup label="<?php echo esc_attr( $group ); ?>">
							<?php foreach ( $choices as $value => $label ) : ?>
								<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $current, $value ); ?> <?php echo isset( $value_rules[ $value ] ) ? 'data-placeholder="' . esc_attr( $value_rules[ $value ] ) . '"' : ''; ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</optgroup>
					<?php endforeach; ?>
				</select>
			</td>
			<td>
				<input type="text" class="regular-text atlas-cb-rule-value" name="<?php echo esc_attr( $name . '[' . $index . '][value]' ); ?>" value="<?php echo esc_attr( $rule['value'] ?? '' ); ?>" aria-label="<?php esc_attr_e( 'Value', 'atlas-content-blocks' ); ?>">
			</td>
			<td class="atlas-cb-rule-actions">
				<button type="button" class="button-link atlas-cb-remove-rule"><?php esc_html_e( 'Remove', 'atlas-content-blocks' ); ?></button>
			</td>
		</tr>
		<?php
	}

	/**
	 * @param int     $post_id Block ID.
	 * @param WP_Post $post    Block.
	 */
	public static function save( $post_id, $post ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( wp_is_post_revision( $post_id ) || ! isset( $_POST[ self::NONCE ], $_POST['atlas_cb'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE ] ) ), 'atlas_cb_save_' . $post_id ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$raw = wp_unslash( $_POST['atlas_cb'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitised field by field below.
		if ( ! is_array( $raw ) ) {
			return;
		}

		// An unchecked checkbox sends nothing.
		if ( ! isset( $raw['popup']['close_overlay'] ) ) {
			$raw['popup']['close_overlay'] = 0;
		}

		update_post_meta( $post_id, ATLAS_CB_META, Atlas_CB_Settings::sanitize( $raw ) );
		Atlas_CB_Settings::flush_index();
	}
}
