/**
 * ATLAS Content Blocks: "Content Block" editor block.
 * Plain script (no build step) using the WordPress globals.
 */
(function (wp) {
	'use strict';

	var el = wp.element.createElement;
	var __ = wp.i18n.__;
	var useSelect = wp.data.useSelect;
	var InspectorControls = wp.blockEditor.InspectorControls;
	var useBlockProps = wp.blockEditor.useBlockProps;
	var PanelBody = wp.components.PanelBody;
	var SelectControl = wp.components.SelectControl;
	var ToggleControl = wp.components.ToggleControl;
	var Placeholder = wp.components.Placeholder;
	var Spinner = wp.components.Spinner;
	var ServerSideRender = wp.serverSideRender;

	var useBlocks = function () {
		return useSelect(function (select) {
			return select('core').getEntityRecords('postType', 'atlas_block', {
				per_page: 100,
				status: 'publish',
				orderby: 'title',
				order: 'asc',
				_fields: 'id,title'
			});
		}, []);
	};

	var options = function (blocks) {
		var list = [{ value: 0, label: __('Choose a content block', 'atlas-content-blocks') }];
		(blocks || []).forEach(function (block) {
			list.push({
				value: block.id,
				label: (block.title && block.title.rendered) || ('#' + block.id)
			});
		});
		return list;
	};

	wp.blocks.registerBlockType('atlas/content-block', {
		apiVersion: 3,
		title: __('Content Block', 'atlas-content-blocks'),
		description: __('Places one of the site\'s content blocks or popups here.', 'atlas-content-blocks'),
		category: 'widgets',
		icon: 'screenoptions',
		keywords: [__('reusable', 'atlas-content-blocks'), __('popup', 'atlas-content-blocks')],
		attributes: {
			id: { type: 'number', default: 0 },
			conditions: { type: 'boolean', default: false }
		},
		supports: { html: false },

		edit: function (props) {
			var attributes = props.attributes;
			var blocks = useBlocks();
			var blockProps = useBlockProps();

			var select = el(SelectControl, {
				label: __('Content block', 'atlas-content-blocks'),
				value: attributes.id,
				options: options(blocks),
				onChange: function (value) {
					props.setAttributes({ id: parseInt(value, 10) || 0 });
				},
				__nextHasNoMarginBottom: true
			});

			var inspector = el(
				InspectorControls,
				null,
				el(
					PanelBody,
					{ title: __('Content block', 'atlas-content-blocks') },
					select,
					el(ToggleControl, {
						label: __('Apply its display conditions', 'atlas-content-blocks'),
						help: __('Off: always shown here. On: only where its own conditions match.', 'atlas-content-blocks'),
						checked: attributes.conditions,
						onChange: function (value) {
							props.setAttributes({ conditions: value });
						},
						__nextHasNoMarginBottom: true
					})
				)
			);

			var body;
			if (blocks === null) {
				body = el(Placeholder, { icon: 'screenoptions', label: __('Content Block', 'atlas-content-blocks') }, el(Spinner));
			} else if (!attributes.id) {
				body = el(Placeholder, { icon: 'screenoptions', label: __('Content Block', 'atlas-content-blocks') }, select);
			} else {
				body = el(ServerSideRender, {
					block: 'atlas/content-block',
					attributes: { id: attributes.id, conditions: false }
				});
			}

			return el('div', blockProps, inspector, body);
		},

		save: function () {
			return null;
		}
	});
})(window.wp);
