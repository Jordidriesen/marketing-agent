/**
 * ATLAS Content Blocks: settings meta box behaviour.
 * Shows the fields that apply to the chosen type, trigger, structure and
 * conditions mode, shows the value fields each condition rule uses, and adds
 * and removes rule rows and groups. Rules that miss a required value are
 * dropped on save.
 */
(function () {
	'use strict';

	var root = document.querySelector('.atlas-cb-settings');
	if (!root) {
		return;
	}

	var counter = Date.now();

	var value = function (selector, fallback) {
		var field = root.querySelector(selector);
		if (!field) {
			return fallback;
		}
		if (field.type === 'checkbox') {
			return field.checked ? '1' : '0';
		}
		return field.value;
	};

	// Mirror the current choices in data attributes; admin.css shows and hides fields from them.
	var sync = function () {
		var type = root.querySelector('input[name="atlas_cb[type]"]:checked');
		var mode = root.querySelector('input[name="atlas_cb[conditions][mode]"]:checked');

		root.dataset.type = type ? type.value : 'hook';
		root.dataset.mode = mode ? mode.value : 'basic';
		root.dataset.trigger = value('#atlas-cb-trigger', 'click');
		root.dataset.relaunch = value('#atlas-cb-relaunch', 'always');
		root.dataset.size = value('#atlas-cb-size', 'medium');
		root.dataset.structure = value('#atlas-cb-structure', 'default');
		root.dataset.backdrop = value('input[type="checkbox"][name="atlas_cb[popup][backdrop]"]', '1');
	};

	// Show only the value fields the chosen rule uses.
	var syncRule = function (row) {
		var select = row.querySelector('.atlas-cb-rule-select');
		var option = select.options[select.selectedIndex];
		var fields = option ? (option.getAttribute('data-fields') || '').split(' ') : [];

		row.querySelectorAll('.atlas-cb-field').forEach(function (field) {
			field.hidden = fields.indexOf(field.getAttribute('data-field')) === -1;
		});
	};

	var template = function (selector) {
		var element = root.querySelector(selector);
		return element ? element.innerHTML : '';
	};

	var addRule = function (table) {
		var negation = table.getAttribute('data-negation') === '1' ? '1' : '0';
		var html = template('.atlas-cb-rule-template[data-negation="' + negation + '"]')
			.replace(/__name__/g, table.getAttribute('data-name'))
			.replace(/__i__/g, String(counter++));
		var body = table.querySelector('tbody');
		body.insertAdjacentHTML('beforeend', html);
		var row = body.lastElementChild;
		syncRule(row);
		return row;
	};

	root.addEventListener('change', function (event) {
		var target = event.target;

		if (target.classList.contains('atlas-cb-rule-select')) {
			syncRule(target.closest('.atlas-cb-rule'));
		}

		// "Default" colour: a disabled colour input sends nothing, which saves as the default.
		if (target.classList.contains('atlas-cb-colour-default')) {
			var input = document.getElementById(target.getAttribute('data-target'));
			if (input) {
				input.disabled = target.checked;
			}
		}

		sync();
	});

	root.addEventListener('click', function (event) {
		var target = event.target;

		if (target.classList.contains('atlas-cb-add-rule')) {
			addRule(target.closest('.atlas-cb-rules')).querySelector('.atlas-cb-rule-select').focus();
		}

		if (target.classList.contains('atlas-cb-remove-rule')) {
			var row = target.closest('.atlas-cb-rule');
			var table = row.closest('.atlas-cb-rules');
			row.remove();
			table.querySelector('.atlas-cb-add-rule').focus();
		}

		if (target.classList.contains('atlas-cb-add-group')) {
			var groups = root.querySelector('.atlas-cb-groups');
			var html = template('.atlas-cb-group-template').replace(/__g__/g, String(counter++));
			groups.insertAdjacentHTML('beforeend', html);
			var group = groups.lastElementChild;
			group.querySelectorAll('.atlas-cb-rule').forEach(syncRule);
			group.querySelector('.atlas-cb-rule-select').focus();
		}

		if (target.classList.contains('atlas-cb-remove-group')) {
			target.closest('.atlas-cb-group').remove();
			root.querySelector('.atlas-cb-add-group').focus();
		}
	});

	root.querySelectorAll('.atlas-cb-groups .atlas-cb-rule, .atlas-cb-only-mode-basic .atlas-cb-rule').forEach(syncRule);
	sync();
})();
