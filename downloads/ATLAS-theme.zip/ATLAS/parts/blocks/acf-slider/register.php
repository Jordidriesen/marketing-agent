<?php
function init_block_gallery_slider() {
    if ( ! function_exists( 'acf_register_block' ) ) {
        return;
    }

    acf_register_block( array(
        'name'              => 'slider',
        'title'             => __( 'Slideshow / Slider', 'ATLAS' ),
        'description'       => __( 'Slider', 'ATLAS' ),
        'category'          => 'custom_blocks',
        'icon'              => 'slides',
        'mode'              => 'auto',
        'keywords'          => array( 'gallery', 'slider', 'images' ),
        'align'             => 'full',
        'supports'          => array(
			'align' => false,
        ),
		'example'         => [
            'attributes' => [
                'mode' => 'auto',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-slider/index.php',
        'enqueue_assets'  => function () {
			wp_enqueue_script(
				'ATLAS/acf-slider',
                get_template_directory_uri() . '/parts/blocks/acf-slider/index.min.js',
                [ 'splide_script' ],
                false,
                array(
                    'in_footer' => true,
                    'strategy'  => 'defer',
                )
			);
		}
    ));
}

add_action( 'acf/init', 'init_block_gallery_slider' );