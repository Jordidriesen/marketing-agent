<?php
$block_object = new Block( $block );
$name = $block_object->block_name();
$img_id = get_field('case_teaser_image');
$label = get_field('case_teaser_label');
$title = get_field('case_teaser_title');
$content = get_field('case_teaser_content');
$link = get_field('case_teaser_link');
$image_full_width = get_field('case_teaser_image_full_width');
$img = wp_get_attachment_image($img_id, 'full', false, 'data-object-fit');
$img_url = wp_get_attachment_image_url($img_id, 'full', false, 'data-object-fit');

$class = ( $image_full_width || empty($img)) ? $block_object->block_class()  . ' block-case-teaser--full' : $block_object->block_class();

loadAcfBlockPreviewImage(__DIR__);
?>

<div class="<?php echo $class; ?>">
	<?php echo loadStyles(__DIR__, $name); ?>
	<div class="block-case-teaser__row">
	<?php if (!empty($img)) : 
			$url = $img_url;
			$ext = pathinfo( $url, PATHINFO_EXTENSION );
		?>
		<div class="block-case-teaser__img-wrapper">
		<?php 
			if ( $ext == 'svg' ):
			echo get_svg( $img_id );
			else: ?>
			<?php echo $img; ?>
		<?php endif; ?>

		<?php if (!empty($title) && !$image_full_width ) : ?>
			<h3 class="block-case-teaser__title"><?php echo $title; ?></h3>
		<?php endif; ?>

		</div>
	<?php endif; ?>
		<div class="block-case-teaser__content-wrapper">
		<?php if (!empty($label)) : ?>
			<span class="block-case-teaser__label"><?php echo $label; ?></span>
		<?php endif; ?>
		<?php if ((!empty($title) && $image_full_width) || (!empty($title) && empty($img_id))) : ?>
			<h3 class="block-case-teaser__title"><?php echo $title; ?></h3>
		<?php endif; ?>
		<?php if (!empty($content)) : ?>
			<div class="block-case-teaser__content"><?php echo $content; ?></div>
		<?php endif; ?>

		<?php 
			$button_style = get_field('case_teaser_button_style');

			if( $button_style != 'download' && !empty($link) ) :
				$link_target = !empty($link['target']) ? $link['target'] : '_self';
				$link_title = !empty($link['title']) ? $link['title'] : 'Button';
				$link_url = !empty($link['url']) ? $link['url'] : '#';
				$name = 'core-button';
		?>
				<?php loadStylesDep('blocks/core-button', $name); ?>

				<?php if( $button_style == 'link-only' ) : ?>
				<div class="wp-block-button is-style-link-only"><a class="wp-block-button__link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a></div>
				<?php elseif( $button_style == 'full-width' ) : ?>
				<div class="wp-block-button full-width"><a class="wp-block-button__link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a></div>
				<?php else : ?>
				<div class="wp-block-button"><a class="wp-block-button__link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a></div>
				<?php endif; ?>
		<?php
			else :
				$download = get_field('case_teaser_download');
				$download_title = get_field('case_teaser_download_title');
				$download_title = !empty($download_title) ? $download_title : __('Download Datasheet', 'ATLAS');
				if( !empty($download) ) :
		?>
					<div class="wp-block-button block-case-teaser__download"><a class="wp-block-button__link" href="<?php echo esc_url( $download ); ?>" target="__BLANK"><?php echo esc_html( $download_title ); ?></a></div>
				<?php endif; ?>
		<?php endif; ?>

		</div>
	</div>

</div>