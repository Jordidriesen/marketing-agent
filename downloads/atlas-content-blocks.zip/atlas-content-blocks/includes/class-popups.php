<?php
/**
 * Popups: printed as native <dialog> elements in the footer and opened by
 * assets/js/popups.js.
 *
 * Any element matching `.atlas-popup-{ID}`, `a[href="#atlas-popup-{ID}"]` or the
 * popup's own trigger selector opens it on click.
 *
 * @package AtlasContentBlocks
 */

defined( 'ABSPATH' ) || exit;

class Atlas_CB_Popups {

	/** @var array Popups placed manually (block or shortcode): ID => settings. */
	private static $manual = array();

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
		// Before footer scripts print (priority 20), so assets enqueued by popup content still load.
		add_action( 'wp_footer', array( __CLASS__, 'print_popups' ), 5 );
	}

	public static function register_assets() {
		wp_register_style( 'atlas-cb-popups', ATLAS_CB_URL . 'assets/css/popups.css', array(), ATLAS_CB_VERSION );
		wp_register_script(
			'atlas-cb-popups',
			ATLAS_CB_URL . 'assets/js/popups.js',
			array(),
			ATLAS_CB_VERSION,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);

		if ( Atlas_CB_Renderer::popups() ) {
			wp_enqueue_style( 'atlas-cb-popups' );
			wp_enqueue_script( 'atlas-cb-popups' );
		} elseif ( self::counts_pages() ) {
			// The "after X pages" trigger needs every page view counted.
			wp_enqueue_script( 'atlas-cb-popups' );
		}
	}

	/**
	 * Whether any published popup opens after a number of page views.
	 *
	 * @return bool
	 */
	private static function counts_pages() {
		if ( ! Atlas_CB_Renderer::is_front_request() ) {
			return false;
		}
		foreach ( Atlas_CB_Settings::index() as $settings ) {
			if ( 'popup' === $settings['type'] && 'pages' === $settings['popup']['trigger'] ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Print a popup on this page whatever its conditions, because it was placed
	 * by hand.
	 *
	 * @param int   $id       Popup ID.
	 * @param array $settings Popup settings.
	 */
	public static function add( $id, array $settings ) {
		self::$manual[ $id ] = $settings;
		wp_enqueue_style( 'atlas-cb-popups' );
		wp_enqueue_script( 'atlas-cb-popups' );
	}

	public static function print_popups() {
		$popups = Atlas_CB_Renderer::popups() + self::$manual;

		foreach ( $popups as $id => $settings ) {
			echo self::markup( $id, $settings ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in markup().
		}
	}

	/**
	 * Behaviour passed to the script.
	 *
	 * @param int   $id       Popup ID.
	 * @param array $settings Popup settings.
	 *
	 * @return array
	 */
	private static function config( $id, array $settings ) {
		$p = $settings['popup'];

		$units = array(
			'minutes' => MINUTE_IN_SECONDS,
			'hours'   => HOUR_IN_SECONDS,
			'days'    => DAY_IN_SECONDS,
		);

		return array(
			'id'            => (int) $id,
			'trigger'       => $p['trigger'],
			'selector'      => $p['selector'],
			'delay'         => (int) $p['delay'],
			'scroll'        => (int) $p['scroll'],
			'scrollUnit'    => $p['scroll_unit'],
			'scrollElement' => $p['scroll_element'],
			'inactivity'    => (int) $p['inactivity'],
			'pages'         => (int) $p['pages'],
			'relaunch'      => $p['relaunch'],
			'interval'      => (int) $p['relaunch_amount'] * $units[ $p['relaunch_unit'] ],
			'closeOverlay'  => (bool) $p['close_overlay'],
			'closeEsc'      => (bool) $p['close_esc'],
			'closeSubmit'   => (bool) $p['close_submit'],
			'closeSelector' => $p['close_selector'],
			'closeDelay'    => (int) $p['close_delay'],
			'closeScroll'   => (bool) $p['close_scroll'],
			'animation'     => $p['animation'],
			'onDemand'      => (bool) $p['on_demand'],
			'scrollLock'    => (bool) $p['scroll_lock'],
			'modal'         => (bool) $p['focus_trap'],
			'stopMedia'     => (bool) $p['stop_media'],
			'hideOn'        => array_values( $settings['hide_on'] ),
		);
	}

	/**
	 * Per-popup design values as CSS custom properties. Every value is
	 * sanitised to a number, a length or a hex colour.
	 *
	 * @param array $p Popup settings.
	 *
	 * @return string
	 */
	private static function style( array $p ) {
		$vars = array(
			'--atlas-popup-offset'  => (int) $p['offset'] . 'px',
			'--atlas-popup-padding' => (int) $p['padding'] . 'px',
			'--atlas-popup-radius'  => (int) $p['radius'] . 'px',
		);

		if ( 'custom' === $p['size'] && '' !== $p['width'] ) {
			$vars['--atlas-popup-width'] = $p['width'];
		}
		if ( '' !== $p['max_height'] ) {
			$vars['--atlas-popup-max-height'] = $p['max_height'];
		}
		if ( '' !== $p['background'] ) {
			$vars['--atlas-popup-bg'] = $p['background'];
		}
		if ( '' !== $p['close_color'] ) {
			$vars['--atlas-popup-close-color'] = $p['close_color'];
		}
		if ( '' !== $p['close_bg'] ) {
			$vars['--atlas-popup-close-bg'] = $p['close_bg'];
		}
		if ( $p['backdrop'] ) {
			$vars['--atlas-popup-backdrop'] = self::rgba( $p['backdrop_color'], (int) $p['backdrop_alpha'] );
			$vars['--atlas-popup-blur']     = (int) $p['backdrop_blur'] . 'px';
		}

		$style = '';
		foreach ( $vars as $name => $value ) {
			$style .= $name . ':' . $value . ';';
		}
		return $style;
	}

	/**
	 * @param string $hex   #rrggbb or #rgb.
	 * @param int    $alpha 0 to 100.
	 *
	 * @return string
	 */
	private static function rgba( $hex, $alpha ) {
		$hex = ltrim( (string) sanitize_hex_color( $hex ), '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( 6 !== strlen( $hex ) ) {
			$hex = '000000';
		}
		return sprintf( 'rgba(%d,%d,%d,%s)', hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ), rtrim( rtrim( number_format( max( 0, min( 100, $alpha ) ) / 100, 2, '.', '' ), '0' ), '.' ) );
	}

	/**
	 * @param int   $id       Popup ID.
	 * @param array $settings Popup settings.
	 *
	 * @return string
	 */
	private static function markup( $id, array $settings ) {
		$content = Atlas_CB_Renderer::render( $id, $settings, false );
		if ( '' === trim( $content ) ) {
			return '';
		}

		$p     = $settings['popup'];
		$label = '' !== $p['label'] ? $p['label'] : get_the_title( $id );

		$classes = array(
			'atlas-popup',
			'atlas-popup--' . $p['size'],
			'atlas-popup--pos-' . $p['position'],
			'atlas-popup--anim-' . $p['animation'],
			'atlas-popup--overflow-' . $p['overflow'],
			'atlas-popup--close-' . $p['close_position'],
		);
		if ( $p['shadow'] ) {
			$classes[] = 'atlas-popup--shadow';
		}
		if ( ! $p['backdrop'] ) {
			$classes[] = 'atlas-popup--no-backdrop';
		}

		if ( $p['on_demand'] ) {
			// Inert until the first open: the script clones it into the popup.
			$content = '<template class="atlas-popup__template">' . $content . '</template>';
		}

		$close = '<svg width="20" height="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M4 4l12 12M16 4L4 16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';

		return sprintf(
			'<dialog id="atlas-popup-%1$d" class="%2$s" aria-label="%3$s" style="%4$s" data-atlas-popup="%5$s">'
				. '<button type="button" class="atlas-popup__close" aria-label="%6$s">%7$s</button>'
				. '<div class="atlas-popup__box">'
				. '<div class="atlas-popup__content">%8$s</div>'
				. '</div>'
				. "</dialog>\n",
			(int) $id,
			esc_attr( implode( ' ', $classes ) ),
			esc_attr( $label ),
			esc_attr( self::style( $p ) ),
			esc_attr( wp_json_encode( self::config( $id, $settings ) ) ),
			esc_attr__( 'Close', 'atlas-content-blocks' ),
			$close,
			$content
		);
	}
}
