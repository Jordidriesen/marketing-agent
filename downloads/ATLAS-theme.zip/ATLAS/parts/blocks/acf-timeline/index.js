import { Slider } from 'lib/sliders';

const initTimelineSlider = () => {
    
    [...document.querySelectorAll(".timeline_list")].forEach( block => {
            return new Slider({
                elem: block,
                num: 3,
                tabNum: 1,
                mobNum: 1,
                infinite: false,
                arrows : true,
                dots: false,
                adaptiveHeight: true,
                slideSpeed:0,
                centerMode: true,
                centerPadding: '24px',
            });
        }
    );

};

initTimelineSlider();

if ( window.acf ) {
    window.acf.addAction( 'render_block_preview/type=timeline', initTimelineSlider);
}
