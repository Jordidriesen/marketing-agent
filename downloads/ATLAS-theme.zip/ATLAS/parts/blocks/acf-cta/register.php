<?php
function init_block_cta() {

	if ( ! function_exists( 'acf_register_block' ) ) {
		return;
	}

	acf_register_block( array(
		'name'            => 'cta',
		'title'           => __( 'Call-To-Action / CTA' ),
		'description'     => __( 'Custom cta block' ),
		'category'        => 'custom_blocks',
		'icon'            => 'media-interactive',
		'keywords'        => array( 'cta', 'full width', 'call', 'action' ),
		'mode'            => 'preview',
		'align_content'	  => 'center right',	
		'align_text'	  => 'center',		
		'example'         => [
            'attributes' => [
                'mode' => 'auto',
            ]
        ],
        'align'             => 'full',
        'supports'          => array(
			'align' => false,
			'align_text' => true,
			'align_content' => 'matrix', 
			'mode' => false,
			'jsx' => true
        ),
		'render_template' => get_template_directory() . '/parts/blocks/acf-cta/index.php',
		'enqueue_assets'  => function () {
			wp_enqueue_script(
				'ATLAS/acf-cta',
                get_template_directory_uri() . ( is_IE() ? '/parts/blocks/acf-cta/index.ie.js' : '/parts/blocks/acf-cta/index.min.js' ),
                [],
                false,
                array(
                    'in_footer' => true,
                    'strategy'  => 'defer',
                )
			);
		}
	) );
}
add_action( 'acf/init', 'init_block_cta' );