<?php
/**
 * Block
 * This class collects Block functionalities.
 */
class Block {
	private $_block = null;

	public function __construct( $block ) {
		$this->_block = $block;
	}

	/**
	 * Generate Block class
	 *
	 * @return string
	 */
	public function block_class( $custom = '' ) {
		$class = 'acf-block';
        $class .= ' block-' . str_replace( 'acf/', '', $this->_block['name'] );

		if ( ! empty( $custom ) ) {
			$class .= ' ' . $custom;
		}

		if ( isset( $this->_block['align'] ) ) {
			$class .= ' align' . $this->_block['align'];
		}

		if ( isset( $this->_block['className'] ) ) {
			$class .= ' ' . $this->_block['className'];
		}

		return $class;
	}
	/**
	 * Generate Block Container class
	 *
	 * @return string
	 */
	public function container_class( $custom = '' ) {
		$class = "container";
		if ( ! empty( $custom ) ) {
			$class .= ' ' . $custom;
		}

		if ( isset( $this->_block['align'] ) ) {
			$class .= ' container--' . $this->_block['align'];
		}
		
		return $class;
	}

    public function block_name() {
        return $this->_block['name'];
    }
}
