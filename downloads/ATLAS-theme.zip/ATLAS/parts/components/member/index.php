<?php
if ( isset($id) ):
	$img = get_the_post_thumbnail($id,'large');
	$title = get_the_title($id);
	$short_desc = get_field('team_description', $id);
	$content = get_post_field('post_content', $id);
?>
<div class="single-member">
	<?php loadStyles(__DIR__, 'member'); ?>
	<div class="single-member__wrapper">
	<?php if (!empty($img)) : ?>
		<figure class="single-member__img"><?php echo $img; ?></figure>
	<?php endif; ?>
		<div class="single-member__content">
			<span class="single-member__title h4"><?php echo $title; ?></span>
		<?php if (!empty($short_desc)) : ?>
			<span class="single-member__details single-member__details-desc"><?php echo $short_desc; ?></span>
		<?php endif; ?>		
		
		<?php if (!empty($content)) : ?>
			<div class="single-member__details single-member__details-content">
				<?php echo apply_filters('the_content', $content); ?>
			</div>
		<?php endif; ?>
		
		</div>
	</div>
</div>
<?php
endif;