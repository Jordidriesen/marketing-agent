<?php
/**
 * Evaluates a block's display conditions against the current request.
 *
 * Basic mode: include rules are grouped by kind (page, date and time,
 * request, visitor, language). The block shows when, for every kind that has
 * include rules, at least one of them matches, and no exclude rule matches.
 * So "Entire website" + "Logged in" + "User role: Editor" means logged-in
 * visitors with the Editor role, anywhere on the site.
 *
 * Advanced mode: groups of rules. The block shows when every rule of at least
 * one group matches (OR between groups, AND inside a group). Each rule can be
 * negated ("is not").
 *
 * With no rules at all, a block shows nowhere. Device visibility is handled
 * in CSS, so it works with page caching.
 *
 * @package AtlasContentBlocks
 */

defined( 'ABSPATH' ) || exit;

class Atlas_CB_Conditions {

	/**
	 * @param array $settings Block settings.
	 *
	 * @return bool
	 */
	public static function matches( array $settings ) {
		$conditions = $settings['conditions'];

		$show = 'advanced' === $conditions['mode']
			? self::groups_match( $conditions['groups'] )
			: self::basic_match( $conditions['include'], $conditions['exclude'] );

		return $show && (bool) apply_filters( 'atlas_cb_matches', true, $settings );
	}

	/**
	 * @param array $include Include rules.
	 * @param array $exclude Exclude rules.
	 *
	 * @return bool
	 */
	private static function basic_match( array $include, array $exclude ) {
		if ( ! $include ) {
			return false;
		}

		$types      = Atlas_CB_Settings::rule_types();
		$categories = array();

		foreach ( $include as $rule ) {
			$category = $types[ $rule['rule'] ]['category'] ?? 'page';
			if ( ! isset( $categories[ $category ] ) ) {
				$categories[ $category ] = false;
			}
			if ( ! $categories[ $category ] && self::rule_matches( $rule ) ) {
				$categories[ $category ] = true;
			}
		}

		if ( in_array( false, $categories, true ) ) {
			return false;
		}

		foreach ( $exclude as $rule ) {
			if ( self::rule_matches( $rule ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * @param array $groups Groups of rules.
	 *
	 * @return bool
	 */
	private static function groups_match( array $groups ) {
		foreach ( $groups as $group ) {
			$rules = $group['rules'] ?? array();
			if ( ! $rules ) {
				continue;
			}

			$all = true;
			foreach ( $rules as $rule ) {
				$result = self::rule_matches( $rule );
				if ( ! empty( $rule['not'] ) ) {
					$result = ! $result;
				}
				if ( ! $result ) {
					$all = false;
					break;
				}
			}

			if ( $all ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether one rule matches the current request (ignoring its "not" flag).
	 *
	 * @param array $rule Sanitised rule row.
	 *
	 * @return bool
	 */
	public static function rule_matches( array $rule ) {
		$result = self::evaluate( $rule );

		/**
		 * Filter the result of one rule, for example to support a custom rule.
		 *
		 * @param bool  $result Whether the rule matches.
		 * @param array $rule   Rule row.
		 */
		return (bool) apply_filters( 'atlas_cb_rule_matches', $result, $rule );
	}

	/**
	 * @param array $rule Rule row.
	 *
	 * @return bool
	 */
	private static function evaluate( array $rule ) {
		$name = (string) ( $rule['rule'] ?? '' );

		list( $kind, $arg ) = array_pad( explode( ':', $name, 2 ), 2, '' );

		switch ( $kind ) {
			case 'entire_site':
				return true;

			case 'front_page':
				return is_front_page();

			case 'posts_page':
				return is_home();

			case 'search':
				return is_search();

			case 'not_found':
				return is_404();

			case 'privacy_page':
				$privacy = (int) get_option( 'wp_page_for_privacy_policy' );
				return $privacy && is_page( self::translate_post_id( $privacy ) );

			case 'author_archive':
				$ids = wp_parse_id_list( $rule['ids'] ?? '' );
				return $ids ? is_author( $ids ) : is_author();

			case 'category_archive':
				return is_category();

			case 'tag_archive':
				return is_tag();

			case 'singular':
				return 'any' === $arg ? is_singular() : is_singular( $arg );

			case 'archive':
				if ( 'any' === $arg ) {
					return is_archive() || is_home();
				}
				if ( 'post' === $arg ) {
					return is_home() || is_category() || is_tag() || is_date() || is_author();
				}
				return is_post_type_archive( $arg ) || ( is_tax() && in_array( get_queried_object()->taxonomy ?? '', get_object_taxonomies( $arg ), true ) );

			case 'post_ids':
				return self::matches_post_ids( $rule['ids'] ?? '' );

			case 'child_of':
				return self::matches_child_of( $rule['ids'] ?? '' );

			case 'post_term':
				return self::matches_post_term( $rule['taxonomy'] ?? '', $rule['terms'] ?? '' );

			case 'post_author':
				return is_singular() && in_array( (int) get_post_field( 'post_author', get_queried_object_id() ), wp_parse_id_list( $rule['ids'] ?? '' ), true );

			case 'term_archive':
				return self::matches_term_archive( $rule['taxonomy'] ?? '', $rule['terms'] ?? '' );

			case 'page_template':
				return self::matches_template( $rule['value'] ?? '' );

			case 'date_range':
				return self::matches_date_range( $rule['start'] ?? '', $rule['end'] ?? '' );

			case 'recurring':
				return self::matches_recurring( (array) ( $rule['days'] ?? array() ), $rule['from'] ?? '', $rule['to'] ?? '' );

			case 'url':
				return self::matches_url( $rule['operator'] ?? 'contains', $rule['value'] ?? '' );

			case 'referer':
				$referer = isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '';
				return '' !== $referer && self::compare( $referer, $rule['operator'] ?? 'contains', $rule['value'] ?? '' );

			case 'cookie':
				return self::matches_cookie( $rule['name'] ?? '', $rule['operator'] ?? 'contains', $rule['value'] ?? '' );

			case 'logged_in':
				return is_user_logged_in();

			case 'logged_out':
				return ! is_user_logged_in();

			case 'user_role':
				$user = wp_get_current_user();
				return $user->exists() && in_array( (string) ( $rule['role'] ?? '' ), (array) $user->roles, true );

			case 'language':
				// Without WPML the filter returns the default (null), so the rule never matches.
				$current = apply_filters( 'wpml_current_language', null );
				return is_string( $current ) && '' !== $current && $current === ( $rule['language'] ?? '' );
		}

		return false;
	}

	/**
	 * The ID's translation in the current language (WPML), or the ID itself.
	 *
	 * @param int $id Post ID.
	 *
	 * @return int
	 */
	private static function translate_post_id( $id ) {
		$type = get_post_type( $id );
		return $type ? (int) apply_filters( 'wpml_object_id', $id, $type, true ) : (int) $id;
	}

	/**
	 * IDs entered in one language also match their translations (WPML).
	 *
	 * @param string $value Comma-separated IDs.
	 *
	 * @return bool
	 */
	private static function matches_post_ids( $value ) {
		if ( ! is_singular() && ! is_home() ) {
			return false;
		}

		$current = get_queried_object_id();
		if ( ! $current ) {
			return false;
		}

		foreach ( wp_parse_id_list( $value ) as $id ) {
			if ( $current === $id || $current === self::translate_post_id( $id ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Pages anywhere below one of the given parents (not the parents themselves).
	 *
	 * @param string $value Comma-separated parent IDs.
	 *
	 * @return bool
	 */
	private static function matches_child_of( $value ) {
		if ( ! is_singular() ) {
			return false;
		}

		$ancestors = array_map( 'intval', get_post_ancestors( get_queried_object_id() ) );

		foreach ( wp_parse_id_list( $value ) as $parent ) {
			if ( in_array( self::translate_post_id( $parent ), $ancestors, true ) || in_array( $parent, $ancestors, true ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Term IDs (translated with WPML) and slugs from a comma list.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @param string $terms    Comma-separated term IDs or slugs.
	 *
	 * @return array
	 */
	private static function term_list( $taxonomy, $terms ) {
		$list = array();
		foreach ( array_filter( array_map( 'trim', explode( ',', (string) $terms ) ), 'strlen' ) as $term ) {
			if ( ctype_digit( $term ) ) {
				$list[] = (int) apply_filters( 'wpml_object_id', (int) $term, $taxonomy, true );
				$list[] = (int) $term;
			} else {
				$list[] = $term;
			}
		}
		return array_unique( $list, SORT_REGULAR );
	}

	/**
	 * A single post that has one of the terms.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @param string $terms    Comma-separated term IDs or slugs.
	 *
	 * @return bool
	 */
	private static function matches_post_term( $taxonomy, $terms ) {
		if ( ! is_singular() || ! taxonomy_exists( $taxonomy ) ) {
			return false;
		}
		$list = self::term_list( $taxonomy, $terms );
		return $list && has_term( $list, $taxonomy, get_queried_object_id() );
	}

	/**
	 * The archive of one of the terms, or of any term of the taxonomy.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @param string $terms    Comma-separated term IDs or slugs, or empty.
	 *
	 * @return bool
	 */
	private static function matches_term_archive( $taxonomy, $terms ) {
		if ( ! ( is_category() || is_tag() || is_tax() ) ) {
			return false;
		}

		$term = get_queried_object();
		if ( ! $term instanceof WP_Term || $term->taxonomy !== $taxonomy ) {
			return false;
		}

		$list = self::term_list( $taxonomy, $terms );
		return ! $list || in_array( (int) $term->term_id, $list, true ) || in_array( $term->slug, $list, true );
	}

	/**
	 * @param string $value Template file relative to the theme, or "default".
	 *
	 * @return bool
	 */
	private static function matches_template( $value ) {
		if ( ! is_singular() ) {
			return false;
		}

		$template = get_page_template_slug( get_queried_object_id() );

		if ( 'default' === $value ) {
			return '' === $template;
		}

		return '' !== $template && $template === $value;
	}

	/**
	 * @param string $start Local datetime (Y-m-d\TH:i) or empty.
	 * @param string $end   Local datetime (Y-m-d\TH:i) or empty.
	 *
	 * @return bool
	 */
	private static function matches_date_range( $start, $end ) {
		$zone = wp_timezone();
		$now  = new DateTimeImmutable( 'now', $zone );

		if ( '' !== $start ) {
			$from = DateTimeImmutable::createFromFormat( 'Y-m-d\TH:i', $start, $zone );
			if ( $from && $now < $from ) {
				return false;
			}
		}

		if ( '' !== $end ) {
			$until = DateTimeImmutable::createFromFormat( 'Y-m-d\TH:i', $end, $zone );
			if ( $until && $now >= $until ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Weekdays (1 = Monday to 7 = Sunday), optionally within a daily time window
	 * in the site time zone. A window like 22:00 to 06:00 runs over midnight and
	 * counts for the day it starts on.
	 *
	 * @param array  $days Weekday numbers.
	 * @param string $from H:i or empty.
	 * @param string $to   H:i or empty.
	 *
	 * @return bool
	 */
	private static function matches_recurring( array $days, $from, $to ) {
		$now   = new DateTimeImmutable( 'now', wp_timezone() );
		$days  = array_map( 'intval', $days );
		$today = (int) $now->format( 'N' );
		$time  = $now->format( 'H:i' );

		if ( '' === $from && '' === $to ) {
			return in_array( $today, $days, true );
		}

		$from = '' === $from ? '00:00' : $from;
		$to   = '' === $to ? '24:00' : $to;

		if ( $from <= $to ) {
			return in_array( $today, $days, true ) && $time >= $from && $time < $to;
		}

		// Overnight window: the evening part today, or the morning part after yesterday.
		$yesterday = 1 === $today ? 7 : $today - 1;
		return ( in_array( $today, $days, true ) && $time >= $from ) || ( in_array( $yesterday, $days, true ) && $time < $to );
	}

	/**
	 * Compares with the full URL and with the path plus query string, so both
	 * "https://example.com/offer/" and "/offer/" work.
	 *
	 * @param string $operator contains, equals or starts.
	 * @param string $value    Value to compare with.
	 *
	 * @return bool
	 */
	private static function matches_url( $operator, $value ) {
		$path = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
		$path = '' === $path ? '/' : $path;
		$full = untrailingslashit( set_url_scheme( home_url(), is_ssl() ? 'https' : 'http' ) );
		$host = wp_parse_url( $full, PHP_URL_SCHEME ) . '://' . wp_parse_url( $full, PHP_URL_HOST ) . ( wp_parse_url( $full, PHP_URL_PORT ) ? ':' . wp_parse_url( $full, PHP_URL_PORT ) : '' );

		return self::compare( $path, $operator, $value ) || self::compare( $host . $path, $operator, $value );
	}

	/**
	 * A cookie that exists, and optionally has a matching value.
	 *
	 * @param string $name     Cookie name.
	 * @param string $operator contains, equals or starts.
	 * @param string $value    Expected value, or empty for "is set".
	 *
	 * @return bool
	 */
	private static function matches_cookie( $name, $operator, $value ) {
		if ( '' === $name || ! isset( $_COOKIE[ $name ] ) ) {
			return false;
		}
		if ( '' === $value ) {
			return true;
		}
		$cookie = sanitize_text_field( wp_unslash( (string) $_COOKIE[ $name ] ) );
		return self::compare( $cookie, $operator, $value );
	}

	/**
	 * Case-insensitive text comparison.
	 *
	 * @param string $haystack Actual value.
	 * @param string $operator contains, equals or starts.
	 * @param string $needle   Expected value.
	 *
	 * @return bool
	 */
	private static function compare( $haystack, $operator, $needle ) {
		$haystack = strtolower( (string) $haystack );
		$needle   = strtolower( (string) $needle );

		if ( '' === $needle ) {
			return false;
		}

		switch ( $operator ) {
			case 'equals':
				return $haystack === $needle;
			case 'starts':
				return 0 === strpos( $haystack, $needle );
			default:
				return false !== strpos( $haystack, $needle );
		}
	}
}
