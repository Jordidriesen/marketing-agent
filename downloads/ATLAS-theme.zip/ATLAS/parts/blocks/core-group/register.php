<?php
add_filter( 'render_block', 'wrap_group_block', 10, 2 );
function wrap_group_block( $block_content, $block ) {
	if ( 'core/group' === $block['blockName'] ) {
		$block_content = '<div data-styles-id="core-group"></div>' . $block_content;
	}
	return $block_content;
}
