import { Slider } from 'lib/sliders';

const initTestimonialSlider = () => {
    
    [...document.querySelectorAll(".block-testimonial__wrapper")].forEach( block => {
            return new Slider({
                elem: block,
                num: 2,
                tabNum: 1,
                mobNum: 1,
                infinite: false,
                arrows : false,
                dots: true,
                adaptiveHeight: true,
                slideSpeed: 600
            });
        }
    );

};

initTestimonialSlider();

if ( window.acf ) {
    window.acf.addAction( 'render_block_preview/type=testimonials', initTestimonialSlider);
}
