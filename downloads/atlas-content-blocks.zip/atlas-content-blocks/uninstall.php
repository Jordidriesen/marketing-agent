<?php
/**
 * Uninstall: removes the plugin's cache option and transients.
 *
 * Content blocks themselves (posts of type atlas_block) are kept, so removing
 * the plugin never deletes editorial content. Delete them in the admin first
 * if they are no longer needed.
 *
 * @package AtlasContentBlocks
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

delete_option( 'atlas_cb_cache_version' );

// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- one-off cleanup of this plugin's transients.
$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
		$wpdb->esc_like( '_transient_atlas_cb_index_' ) . '%',
		$wpdb->esc_like( '_transient_timeout_atlas_cb_index_' ) . '%'
	)
);
