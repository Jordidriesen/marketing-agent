<?php
/**
 * Block with Pricing Columns
 *
 * @package WordPress
 * @subpackage ATLAS
 * @since ATLAS 1.0
 */

loadAcfBlockPreviewImage(__DIR__);

$id = get_field('team_tile_member');

if ( !empty($id) ) {
    get_theme_part('components/member/index', ['id' => $id]); 
}