<?php 
/**
 * Turn the Rank Math FAQ block into an accordion.
 * The script is inlined in the footer (no extra request) and has no jQuery
 * dependency. Source: index.js, built to index.min.js.
 */
function turn_rm_faq_to_accordion() {
	$script = __DIR__ . '/index.min.js';

	if ( ! file_exists( $script ) ) {
		return;
	}

	echo '<script>' . file_get_contents( $script ) . '</script>';
}
add_action( 'wp_footer', 'turn_rm_faq_to_accordion' );
