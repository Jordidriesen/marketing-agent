<?php
/**
 * Human-readable summaries of a block's settings: placement, popup trigger
 * and display conditions. Used by the list screen and the settings meta box.
 * admin.js builds the same texts in the browser from the strings in
 * Atlas_CB_Summary::script_strings(), so keep the two in step.
 *
 * @package AtlasContentBlocks
 */

defined( 'ABSPATH' ) || exit;

class Atlas_CB_Summary {

	/**
	 * Placement column text: the popup trigger, the locations, or "Placed by
	 * hand only".
	 *
	 * @param array $s Settings.
	 *
	 * @return string
	 */
	public static function placement( array $s ) {
		if ( 'popup' === $s['type'] ) {
			return self::trigger( $s['popup'] );
		}

		if ( ! $s['locations'] ) {
			return __( 'Placed by hand only', 'atlas-content-blocks' );
		}

		$labels = Atlas_CB_Settings::locations();
		$names  = array();
		foreach ( $s['locations'] as $location ) {
			if ( 'custom' === $location ) {
				$names[] = $s['custom_hook'];
			} elseif ( 'after_paragraph' === $location ) {
				/* translators: %d: paragraph number */
				$names[] = sprintf( __( 'After paragraph %d', 'atlas-content-blocks' ), $s['paragraph'] );
			} elseif ( 'before_heading' === $location ) {
				/* translators: %d: heading number */
				$names[] = sprintf( __( 'Before heading %d', 'atlas-content-blocks' ), $s['heading'] );
			} else {
				$names[] = $labels[ $location ] ?? $location;
			}
		}
		return implode( ', ', $names );
	}

	/**
	 * Formats of the popup trigger texts, with the setting each placeholder
	 * takes, in order.
	 *
	 * @return array Trigger => [ format, [ popup setting keys ] ].
	 */
	public static function trigger_formats() {
		return array(
			'click'          => array( __( 'On click', 'atlas-content-blocks' ), array() ),
			'load'           => array( __( 'On page load', 'atlas-content-blocks' ), array() ),
			/* translators: %d: seconds */
			'delay'          => array( __( 'After %d s', 'atlas-content-blocks' ), array( 'delay' ) ),
			/* translators: 1: amount, 2: unit (px or %) */
			'scroll_down'    => array( __( 'After scrolling %1$d%2$s', 'atlas-content-blocks' ), array( 'scroll', 'scroll_unit' ) ),
			'scroll_up'      => array( __( 'On scroll up', 'atlas-content-blocks' ), array() ),
			/* translators: %s: CSS selector */
			'scroll_element' => array( __( 'When %s is in view', 'atlas-content-blocks' ), array( 'scroll_element' ) ),
			/* translators: %d: seconds */
			'inactivity'     => array( __( 'After %d s inactive', 'atlas-content-blocks' ), array( 'inactivity' ) ),
			/* translators: %d: number of pages */
			'pages'          => array( __( 'After %d pages', 'atlas-content-blocks' ), array( 'pages' ) ),
			'exit'           => array( __( 'On exit intent', 'atlas-content-blocks' ), array() ),
		);
	}

	/**
	 * @param array $p Popup settings.
	 *
	 * @return string
	 */
	public static function trigger( array $p ) {
		$formats = self::trigger_formats();
		if ( ! isset( $formats[ $p['trigger'] ] ) ) {
			return '';
		}
		list( $format, $keys ) = $formats[ $p['trigger'] ];
		$args                  = array();
		foreach ( $keys as $key ) {
			$args[] = $p[ $key ] ?? '';
		}
		return vsprintf( $format, $args );
	}

	/**
	 * One rule: its label, the first value it has, and "not" when negated.
	 *
	 * @param array $rule Rule.
	 *
	 * @return string
	 */
	public static function rule( array $rule ) {
		$types = Atlas_CB_Settings::rule_types();
		$label = $types[ $rule['rule'] ]['label'] ?? $rule['rule'];
		foreach ( self::value_keys() as $key ) {
			if ( isset( $rule[ $key ] ) && is_scalar( $rule[ $key ] ) && '' !== (string) $rule[ $key ] ) {
				$label .= ': ' . $rule[ $key ];
				break;
			}
		}
		return ! empty( $rule['not'] ) ? __( 'not', 'atlas-content-blocks' ) . ' ' . $label : $label;
	}

	/**
	 * Rule fields shown in a summary, in order of preference.
	 *
	 * @return array
	 */
	public static function value_keys() {
		return array( 'ids', 'terms', 'role', 'value', 'name', 'language' );
	}

	/**
	 * Display conditions in one line, such as "Entire website, except Front
	 * page" or "(Single page + Logged in) or (Front page)".
	 *
	 * @param array $s Settings.
	 *
	 * @return string
	 */
	public static function conditions( array $s ) {
		$c = $s['conditions'];

		if ( 'advanced' === $c['mode'] ) {
			if ( ! $c['groups'] ) {
				return __( 'Nowhere (no rules)', 'atlas-content-blocks' );
			}
			$groups = array();
			foreach ( $c['groups'] as $group ) {
				$groups[] = '(' . implode( ' + ', array_map( array( __CLASS__, 'rule' ), $group['rules'] ) ) . ')';
			}
			return implode( ' ' . __( 'or', 'atlas-content-blocks' ) . ' ', $groups );
		}

		if ( ! $c['include'] ) {
			return __( 'Nowhere (no rules)', 'atlas-content-blocks' );
		}

		$text = implode( ', ', array_map( array( __CLASS__, 'rule' ), $c['include'] ) );

		if ( $c['exclude'] ) {
			/* translators: 1: included rules, 2: excluded rules */
			$text = sprintf( __( '%1$s, except %2$s', 'atlas-content-blocks' ), $text, implode( ', ', array_map( array( __CLASS__, 'rule' ), $c['exclude'] ) ) );
		}

		return $text;
	}

	/**
	 * Strings admin.js needs to build the same summaries in the browser.
	 *
	 * @return array
	 */
	public static function script_strings() {
		$triggers = array();
		foreach ( self::trigger_formats() as $trigger => $format ) {
			$triggers[ $trigger ] = array(
				'format' => $format[0],
				'keys'   => $format[1],
			);
		}

		return array(
			'nowhere'   => __( 'Nowhere (no rules)', 'atlas-content-blocks' ),
			'or'        => __( 'or', 'atlas-content-blocks' ),
			'not'       => __( 'not', 'atlas-content-blocks' ),
			/* translators: 1: included rules, 2: excluded rules */
			'except'    => __( '%1$s, except %2$s', 'atlas-content-blocks' ),
			'valueKeys' => self::value_keys(),
			'triggers'  => $triggers,
		);
	}
}
