<?php
$link_target = isset($link_target) ? $link_target : '_self';
$link_title = isset($link_title) ? $link_title : 'Button';
$link_url = isset($link_url) ? $link_url : '#';
$name = 'core-button';
?>
<?php loadStylesDep('blocks/core-button', $name); ?>
<div class="wp-block-button"><a class="wp-block-button__link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a></div>