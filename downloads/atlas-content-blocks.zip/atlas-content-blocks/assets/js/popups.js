/**
 * ATLAS Content Blocks: popups.
 *
 * Opens the <dialog> popups printed by the plugin. With the focus trap on, a
 * popup opens with showModal(): the browser traps focus, shows the backdrop
 * and returns focus on close. With it off, show() opens it without a backdrop
 * and the page stays usable.
 *
 * Triggers (one automatic trigger per popup):
 * - click: `.atlas-popup-{ID}`, `a[href="#atlas-popup-{ID}"]` or the popup's
 *   own selector (always active, whatever the automatic trigger)
 * - load: on page load; delay: after a number of seconds
 * - scroll_down: after scrolling down a number of pixels (or % of the page)
 * - scroll_up: when the visitor scrolls back up
 * - scroll_element: when an element (CSS selector) comes into view
 * - inactivity: after a number of seconds without input
 * - pages: once the visitor has viewed a number of pages (localStorage)
 * - exit: when the pointer leaves through the top of the window (desktop)
 *
 * Relaunch limits apply to automatic triggers only; a click always opens.
 *
 * Events: `atlas-popup:open` and `atlas-popup:close` bubble from the dialog
 * to document, with `detail.id` and `detail.dialog`.
 *
 * API: window.atlasPopups.open(id), .close(id), .closeAll(), .isOpen(id).
 */
(function () {
	'use strict';

	var SEEN_PREFIX = 'atlasPopupSeen-';
	var PAGES_KEY = 'atlasPopupPages';
	var MEDIA_IFRAME = /youtube\.com|youtube-nocookie\.com|youtu\.be|vimeo\.com|wistia\.(com|net)/i;

	var media = {
		mobile: '(max-width: 767px)',
		tablet: '(min-width: 768px) and (max-width: 1199px)',
		desktop: '(min-width: 1200px)'
	};

	var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
	var popups = [];

	var storage = function (type) {
		try {
			var store = window[type];
			var probe = '__atlas_cb__';
			store.setItem(probe, probe);
			store.removeItem(probe);
			return store;
		} catch (e) {
			return null;
		}
	};

	// Count this page view for the "after X pages" trigger.
	var pageViews = (function () {
		var local = storage('localStorage');
		if (!local) {
			return 0;
		}
		var count = (parseInt(local.getItem(PAGES_KEY), 10) || 0) + 1;
		local.setItem(PAGES_KEY, String(count));
		return count;
	})();

	var hiddenHere = function (config) {
		return (config.hideOn || []).some(function (device) {
			return media[device] && window.matchMedia(media[device]).matches;
		});
	};

	var seenRecently = function (config) {
		var key = SEEN_PREFIX + config.id;

		if (config.relaunch === 'session') {
			var session = storage('sessionStorage');
			return !!(session && session.getItem(key));
		}

		if (config.relaunch === 'interval') {
			var local = storage('localStorage');
			var at = local ? parseInt(local.getItem(key), 10) : 0;
			return !!at && Date.now() - at < config.interval * 1000;
		}

		return false;
	};

	var markSeen = function (config) {
		var key = SEEN_PREFIX + config.id;

		if (config.relaunch === 'session') {
			var session = storage('sessionStorage');
			if (session) {
				session.setItem(key, '1');
			}
		} else if (config.relaunch === 'interval') {
			var local = storage('localStorage');
			if (local) {
				local.setItem(key, String(Date.now()));
			}
		}
	};

	var emit = function (name, popup) {
		var detail = { id: popup.config.id, dialog: popup.dialog };
		var event;
		try {
			event = new CustomEvent(name, { detail: detail, bubbles: true });
		} catch (e) {
			event = document.createEvent('CustomEvent');
			event.initCustomEvent(name, true, false, detail);
		}
		popup.dialog.dispatchEvent(event);
	};

	var isOpen = function (popup) {
		return popup.dialog.open;
	};

	// Page classes: any popup open, and the scroll lock for modal popups that ask for it.
	var syncPage = function () {
		var open = popups.filter(isOpen);
		var root = document.documentElement;
		root.classList.toggle('atlas-popup-open', open.length > 0);
		root.classList.toggle('atlas-popup-lock', open.some(function (popup) {
			return popup.config.modal && popup.config.scrollLock;
		}));
	};

	// Load on demand: the content waits in a <template> until the first open.
	var loadContent = function (popup) {
		var template = popup.dialog.querySelector('template.atlas-popup__template');
		if (!template) {
			return;
		}

		// Scripts cloned out of a template run once inserted (checked in Chromium).
		var fragment = document.importNode(template.content, true);

		template.parentNode.replaceChild(fragment, template);
	};

	var stopMedia = function (popup) {
		popup.dialog.querySelectorAll('video, audio').forEach(function (element) {
			if (typeof element.pause === 'function') {
				element.pause();
			}
		});
		popup.dialog.querySelectorAll('iframe').forEach(function (frame) {
			var src = frame.getAttribute('src');
			if (src && MEDIA_IFRAME.test(src)) {
				// Reloading the frame stops playback.
				frame.setAttribute('src', src);
			}
		});
	};

	// Runs once per close, however the dialog was closed (script, Escape, form method="dialog").
	var afterClose = function (popup) {
		if (!popup.isOpen) {
			return;
		}
		popup.isOpen = false;
		window.clearTimeout(popup.closeTimer);
		popup.closing = false;
		popup.dialog.classList.remove('is-closing');
		if (popup.config.stopMedia) {
			stopMedia(popup);
		}
		syncPage();
		emit('atlas-popup:close', popup);
	};

	var open = function (popup, automatic) {
		var dialog = popup.dialog;
		var config = popup.config;

		if (dialog.open || hiddenHere(config)) {
			return false;
		}

		if (automatic) {
			// Never interrupt another open popup with an automatic one.
			if (document.querySelector('dialog.atlas-popup[open]')) {
				return false;
			}
			if (seenRecently(config)) {
				return false;
			}
		}

		loadContent(popup);
		window.clearTimeout(popup.closeTimer);
		popup.closing = false;
		dialog.classList.remove('is-closing');

		if (config.modal && typeof dialog.showModal === 'function') {
			dialog.showModal();
		} else if (typeof dialog.show === 'function') {
			dialog.show();
		} else {
			dialog.setAttribute('open', '');
		}

		popup.isOpen = true;
		popup.openedAt = window.pageYOffset;
		syncPage();
		markSeen(config);
		emit('atlas-popup:open', popup);
		return true;
	};

	// Close, after the closing animation when there is one.
	var close = function (popup) {
		var dialog = popup.dialog;

		if (!dialog.open || popup.closing) {
			return;
		}

		var finish = function () {
			window.clearTimeout(popup.closeTimer);
			dialog.removeEventListener('animationend', onEnd);
			popup.closing = false;
			dialog.classList.remove('is-closing');
			if (!dialog.open) {
				return;
			}
			if (typeof dialog.close === 'function') {
				dialog.close();
			} else {
				dialog.removeAttribute('open');
			}
			afterClose(popup);
		};

		var onEnd = function (event) {
			if (event.target === dialog) {
				finish();
			}
		};

		if (popup.config.animation === 'none' || reducedMotion.matches) {
			finish();
			return;
		}

		popup.closing = true;
		dialog.classList.add('is-closing');
		dialog.addEventListener('animationend', onEnd);
		// In case the animation never runs (hidden tab, styles not loaded).
		popup.closeTimer = window.setTimeout(finish, 400);
	};

	var closeLater = function (popup) {
		window.setTimeout(function () {
			close(popup);
		}, Math.max(0, popup.config.closeDelay || 0) * 1000);
	};

	var validSelector = function (selector) {
		if (!selector) {
			return false;
		}
		try {
			document.querySelector(selector);
			return true;
		} catch (e) {
			return false;
		}
	};

	var setupAutomatic = function (popup) {
		var config = popup.config;
		var auto = function () {
			return open(popup, true);
		};

		switch (config.trigger) {
			case 'load':
				auto();
				break;

			case 'delay':
				window.setTimeout(auto, Math.max(0, config.delay) * 1000);
				break;

			case 'scroll_down':
				var onScrollDown = function () {
					var reached;
					if (config.scrollUnit === '%') {
						var max = document.documentElement.scrollHeight - window.innerHeight;
						reached = (max > 0 ? (window.pageYOffset / max) * 100 : 100) >= config.scroll;
					} else {
						reached = window.pageYOffset >= config.scroll;
					}
					if (reached && auto()) {
						window.removeEventListener('scroll', onScrollDown);
					}
				};
				window.addEventListener('scroll', onScrollDown, { passive: true });
				onScrollDown();
				break;

			case 'scroll_up':
				// Opens once the visitor scrolls back up at least 50px from the furthest point.
				var deepest = window.pageYOffset;
				var onScrollUp = function () {
					var y = window.pageYOffset;
					deepest = Math.max(deepest, y);
					if (deepest - y >= 50 && auto()) {
						window.removeEventListener('scroll', onScrollUp);
					}
				};
				window.addEventListener('scroll', onScrollUp, { passive: true });
				break;

			case 'scroll_element':
				if (!validSelector(config.scrollElement)) {
					break;
				}
				var target = document.querySelector(config.scrollElement);
				if (!target) {
					break;
				}
				if ('IntersectionObserver' in window) {
					var observer = new IntersectionObserver(function (entries) {
						if (entries.some(function (entry) { return entry.isIntersecting; }) && auto()) {
							observer.disconnect();
						}
					});
					observer.observe(target);
				}
				break;

			case 'inactivity':
				var idleTimer;
				var events = ['pointermove', 'pointerdown', 'keydown', 'scroll', 'wheel', 'touchstart'];
				var stop = function () {
					window.clearTimeout(idleTimer);
					events.forEach(function (name) {
						window.removeEventListener(name, reset, true);
					});
				};
				var reset = function () {
					window.clearTimeout(idleTimer);
					idleTimer = window.setTimeout(function () {
						if (auto()) {
							stop();
						} else {
							reset();
						}
					}, Math.max(1, config.inactivity) * 1000);
				};
				events.forEach(function (name) {
					window.addEventListener(name, reset, { capture: true, passive: true });
				});
				reset();
				break;

			case 'pages':
				if (pageViews >= config.pages) {
					auto();
				}
				break;

			case 'exit':
				if (window.matchMedia('(pointer: fine)').matches) {
					var onLeave = function (event) {
						if (!event.relatedTarget && event.clientY <= 0 && auto()) {
							document.removeEventListener('mouseout', onLeave);
						}
					};
					document.addEventListener('mouseout', onLeave);
				}
				break;
		}
	};

	var setup = function (dialog) {
		var config;
		try {
			config = JSON.parse(dialog.getAttribute('data-atlas-popup'));
		} catch (e) {
			return;
		}

		var popup = { dialog: dialog, config: config, openedAt: 0, closing: false, isOpen: false };
		var selectors = ['.atlas-popup-' + config.id, 'a[href="#atlas-popup-' + config.id + '"]'];

		if (validSelector(config.selector)) {
			selectors.push(config.selector);
		}

		popup.selector = selectors.join(',');
		popup.closeSelector = validSelector(config.closeSelector) ? config.closeSelector : '';
		popups.push(popup);

		dialog.querySelector('.atlas-popup__close').addEventListener('click', function () {
			close(popup);
		});

		// A click on the backdrop lands on the dialog itself, outside its children.
		dialog.addEventListener('click', function (event) {
			if (config.closeOverlay && config.modal && event.target === dialog) {
				close(popup);
			}
		});

		// Escape on a modal popup: animate the close, or keep it open.
		dialog.addEventListener('cancel', function (event) {
			event.preventDefault();
			if (config.closeEsc) {
				close(popup);
			}
		});

		dialog.addEventListener('submit', function () {
			if (config.closeSubmit) {
				closeLater(popup);
			}
		}, true);

		// The native close event is queued, so it can arrive after a reopen: check first.
		dialog.addEventListener('close', function () {
			if (!dialog.open) {
				afterClose(popup);
			}
		});

		setupAutomatic(popup);
	};

	var byId = function (id) {
		return popups.filter(function (popup) {
			return popup.config.id === Number(id);
		});
	};

	var init = function () {
		document.querySelectorAll('dialog.atlas-popup[data-atlas-popup]').forEach(setup);

		window.atlasPopups = {
			open: function (id) {
				return byId(id).some(function (popup) {
					return open(popup, false);
				});
			},
			close: function (id) {
				byId(id).forEach(close);
			},
			closeAll: function () {
				popups.forEach(close);
			},
			isOpen: function (id) {
				return byId(id).some(isOpen);
			}
		};

		if (!popups.length) {
			return;
		}

		document.addEventListener('click', function (event) {
			if (!(event.target instanceof Element)) {
				return;
			}

			// Custom close triggers, with their optional delay.
			popups.forEach(function (popup) {
				if (popup.closeSelector && popup.dialog.open && event.target.closest(popup.closeSelector)) {
					closeLater(popup);
				}
			});

			popups.some(function (popup) {
				if (event.target.closest(popup.selector)) {
					event.preventDefault();
					open(popup, false);
					return true;
				}
				return false;
			});
		});

		// Escape for popups opened without the focus trap (no native cancel event).
		document.addEventListener('keydown', function (event) {
			if (event.key !== 'Escape') {
				return;
			}
			var modeless = popups.filter(function (popup) {
				return isOpen(popup) && !popup.config.modal && popup.config.closeEsc;
			});
			if (modeless.length) {
				close(modeless[modeless.length - 1]);
			}
		});

		// Close on scroll back: scrolling up past the point where the popup opened.
		window.addEventListener('scroll', function () {
			var y = window.pageYOffset;
			popups.forEach(function (popup) {
				if (popup.config.closeScroll && isOpen(popup) && y < popup.openedAt - 10) {
					close(popup);
				}
			});
		}, { passive: true });

		// Form plugins that submit without a native submit event (HubSpot).
		var closeFormPopups = function () {
			popups.forEach(function (popup) {
				if (popup.config.closeSubmit && isOpen(popup) && popup.dialog.querySelector('form, iframe, .hbspt-form, .hs-form')) {
					closeLater(popup);
				}
			});
		};
		window.addEventListener('message', function (event) {
			var data = event.data;
			if (data && data.type === 'hsFormCallback' && data.eventName === 'onFormSubmitted') {
				closeFormPopups();
			}
		});
		window.addEventListener('hs-form-event:on-submission:success', closeFormPopups);

		// Open from a link to the popup's anchor, e.g. a shared URL ending in #atlas-popup-123.
		var hash = window.location.hash.replace('#', '');
		popups.forEach(function (popup) {
			if (hash === popup.dialog.id) {
				open(popup, false);
			}
		});
	};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
