<?php
function init_block_teaser() {
    if ( ! function_exists( 'acf_register_block' ) ) {
        return;
    }

    acf_register_block( array(
        'name'              => 'teaser',
        'title'             => __( 'Leistungen-Vorschau / Service-Teaser', 'ATLAS' ),
        'description'       => __( 'Teaser block', 'ATLAS' ),
        'category'          => 'custom_blocks',
        'icon'              => 'media-document',
        'mode'              => 'auto',
        'keywords'          => array( 'teaser' ),
        'supports'          => array(
            'align' => false,
        ),
		'example'         => [
            'attributes' => [
                'mode' => 'preview',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-teaser/index.php',
    ));
}

add_action( 'acf/init', 'init_block_teaser' );

function extend_block_teser_script() {
    wp_enqueue_script(
        'ATLAS/block_teser_script',
        get_template_directory_uri() . '/parts/blocks/acf-teaser/admin.min.js',
        array( 'wp-i18n', 'wp-dom-ready', 'wp-editor', 'wp-blocks' )
    );
}
add_action( 'enqueue_block_editor_assets', 'extend_block_teser_script' );