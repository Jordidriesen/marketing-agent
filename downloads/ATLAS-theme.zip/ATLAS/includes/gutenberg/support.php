<?php
/**
 * Add support for Gutenberg.
 *
 * @link https://wordpress.org/gutenberg/handbook/reference/theme-support/
 */
function base_theme_setup_theme_supported_features() {
	// Add support for Block Styles.
	add_theme_support( 'wp-block-styles' );

	// Add support for full and wide align images.
	add_theme_support( 'align-wide' );
	add_theme_support( 'align-full' );

	// Add support for editor styles.
	add_theme_support( 'editor-styles' );

	// Enqueue editor styles.
	add_editor_style( 'css/style-editor.css' );

	// Add support for responsive embedded content.
	add_theme_support( 'responsive-embeds' );

	// Register Theme font sizes
	add_theme_support( 'editor-font-sizes', array(
		array(
			'name' => __( 'Normal', 'ATLAS' ),
			'size' => 16,
			'slug' => 'normal'
		),
		array(
			'name' => __( 'Large', 'ATLAS' ),
			'size' => 20,
			'slug' => 'large'
		)
	) );

	// Register Theme colors
	add_theme_support( 'editor-color-palette', get_supported_colors() );

	// Spacing
	add_theme_support( 'custom-spacing' );

}
add_action( 'after_setup_theme', 'base_theme_setup_theme_supported_features' );

/**
 * Function for generate supported colors output in array or styles string
 *
 * @param string $return_format
 *
 * @return string || array || debug
 */
function get_supported_colors($return_format = 'support') {
	$colors = json_decode(file_get_contents(__DIR__ . '/colors.json'), true);

	if ($return_format === 'support') {

		$arr = [];

		foreach ($colors as $key => $color) {
			$slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $key)));
			$arr[] = array(
				'name' => __( $key, 'ATLAS' ),
				'slug' => $slug,
				'color' => $color,
			);
		}

		return $arr;

	} else if ($return_format === 'styles') {

		$html = '<style type="text/css">';

		foreach ($colors as $key => $color) {
			$slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $key)));
			$html .= ".has-$slug-color{color:$color;}";
			$html .= ".has-$slug-background-color{background-color:$color;}";
		}

		$html .= '</style>';

		echo $html;

	} else if ($return_format === 'debug') {
		var_dump($colors);
	}
}

/**
 * Enqueue script for modifications of post preview loading animation
 */
function modify_preview_animation() {
	wp_enqueue_script(
		'modify_preview_animation',
		get_template_directory_uri() . '/js/preview-animation.js',
		array( 'wp-hooks' ),
		false,
		true
	);
}

add_action( 'enqueue_block_editor_assets', 'modify_preview_animation' );

add_action( 'admin_menu', 'show_reusable_blocks_in_menu' );
function show_reusable_blocks_in_menu() {
	add_menu_page( 'reusable_blocks_menu', 'Reusable Blocks', 'read', 'edit.php?post_type=wp_block', '', 'dashicons-editor-table', 22 );
}

if (!is_admin()) {
    function atlas_dequeue_common_css() {
        wp_deregister_style('common');
    }
    add_action( 'wp_enqueue_scripts', 'atlas_dequeue_common_css');
}