<?php
/**
 * Return the term names of a taxonomy for a given post, always as an array.
 *
 * @param int    $post_id
 * @param string $taxonomy
 *
 * @return array
 */
function get_webinar_term_names($post_id, $taxonomy) {
	$terms = get_the_terms($post_id, $taxonomy);

	if (empty($terms) || is_wp_error($terms)) {
		return [];
	}

	return wp_list_pluck($terms, 'name');
}
