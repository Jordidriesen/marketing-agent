<?php if ( have_rows('footer_columns', 'options') || have_rows('footer_info', 'options') ) : ?>
<div class="main-footer__top">
	<div class="container">
		<?php if ( have_rows('footer_info', 'options') ) : ?>
			<div class="row">
			<?php
				while ( have_rows('footer_info', 'options') ): the_row(); 
				$logo = get_sub_field('logo');
				$company_logo = get_sub_field('company_logo');
				$content = get_sub_field('content');
				$company_content = get_sub_field('company_content');

				if( !empty($content) ) :
			?>
				<div class="main-footer__col col-12 col-lg-6">
					<div class="main-footer__content">
						<?php if ( !empty($logo) ) : ?>
							<figure class="main-footer__logo">
								<?php echo get_svg( $logo, 'full' ); ?>
							</figure>
						<?php endif; ?>
						<?php echo $content; ?>
					</div>
				</div>
			<?php endif; ?>

			<?php if( have_rows( 'legal_group', 'options') ) : ?>
				<div class="main-footer__col col-12 col-lg-3">
				<div class="row_columns main-footer__legal">
					<div class="main-footer__wrapper">
						<?php while( have_rows( 'legal_group', 'options') ) : the_row(); ?>
							<?php
								$legal_title = get_sub_field('legal_headline');
								$legal_menu = get_sub_field('legal_menu');
								$activate_usercentrics = get_sub_field('activate_usercentrics');
							?>
							<?php if( !empty($legal_title) ) : ?>
								<div class="main-footer__header">
									<div class="main-footer__heading h6"><?php echo $legal_title; ?></div>
								</div>
							<?php endif; ?>
							<?php if( !empty($legal_menu) ) : ?>
								<nav class="main-footer__menu">
									<?php echo $legal_menu; ?>
									
								<?php if( $activate_usercentrics ) : ?>
									<div class="main-footer__usercentrics">
									<a href="#" onClick="UC_UI.showSecondLayer();"><?php echo __('Privacy Settings', 'ATLAS'); ?></a>
									</div>
								<?php endif; ?>
								</nav>
							<?php endif; ?>

						<?php endwhile; ?>
					</div>
				</div>
				</div>
			<?php endif; ?>

			<?php if( !empty($company_content) ) : ?>
				<div class="main-footer__col col-12 col-lg-3">
					<div class="main-footer__content main-footer__content--company">
						<?php echo $company_content; ?>
						<?php 
							$company_logo_url = get_sub_field('company_logo_url', 'options');
							if ( !empty($company_logo_url) ) :
						?>
							<a href="<?php echo $company_logo_url; ?>" target="_blank">
								<?php if ( !empty($company_logo) ) : ?>
								<figure class="main-footer__company-logo">
									<?php echo get_svg( $company_logo, 'full' ); ?>
								</figure>
								<?php endif; ?>
							</a>
						<?php else: ?>
							<?php if ( !empty($company_logo) ) : ?>
							<figure class="main-footer__company-logo">
								<?php echo get_svg( $company_logo, 'full' ); ?>
							</figure>
							<?php endif; ?>
						<?php endif; ?>
					</div>
				</div>
			<?php endif; ?>

			<?php endwhile; ?>
			</div>
		<?php endif; ?>

		<?php if ( have_rows('footer_columns', 'options') ) : ?>
		<div class="row row_columns">
		<?php 
		while ( have_rows('footer_columns', 'options') ): the_row(); 
			$title = get_sub_field('title');
			$subtitle = get_sub_field('subtitle');
			$type = get_sub_field('type');
			$menu = get_sub_field('menu');
			$content = get_sub_field('content');
			$link = get_sub_field('link');
			$icon = get_sub_field('icon');
		?>
			<div class="main-footer__col col-12">
				<div class="main-footer__wrapper">
			<?php if ( !empty($title) || !empty($subtitle) ): ?>
				<div class="main-footer__header">
				<?php if ( !empty($title) ) : ?>
					<div class="main-footer__heading h6"><?php echo $title; ?></div>
				<?php endif; ?>
				<?php if ( !empty($subtitle) ) : ?>
					<div class="main-footer__subheading"><?php echo $subtitle; ?></div>
				<?php endif; ?>
				</div>
			<?php endif; ?>
			<?php if ( $type === 'socials' && have_rows('social_links') ) : ?>
				<ul class="social-links__wrapper">
				<?php 
				while ( have_rows('social_links') ) : the_row();
					$link = get_sub_field('link');
					$icon = get_sub_field('icon');
					
					if ( $link ) :
						$icon_html = get_svg($icon, 'full');
						$link_url = $link['url'];
						$link_title = $link['title'];
						$link_target = $link['target'] ? $link['target'] : '_self';
				?>
					<li class="social-links__single">
						<a class="social-links__link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php
							if ( !empty($icon_html) ) :
						?><span class="social-links__icon"><?php echo $icon_html; ?></span><?php 
							endif;
						?><span class="social-links__text"><?php echo esc_html( $link_title ); ?></span></a>
					</li>
				<?php 
					endif;
				endwhile;
				?>
				</ul>
			<?php elseif ( $type === 'menu' && !empty($menu)) : ?>
				<nav class="main-footer__menu">
					<?php echo $menu; ?>
				</nav>
			<?php elseif ( !empty($content) ) : ?>
				<div class="main-footer__content">
					<?php echo $content; ?>
				</div>
			<?php endif; ?>
			</div>
			</div>
		<?php endwhile; ?>
		</div>
		<?php endif; ?>
	</div>
</div>
<?php endif; ?>
