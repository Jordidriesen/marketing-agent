// /**
//  * External Dependencies
//  */
import assign from 'lodash.assign';

// /**
//  * WordPress Dependencies
//  */
const { addFilter } = wp.hooks;
const { __ } = wp.i18n;
const { createHigherOrderComponent } = wp.compose;
const { Fragment } = wp.element;
const { InspectorControls } = wp.editor;
const { PanelBody, ToggleControl } = wp.components;
const {registerBlockStyle} = wp.blocks;

// Enable text uppercase style control on the following blocks
const enableHiddenOnMobileControl = [
    'core/table'
];

const addHiddenOnMobileControlAttribute = ( settings, name ) => {
    // Do nothing if it's another block than our defined ones.
    if ( ! enableHiddenOnMobileControl.includes( name ) ) {
        return settings;
    }

    // Use Lodash's assign to gracefully handle if attributes are undefined
    settings.attributes = assign( settings.attributes, {
        hiddenOnMobile: {
            type: 'boolean',
            default: false,
        },
    } );

    return settings;
};
addFilter( 'blocks.registerBlockType', 'smarttec-extend-block/attribute/hidden-mobile', addHiddenOnMobileControlAttribute );

/**
 * Create HOC to add text uppercase style control to inspector controls of block.
 */
const hiddenOnMobile = createHigherOrderComponent( ( BlockEdit ) => {
    return ( props ) => {
        // Do nothing if it's another block than our defined ones.
        if ( ! enableHiddenOnMobileControl.includes( props.name ) ) {
            return (
                <BlockEdit { ...props } />
            );
        }

        const { hiddenOnMobile } = props.attributes;

        // add has-hidden-mobile class to block
        if ( hiddenOnMobile ) {
            //props.attributes.className = classnames( props.attributes.className, 'has-hidden-mobile' );
            props.attributes.className = 'has-hidden-mobile';
        } else {
            props.attributes.className = '';
            props.attributes.style = '';
        }

        return (
            <Fragment>
                <BlockEdit { ...props } />
                <InspectorControls>
                    <PanelBody
                        title={ __( 'Additional Table Settings' ) }
                        initialOpen={ true }
                    >
                        <ToggleControl
                            label={ __( 'Hide on Mobile' ) }
                            checked={ !! hiddenOnMobile }
                            onChange={ () => {
                                props.setAttributes( {
                                    hiddenOnMobile: ! hiddenOnMobile
                                } );
                            }}
                            help={ !! hiddenOnMobile ? __( 'Hidden on mobile' ) : __( 'Toggle to Hide on mobile' ) }
                        />
                    </PanelBody>
                </InspectorControls>
            </Fragment>
        );
    };
}, 'hiddenOnMobile' );
addFilter( 'editor.BlockEdit', 'smarttec-extend-block/hidden-on-mobile', hiddenOnMobile );

const styles = [
    {
        name: 'highlight-first-column',
        label: 'Highlight First Column'
    }
];

wp.domReady(() => {
    styles.forEach(style => {
        registerBlockStyle('core/table', style);
    });
});
