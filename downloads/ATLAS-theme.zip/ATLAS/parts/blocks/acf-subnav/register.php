<?php
function init_block_subnav() {
    if ( ! function_exists( 'acf_register_block' ) ) {
        return;
    }

    acf_register_block( array(
        'name'              => 'subnav',
        'title'             => __( 'Inhaltsnavigation / Subnavigation', 'ATLAS' ),
        'description'       => __( 'subnav block', 'ATLAS' ),
        'category'          => 'custom_blocks',
        'icon'              => 'media-document',
        'mode'              => 'auto',
        'keywords'          => array( 'navigation', 'sub' ),
        'supports'          => array(
            'align' => false,
        ),
		'example'         => [
            'attributes' => [
                'mode' => 'preview',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-subnav/index.php',
        'enqueue_assets'  => function () {
            $block_directory = basename(__DIR__);
            wp_enqueue_script(
                'ATLAS/'.$block_directory,
                get_template_directory_uri(). (is_IE() ? '/parts/blocks/'.$block_directory. '/index.ie.js' : '/parts/blocks/'.$block_directory. '/index.min.js'),
                [],
                false,
                array(
                    'in_footer' => true,
                    'strategy'  => 'defer',
                )
            );
            wp_enqueue_style(
                'ATLAS/'.$block_directory,
                get_template_directory_uri(). '/parts/blocks/'.$block_directory. '/style.css'
            );
        }
    ));
}

add_action( 'acf/init', 'init_block_subnav' );
