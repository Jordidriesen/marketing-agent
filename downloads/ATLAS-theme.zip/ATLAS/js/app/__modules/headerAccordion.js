import { slideUp, slideDown } from 'lib/slide';

class HeaderAccordion {
    constructor() {
        this.trigger = '.sub-menu-text span, .sub-menu-text a';
    }

    toggleHeaderAccordion(e) {
        const el = e.target;
        const parent = el.parentElement;
        const elContent = parent.nextElementSibling;
        const wrapper = parent.closest('.mega-menu-wrapper');

        if (
            !elContent ||
            elContent.querySelectorAll('li').length === 0
        ) {
            return; // Kein Akkordeon-Inhalt → Klick durchlassen, aber nichts tun
        }

        const isLink = el.matches('a');

        if (parent.classList.contains('active')) {
            if (isLink) {
                // Allow default link behavior on the second click
                return true;
            }
            parent.classList.remove('active');
            slideUp(elContent, 250);
        } else {
            if (wrapper && wrapper.classList.contains('singular-open')) {
                wrapper.querySelectorAll('.active').forEach((active) => {
                    active.classList.remove('active');
                    slideUp(active.nextElementSibling, 250);
                });
            }
            parent.classList.add('active');
            slideDown(elContent, 250);
        }

        // Prevent default link behavior on the first click
        if (isLink) {
            e.preventDefault();
        }
    }

    initHeaderAccordion() {
        document.querySelectorAll(this.trigger).forEach((item) => {
            item.addEventListener('click', (e) => {
                if (window.innerWidth < 1200) {
                    this.toggleHeaderAccordion(e);
                }
            });
        });
    }

    backendAccordionInitHeaderAccordion() {
        document.addEventListener('click', (e) => {
            if (e.target instanceof Element && e.target.matches(this.trigger)) {
                this.toggleHeaderAccordion(e);
            }
        });
    }
}

export default HeaderAccordion;
