<?php
function init_block_accordion()
{
    if (! function_exists('acf_register_block')) {
        return;
    }

    acf_register_block(array(
        'name'              => 'accordion',
        'title'             => __('Akkordeon / Accordion', 'ATLAS'),
        'description'       => __('Akkordeon', 'ATLAS'),
        'category'          => 'custom_blocks',
        'icon'              => 'media-code',
        'mode'              => 'auto',
        'keywords'          => array('accordion', 'content', 'clickable', 'open', 'close'),
        'align'             => 'full',
        'supports'          => array(
            'align' => false,
        ),
        'example'         => [
            'attributes' => [
                'mode' => 'auto',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-accordion/index.php',
        'enqueue_assets'  => function () {
            $block_directory = basename(__DIR__);
            wp_enqueue_script(
                'ATLAS/'.$block_directory,
                get_template_directory_uri(). '/parts/blocks/'.$block_directory. '/index.min.js',
                [],
                false,
                array(
                    'in_footer' => true,
                    'strategy'  => 'defer',
                )
            );
            wp_enqueue_style(
                'ATLAS/'.$block_directory,
                get_template_directory_uri(). '/parts/blocks/'.$block_directory. '/style.css'
            );
        }
    ));
}

add_action('acf/init', 'init_block_accordion');
