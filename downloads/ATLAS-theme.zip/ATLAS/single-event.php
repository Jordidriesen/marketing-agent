<?php

/**
 * The single post page template.
 *
 * @package    WordPress
 * @subpackage ATLAS
 * @since      ATLAS 1.0
 */

get_header();
the_post();
loadStylesComponents('event-overview');
?>
<main class="page-content page-content--single page-content--event">
	<div class="page-entry">

		<?php loadStylesDep('blocks/custom-container', 'custom-container'); ?>
		<section class="wp-block-custom-container alignwide block-content has-dark-grey-background-color block-content--spacing-top block-content--spacing-bottom block-content--margin-top">
			<div class="container container-wide">
				<div class="container__body">

					<div class="wp-block-custom-columns columns-row row">
						<?php loadStylesDep('blocks/custom-columns', 'custom-columns'); ?>
						<?php loadStylesDep('blocks/core-image', 'core-image'); ?>
						<div class="wp-block-custom-column col col-12 col-xl-7">

							<?php
							$title = get_the_title();
							$short_desc = get_the_excerpt();

							$thumbnail = get_the_post_thumbnail_url(get_the_ID(), 'full');
							$event_date = get_field('event_date');
							$event_date_end = get_field('event_date_end');
							$event_time_start = get_field('event_time_start');
							$event_time_end = get_field('event_time_end');

							$event_location = get_field('event_location');
							$event_address = get_field('event_address');

							$event_about = get_field('event_about');
							//Timetable as Repeater
							$event_agenda = get_field('event_agenda');
							//Speaker as Post Object
							$event_speakers = get_field('event_speaker');

							$event_hs_form = get_field('event_hs_form');
							$event_custom_form = get_field('event_custom_form');

							?>
							<?php if (function_exists("rank_math_the_breadcrumbs")) rank_math_the_breadcrumbs(); ?>

							<?php
							// Display the event-format taxonomy terms
							$event_formats = get_the_terms(get_the_ID(), 'event-format');
							if ($event_formats && !is_wp_error($event_formats)) :
								$event_format_names = wp_list_pluck($event_formats, 'name');
								echo '<p class="single-event__event-formats">' . implode(', ', $event_format_names) . '</p>';
							endif;
							?>
							
							<h1 class="single-event__title"><?php echo $title; ?></h1>
							<?php if (!empty($short_desc)) : ?>
								<span class="single-event__desc"><?php echo $short_desc; ?></span>
							<?php endif; ?>

							
							<?php if (empty($event_custom_form) && !empty($event_hs_form)) : ?>
							<div class="single-event__meta">
								<?php if (!empty($event_date)) : ?>
									<div class="single-event__meta-item single-event__date">
										<figure class="single-event__meta-item-icon">
											<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-calendar"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
										</figure>
										<span class="single-event__meta-item-text">
										<?php echo date_i18n(get_option('date_format'), strtotime($event_date)); ?>
										<?php if (!empty($event_date_end)) : ?>
											- <?php echo date_i18n(get_option('date_format'), strtotime($event_date_end)); ?>
										<?php endif; ?>
										</span>
									</div>
								<?php endif; ?>

								<?php if (!empty($event_time_start)) : ?>
									<div class="single-event__meta-item single-event__time">
										<figure class="single-event__meta-item-icon">
											<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-clock"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
										</figure>
										<span class="single-event__meta-item-text">
										<?php echo date_i18n(get_option('time_format'), strtotime($event_time_start)); ?>
										<?php if (!empty($event_time_end)) : ?>
											- <?php echo date_i18n(get_option('time_format'), strtotime($event_time_end)); ?>
										<?php endif; ?>
										<?php echo ' CET'; ?>
										</span>
									</div>
								<?php endif; ?>

								<?php if (!empty($event_location)) : ?>
									<div class="single-event__meta-item single-event__location">
										<figure class="single-event__meta-item-icon">
											<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-map-pin"><path d="M21 10c0 6-9 13-9 13S3 16 3 10a9 9 0 1 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
										</figure>
										<span class="single-event__meta-item-text">
										<?php echo $event_location; ?>
										</span>
									</div>
								<?php endif; ?>
							</div>
							<?php endif; ?>

							<figure class="wp-block-image size-full">
								<img fetchpriority="high" decoding="async" width="384" height="384" src="<?php echo $thumbnail; ?>" alt="" class="wp-image-1003" style="aspect-ratio:2/1;object-fit:cover" srcset="<?php echo $thumbnail; ?> 384w, <?php echo $thumbnail; ?>-300x300.png 300w, <?php echo $thumbnail; ?>-150x150.png 150w, <?php echo $thumbnail; ?>-123x123.png 123w" sizes="(max-width: 384px) 100vw, 384px">
							</figure>
						</div>

						<div class="wp-block-custom-column col col-12 col-xl-5">
							<section class="wp-block-custom-container alignwide block-content has-white-black-background-color" style="background-color:#000000">
								<div class="container container--wide">
									<div class="event-form container__body">

										<?php if (!empty( $event_hs_form )) : ?>
											<h2 class="wp-block-heading has-dark-grey-light-grey-color has-text-color"><?php echo __('Register for this event', 'ATLAS'); ?></h2>

											<?php echo $event_hs_form; ?>

										<?php else : ?>
											<h2 class="wp-block-heading has-dark-grey-light-grey-color has-text-color"><?php echo __('Join this event', 'ATLAS'); ?></h2>

											<div class="single-event__meta">
												<?php if (!empty($event_date)) : ?>
													<div class="single-event__meta-item single-event__date">
														<figure class="single-event__meta-item-icon">
															<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-calendar"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
														</figure>
														<span class="single-event__meta-item-text">
														<?php echo date_i18n(get_option('date_format'), strtotime($event_date)); ?>
														<?php if (!empty($event_date_end)) : ?>
															- <?php echo date_i18n(get_option('date_format'), strtotime($event_date_end)); ?>
														<?php endif; ?>
														</span>
													</div>
												<?php endif; ?>

												<?php if (!empty($event_time_start)) : ?>
													<div class="single-event__meta-item single-event__time">
														<figure class="single-event__meta-item-icon">
															<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-clock"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
														</figure>
														<span class="single-event__meta-item-text">
														<?php echo date_i18n(get_option('time_format'), strtotime($event_time_start)); ?>
														<?php if (!empty($event_time_end)) : ?>
															- <?php echo date_i18n(get_option('time_format'), strtotime($event_time_end)); ?>
														<?php endif; ?>
														<?php echo ' CET'; ?>
														</span>
													</div>
												<?php endif; ?>

												<?php if (!empty($event_location)) : ?>
													<div class="single-event__meta-item single-event__location">
														<figure class="single-event__meta-item-icon">
															<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-map-pin"><path d="M21 10c0 6-9 13-9 13S3 16 3 10a9 9 0 1 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
														</figure>
														<span class="single-event__meta-item-text">
														<?php echo $event_location; ?>
														</span>
													</div>
												<?php endif; ?>
											</div>

											<div class="single-event__buttons">
												<?php if (!empty($event_custom_form)) : ?>
													<?php 
													$name = 'core-button';
													    $event_custom_form_url = $event_custom_form['url'];
														$event_custom_form_title = $event_custom_form['title'];
														$event_custom_form_target = $event_custom_form['target'] ? $event_custom_form['target'] : '_self';
													?>
													<?php loadStylesDep('blocks/core-button', $name); ?>

													<div class="wp-block-button single-event__button"><a class="wp-block-button__link" target="<?php echo $event_custom_form_target; ?>" href="<?php echo $event_custom_form_url; ?>"><?php echo __('Register now', 'ATLAS'); ?></a></div>

												<?php else : ?>
													<p><?php echo __('Please contact us for registration details.', 'ATLAS'); ?></p>
												<?php endif; ?>
											</div>
										<?php endif; ?>

									</div>
								</div>
							</section>
						</div>
					</div>



				</div>
			</div>
		</section>

		<section class="wp-block-custom-container alignwide block-content  block-content--spacing-top block-content--spacing-bottom">
			<div class="container container--wide">
				<div class="container__body">
					<div class="wp-block-custom-columns columns-row row">
						
						<div class="wp-block-custom-column col col-12 col-xl-8">
							<?php if (!empty($event_about)) : ?>
								<div class="single-event__about">
									<h2 class="wp-block-heading"><?php echo __('About this event', 'ATLAS'); ?></h2>
									<?php echo $event_about; ?>
								</div>
							<?php endif; ?>

							<?php if (!empty($event_agenda)) : ?>
								<div class="single-event__agenda">
									<h2 class="wp-block-heading"><?php echo __('Agenda', 'ATLAS'); ?></h2>
									<?php foreach ($event_agenda as $agenda_item) : ?>
										<div class="single-event__agenda-item">
											
											<p class="single-event__agenda-item-time"><?php echo $agenda_item['agenda_time']; ?></p>
											<p class="single-event__agenda-item-headline"><?php echo $agenda_item['agenda_headline']; ?></p>
										</div>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>

							<?php if (!empty($event_speakers)) : ?>
								<div class="single-event__speakers">
									<h2 class="wp-block-heading"><?php echo __('Speakers', 'ATLAS'); ?></h2>
									<div class="single-event__speaker-list">
									<?php foreach ($event_speakers as $speaker) : ?>
										<?php $speaker_id = is_object($speaker) ? $speaker->ID : $speaker; ?>
										<div class="single-event__speaker">
											<div class="single-event__speaker-image">
												<?php echo get_the_post_thumbnail($speaker_id, 'thumbnail'); ?>
											</div>
											<div class="single-event__speaker-details">
												<h4 class="single-event__speaker-name"><?php echo get_the_title($speaker_id); ?></h4>
												<div class="single-event__speaker-desc">
													<?php echo get_field('team_description', $speaker_id); ?>
												</div>
												<?php if (!empty(get_field('team_event_desc', $speaker_id))) : ?>
													<div class="single-event__speaker-bio">
														<?php echo get_field('team_event_desc', $speaker_id); ?>
													</div>
												<?php endif; ?>
											</div>
										</div>
									<?php endforeach; ?>
									</div>
								</div>
							<?php endif; ?>

							<?php if (!empty($event_address)) : ?>
								<div class="single-event__address">
									<h2 class="wp-block-heading"><?php echo __('Venue', 'ATLAS'); ?></h2>
									
									<div class="single-event__address-row">
										<div class="single-event__address-info">
											<h4><?php echo get_field('event_location', get_the_ID()); ?></h4>
											<p><?php echo $event_address; ?></p>

											<?php if (!empty($event_address)) : ?>

												<div class="wp-block-button is-style-link-only single-event__button">
													<a class="wp-block-button__link" href="https://www.google.com/maps/search/?api=1&query=<?php echo urlencode($event_address); ?>" target="_blank" rel="noopener noreferrer">
														<?php echo __('View on maps', 'ATLAS'); ?>
													</a>
												</div>

											<?php endif; ?>

										</div>
										<?php
											$event_location_image = get_field('event_location_image');
											$event_location_image_id = $event_location_image;
											
											if (!empty($event_location_image_id)) : ?>
											<div class="single-event__address-image">
												<?php echo wp_get_attachment_image($event_location_image_id, 'large'); ?>
											</div>
										<?php endif; ?>
									</div>
								</div>
							<?php endif; ?>

						</div>



						<div class="wp-block-custom-column col col-12 col-xl-4">
							
							<?php if (!empty($event_date) || !empty($event_time_start) || !empty($event_location) || !empty($event_format_names)) : ?>
								<section class="wp-block-custom-container alignwide block-content has-dark-grey-background-color block-content--margin-bottom" style="background-color:#000000">
									<div class="container container--wide">
										<div class="event-info container__body">
											<h2 class="wp-block-heading has-white-color has-text-color"><?php echo __('At a glance', 'ATLAS'); ?></h2>

											<?php if (!empty($event_date)) : ?>
											<p>
												<?php echo __('Date:', 'ATLAS'); ?><br>
												<?php echo $event_date . (!empty($event_date_end) ? ' - ' . $event_date_end : ''); ?>
											</p>
											<?php endif; ?>

											<?php if (!empty($event_time_start)) : ?>
											<p>
												<?php echo __('Time:', 'ATLAS'); ?><br>
												<?php echo $event_time_start . (!empty($event_time_end) ? ' - ' . $event_time_end . ' CET' : ''); ?>
											</p>
											<?php endif; ?>

											<?php if (!empty($event_location)) : ?>
											<p>
												<?php echo __('Location:', 'ATLAS'); ?><br>
												<?php echo $event_location; ?>
											</p>
											<?php endif; ?>

											<?php if (!empty($event_format_names)) : ?>
											<p>
												<?php echo __('Format:', 'ATLAS'); ?><br>
												<?php echo implode(', ', $event_format_names); ?>
											</p>
											<?php endif; ?>
											
										</div>
									</div>
								</section>
							<?php endif; ?>


							<?php // Related events ?>
							<?php
							$related_events_query = get_latest_events(3, get_the_ID());
							if ($related_events_query->have_posts()) :
								?>
								<h2><?php echo __('Related events', 'ATLAS'); ?></h2>
								<?php while ($related_events_query->have_posts()) : $related_events_query->the_post();
									$related_event_title = get_the_title();
									$related_event_permalink = get_permalink();
									$related_event_thumbnail = get_the_post_thumbnail_url(get_the_ID(), 'thumbnail');
									?>
									<div class="single-event__related-event--item">
										<a class="single-event__related-event" href="<?php echo esc_url($related_event_permalink); ?>">
											<?php if ($related_event_thumbnail) : ?>
												<img class="single-event__related-event-image" src="<?php echo esc_url($related_event_thumbnail); ?>" alt="<?php echo esc_attr($related_event_title); ?>">
											<?php endif; ?>
											<div class="single-event__related-event-info">
												<h4 class="single-event__related-event-title"><?php echo esc_html($related_event_title); ?></h4>

												<div class="wp-block-button is-style-link-only single-event__related-event-button">
													<div class="wp-block-button__link">
														<?php echo __('View event', 'ATLAS'); ?>
													</div>
												</div>

											</div>
										</a>
									</div>
								<?php endwhile; ?>
								<?php wp_reset_postdata(); ?>
							<?php endif; ?>
						

						</div>
					</div>
				</div>
			</div>
		</section>

	</div>
</main>
<?php
get_footer();
