<?php
/**
 * Resolves which blocks apply to the current request and outputs hook blocks
 * at their locations.
 *
 * @package AtlasContentBlocks
 */

defined( 'ABSPATH' ) || exit;

class Atlas_CB_Renderer {

	/** @var array Matching hook blocks: ID => settings. */
	private static $hook_blocks = array();

	/** @var array Matching popups: ID => settings. */
	private static $popups = array();

	/** @var int[] Blocks being rendered, to stop a block rendering itself. */
	private static $stack = array();

	/** @var int Nesting depth of the_content, to inject only into the outermost call. */
	private static $content_depth = 0;

	public static function init() {
		add_action( 'wp', array( __CLASS__, 'resolve' ) );
		add_action( 'wp_head', array( __CLASS__, 'print_device_css' ), 20 );
	}

	/**
	 * Whether this request renders a front-end page.
	 *
	 * @return bool
	 */
	public static function is_front_request() {
		return ! ( is_admin() || is_feed() || is_embed() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) );
	}

	/**
	 * Decide which blocks show on this request and attach them to their hooks.
	 * Runs once the main query is known.
	 */
	public static function resolve() {
		if ( ! self::is_front_request() ) {
			return;
		}

		foreach ( Atlas_CB_Settings::index() as $id => $settings ) {
			if ( 'hook' === $settings['type'] && 'manual' === $settings['location'] ) {
				continue;
			}
			if ( ! Atlas_CB_Conditions::matches( $settings ) ) {
				continue;
			}

			if ( 'popup' === $settings['type'] ) {
				self::$popups[ $id ] = $settings;
				continue;
			}

			self::$hook_blocks[ $id ] = $settings;
			self::attach( $id, $settings );
		}

		if ( self::$hook_blocks ) {
			// Track the_content nesting for the content start and end locations.
			add_filter( 'the_content', array( __CLASS__, 'content_enter' ), -1000 );
			add_filter( 'the_content', array( __CLASS__, 'content_leave' ), PHP_INT_MAX );
		}

		do_action( 'atlas_cb_resolved', self::$hook_blocks, self::$popups );
	}

	/**
	 * @param int   $id       Block ID.
	 * @param array $settings Block settings.
	 */
	private static function attach( $id, array $settings ) {
		$priority = (int) $settings['priority'];

		if ( 'content_start' === $settings['location'] || 'content_end' === $settings['location'] ) {
			$start = 'content_start' === $settings['location'];
			add_filter(
				'the_content',
				function ( $content ) use ( $id, $settings, $start ) {
					if ( ! self::is_main_content() ) {
						return $content;
					}
					$block = self::render( $id, $settings );
					return $start ? $block . $content : $content . $block;
				},
				// Always after blocks and shortcodes have been rendered (priority 11).
				max( 12, 20 + $priority )
			);
			return;
		}

		$hook = 'custom' === $settings['location'] ? $settings['custom_hook'] : $settings['location'];
		if ( '' === $hook ) {
			return;
		}

		add_action(
			$hook,
			function () use ( $id, $settings ) {
				echo self::render( $id, $settings ); // phpcs:ignore WordPress.Security.EscapeOutput -- post content, filtered like the_content.
			},
			$priority
		);
	}

	/**
	 * Whether the current the_content call is the main post's own content.
	 *
	 * @return bool
	 */
	private static function is_main_content() {
		return 1 === self::$content_depth
			&& empty( self::$stack )
			&& is_singular()
			&& in_the_loop()
			&& is_main_query()
			&& get_the_ID() === get_queried_object_id();
	}

	/**
	 * @param string $content Content.
	 *
	 * @return string
	 */
	public static function content_enter( $content ) {
		self::$content_depth++;
		return $content;
	}

	/**
	 * @param string $content Content.
	 *
	 * @return string
	 */
	public static function content_leave( $content ) {
		self::$content_depth = max( 0, self::$content_depth - 1 );
		return $content;
	}

	/**
	 * Render a block's content inside its wrapper.
	 *
	 * Content goes through the_content, so blocks, shortcodes, embeds and the
	 * theme's per-block style loader work as in a page.
	 *
	 * @param int   $id       Block ID.
	 * @param array $settings Block settings.
	 * @param bool  $wrap     Wrap in the block container.
	 *
	 * @return string
	 */
	public static function render( $id, array $settings, $wrap = true ) {
		if ( in_array( $id, self::$stack, true ) ) {
			return '';
		}

		$post = get_post( $id );
		if ( ! $post || ATLAS_CB_POST_TYPE !== $post->post_type ) {
			return '';
		}

		self::$stack[] = $id;
		$content       = apply_filters( 'the_content', $post->post_content );
		array_pop( self::$stack );

		$content = (string) apply_filters( 'atlas_cb_content', $content, $id, $settings );

		if ( ! $wrap || '' === trim( $content ) ) {
			return $content;
		}

		$classes = array( 'atlas-cb', 'atlas-cb-' . $id );
		foreach ( $settings['hide_on'] as $device ) {
			$classes[] = 'atlas-cb--hide-' . $device;
		}

		return sprintf(
			'<div class="%s" data-atlas-cb="%d">%s</div>',
			esc_attr( implode( ' ', $classes ) ),
			(int) $id,
			$content
		);
	}

	/**
	 * Device visibility classes, inline in the head so they apply before first
	 * paint. Printed when any published block uses them, since manually placed
	 * blocks are only known after the head. Breakpoints follow the theme:
	 * desktop from 1200px, mobile below 768px.
	 */
	public static function print_device_css() {
		if ( ! self::is_front_request() ) {
			return;
		}

		$needed = false;
		foreach ( Atlas_CB_Settings::index() as $settings ) {
			if ( $settings['hide_on'] ) {
				$needed = true;
				break;
			}
		}

		if ( ! $needed ) {
			return;
		}

		echo '<style id="atlas-cb-devices">'
			. '@media (max-width:767px){.atlas-cb--hide-mobile{display:none!important}}'
			. '@media (min-width:768px) and (max-width:1199px){.atlas-cb--hide-tablet{display:none!important}}'
			. '@media (min-width:1200px){.atlas-cb--hide-desktop{display:none!important}}'
			. "</style>\n";
	}

	/**
	 * @return array Matching popups: ID => settings.
	 */
	public static function popups() {
		return self::$popups;
	}
}
