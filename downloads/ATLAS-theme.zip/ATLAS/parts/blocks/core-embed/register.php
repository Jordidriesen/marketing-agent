<?php
add_filter('render_block', 'wrap_embed_block', 10, 2);
function wrap_embed_block($block_content, $block)
{
    if ('core-embed/youtube' === $block['blockName'] || 'core-embed/wordpress' === $block['blockName']) {
        $block_content = '<div data-styles-id="core-embed"></div>' . $block_content;
    }
    return $block_content;
}

function core_block_registration_embed()
{
    if (is_admin()) {
        wp_enqueue_style(
            'core/embed',
            get_template_directory_uri() . '/parts/blocks/core-embed/style-editor.css',
            array('wp-edit-blocks')
        );
    }
}
add_action('enqueue_block_editor_assets', 'core_block_registration_embed');

/**
 * Register the embed overlay script. It is only enqueued when an embed is rendered,
 * see oembed_video_wrapper(), and always in the editor.
 */
function register_block_embed_scripts()
{
    wp_register_script(
        'ATLAS/block_embed_script',
        get_template_directory_uri() . '/parts/blocks/core-embed/index.min.js',
        [],
        false,
        array(
            'in_footer' => true,
            'strategy'  => 'defer',
        )
    );

    if (is_admin()) {
        wp_enqueue_script('ATLAS/block_embed_script');
    }
}
add_action('enqueue_block_assets', 'register_block_embed_scripts');
