const { __ } = wp.i18n;
const {registerBlockStyle} = wp.blocks;

const styles = [
    {
        name: 'uppercase',
        label: __('Uppercase', 'ATLAS')
    },
    {
        name: 'subheading',
        label: __('Subheading', 'ATLAS')
    },
    {
        name: 'leadparagraph',
        label: __('Leadparagraph', 'ATLAS')
    },
];

wp.domReady(() => {
    styles.forEach(style => {
        registerBlockStyle('core/paragraph', style);
    });
});