<?php
if ( isset($id) ):
	$img = get_the_post_thumbnail($id,'news-image');
	$title = get_the_title($id);
	$date = get_the_date('d.m.Y', $id);
	$short_desc = get_the_excerpt($id);
	$link_url = get_permalink($id);
	$link_target = isset($link_target) ? $link_target : '_self';
	$link_title = $btn_txt ? $btn_txt : __('Read more', 'ATLAS');

	$primary_category = get_post_meta( $id, 'rank_math_primary_category', true );
	if ( empty( $primary_category ) ) {
		$categories = get_the_category( $id );
		$primary_category = $categories[0]->name;
	} else {
		$primary_category = get_term($primary_category)->name;
	}
?>
<div class="single-news">
	<?php loadStyles(__DIR__, 'single-news'); ?>
	<div class="single-news__wrapper">
	<?php if (!empty($img)) : ?>
		<figure class="single-news__img"><?php echo $img; ?></figure>
	<?php endif; ?>
		<div class="single-news__content">
			<div class="single-news__meta">
				<time class="single-news__date" datetime="<?php echo $date; ?>"><?php echo $date; ?></time>
				<?php if ( $primary_category ) : ?>
					<span class="single-news__meta--space"> | </span>
				<span class="single-news__term"><?php echo esc_html( $primary_category ); ?></span>
				<?php endif; ?>
			</div>
			<h3 class="single-news__title" role="heading"><?php echo $title; ?></h3>
			<?php if (!empty($short_desc)) : ?>
			<span class="single-news__desc"><?php echo $short_desc; ?></span>
		<?php endif; ?>	
			<?php $name = 'core-button';?>
			<?php loadStylesDep('blocks/core-button', $name); ?>
			<div class="wp-block-button is-style-link-only"><a class="wp-block-button__link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a></div>
		</div>
	</div>
</div>
<?php
endif;