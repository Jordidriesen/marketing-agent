<?php

/**
 * The single post page template.
 *
 * @package    WordPress
 * @subpackage ATLAS
 * @since      ATLAS 1.0
 */

get_header();
the_post();
loadStylesComponents('webinar-overview');
?>
<main class="page-content page-content--single page-content--webinar">
	<div class="page-entry">

		<?php loadStylesDep('blocks/custom-container', 'custom-container'); ?>
		<section class="wp-block-custom-container alignwide block-content has-dark-grey-background-color block-content--spacing-top block-content--spacing-bottom block-content--margin-top">
			<div class="container container-wide">
				<div class="container__body">

					<div class="wp-block-custom-columns columns-row row">
						<?php loadStylesDep('blocks/custom-columns', 'custom-columns'); ?>
						<?php loadStylesDep('blocks/core-image', 'core-image'); ?>
						<div class="wp-block-custom-column col col-12 col-xl-7">

							<?php
							$title = get_the_title();
							$short_desc = get_the_excerpt();

							$webinar_date = get_field('webinar_date');
							$webinar_time_start = get_field('webinar_time_start');
							$webinar_time_end = get_field('webinar_time_end');

							$webinar_duration = get_field('webinar_duration');

							$webinar_about = get_field('webinar_about');
							//What you will learn as Repeater
							$webinar_agenda = get_field('webinar_agenda');
							//Speaker as Post Object
							$webinar_speakers = get_field('webinar_speaker');

							$webinar_hs_form = get_field('webinar_hs_form');
							//Recording as oEmbed
							$webinar_video = get_field('webinar_video');

							// Without a date the webinar is a recording, not an upcoming live session
							$webinar_is_recorded = empty($webinar_date);

							// Taxonomy terms (always arrays, so they can safely be checked further down)
							$webinar_format_names = get_webinar_term_names(get_the_ID(), 'webinar-format');
							$webinar_type_names = get_webinar_term_names(get_the_ID(), 'webinar-type');
							?>
							<?php if (function_exists("rank_math_the_breadcrumbs")) rank_math_the_breadcrumbs(); ?>

							<?php if (!empty($webinar_type_names)) : ?>
								<div class="single-webinar__taxonomies">
									<p class="single-webinar__webinar-types"><?php echo esc_html(implode(', ', $webinar_type_names)); ?></p>
								</div>
							<?php endif; ?>

							<h1 class="single-webinar__title"><?php echo $title; ?></h1>
							<?php if (!empty($short_desc)) : ?>
								<span class="single-webinar__desc"><?php echo $short_desc; ?></span>
							<?php endif; ?>


							<div class="single-webinar__meta">
								<?php if (!$webinar_is_recorded) : ?>
									<div class="single-webinar__meta-item single-webinar__date">
										<figure class="single-webinar__meta-item-icon">
											<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-calendar"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
										</figure>
										<span class="single-webinar__meta-item-text">
										<?php echo date_i18n(get_option('date_format'), strtotime($webinar_date)); ?>
										</span>
									</div>
								<?php else : ?>
									<div class="single-webinar__meta-item single-webinar__recorded">
										<figure class="single-webinar__meta-item-icon">
											<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-play-circle"><circle cx="12" cy="12" r="10"></circle><polygon points="10 8 16 12 10 16 10 8"></polygon></svg>
										</figure>
										<span class="single-webinar__meta-item-text">
										<?php echo __('Recorded', 'ATLAS'); ?>
										</span>
									</div>
								<?php endif; ?>

								<?php if (!$webinar_is_recorded && !empty($webinar_time_start)) : ?>
									<div class="single-webinar__meta-item single-webinar__time">
										<figure class="single-webinar__meta-item-icon">
											<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-clock"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
										</figure>
										<span class="single-webinar__meta-item-text">
										<?php echo date_i18n(get_option('time_format'), strtotime($webinar_time_start)); ?>
										<?php if (!empty($webinar_time_end)) : ?>
											- <?php echo date_i18n(get_option('time_format'), strtotime($webinar_time_end)); ?>
										<?php endif; ?>
										<?php echo ' CET'; ?>
										</span>
									</div>
								<?php endif; ?>

								<?php if (!empty($webinar_duration)) : ?>
									<div class="single-webinar__meta-item single-webinar__duration">
										<figure class="single-webinar__meta-item-icon">
											<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" class="icon-hourglass"><path d="M9 18.5H15M6.6 2H17.4C17.9601 2 18.2401 2 18.454 2.10899C18.6422 2.20487 18.7951 2.35785 18.891 2.54601C19 2.75992 19 3.03995 19 3.6V5.67452C19 6.1637 19 6.40829 18.9447 6.63846C18.8957 6.84254 18.8149 7.03763 18.7053 7.21657C18.5816 7.4184 18.4086 7.59135 18.0627 7.93726L15.1314 10.8686C14.7354 11.2646 14.5373 11.4627 14.4632 11.691C14.3979 11.8918 14.3979 12.1082 14.4632 12.309C14.5373 12.5373 14.7354 12.7354 15.1314 13.1314L18.0627 16.0627C18.4086 16.4086 18.5816 16.5816 18.7053 16.7834C18.8149 16.9624 18.8957 17.1575 18.9447 17.3615C19 17.5917 19 17.8363 19 18.3255V20.4C19 20.9601 19 21.2401 18.891 21.454C18.7951 21.6422 18.6422 21.7951 18.454 21.891C18.2401 22 17.9601 22 17.4 22H6.6C6.03995 22 5.75992 22 5.54601 21.891C5.35785 21.7951 5.20487 21.6422 5.10899 21.454C5 21.2401 5 20.9601 5 20.4V18.3255C5 17.8363 5 17.5917 5.05526 17.3615C5.10425 17.1575 5.18506 16.9624 5.29472 16.7834C5.4184 16.5816 5.59135 16.4086 5.93726 16.0627L8.86863 13.1314C9.26465 12.7354 9.46265 12.5373 9.53684 12.309C9.6021 12.1082 9.6021 11.8918 9.53684 11.691C9.46266 11.4627 9.26464 11.2646 8.86863 10.8686L5.93726 7.93726C5.59136 7.59136 5.4184 7.4184 5.29472 7.21657C5.18506 7.03763 5.10425 6.84254 5.05526 6.63846C5 6.40829 5 6.1637 5 5.67452V3.6C5 3.03995 5 2.75992 5.10899 2.54601C5.20487 2.35785 5.35785 2.20487 5.54601 2.10899C5.75992 2 6.03995 2 6.6 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
										</figure>
										<span class="single-webinar__meta-item-text">
										<?php printf(__('%s min', 'ATLAS'), esc_html($webinar_duration)); ?>
										</span>
									</div>
								<?php endif; ?>

								<?php if (!empty($webinar_format_names)) : ?>
									<div class="single-webinar__meta-item single-webinar__format">
										<figure class="single-webinar__meta-item-icon">
											<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-monitor"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
										</figure>
										<span class="single-webinar__meta-item-text">
										<?php echo esc_html(implode(', ', $webinar_format_names)); ?>
										</span>
									</div>
								<?php endif; ?>
							</div>

							<?php if (!empty($webinar_agenda)) : ?>
								<div class="single-webinar__agenda">
									<h2 class="wp-block-heading"><?php echo __('What you will learn', 'ATLAS'); ?></h2>
									<?php foreach ($webinar_agenda as $agenda_item) : ?>
										<?php if (empty($agenda_item['agenda_headline'])) continue; ?>
										<div class="single-webinar__agenda-item">
											<figure class="single-webinar__agenda-item-icon">
												<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-check-circle"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
											</figure>
											<p class="single-webinar__agenda-item-headline"><?php echo $agenda_item['agenda_headline']; ?></p>
										</div>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>
						</div>

						<div class="wp-block-custom-column col col-12 col-xl-5">
							<section class="wp-block-custom-container alignwide block-content has-white-black-background-color" style="background-color:#000000">
								<div class="container container--wide">
									<div class="webinar-form container__body">

										<?php if (!empty($webinar_hs_form)) : ?>
											<h2 class="wp-block-heading has-dark-grey-light-grey-color has-text-color"><?php echo __('Save your seat', 'ATLAS'); ?></h2>

											<?php echo $webinar_hs_form; ?>

										<?php elseif (!empty($webinar_video)) : ?>
											<h2 class="wp-block-heading has-dark-grey-light-grey-color has-text-color"><?php echo __('Watch the recording', 'ATLAS'); ?></h2>

											<div class="single-webinar__video">
												<?php echo $webinar_video; ?>
											</div>

											<?php
											// Raw field value (the video URL), the formatted value is the embed markup above
											$webinar_video_url = get_field('webinar_video', false, false);
											?>
											<?php if (!empty($webinar_video_url)) : ?>
												<?php loadStylesDep('blocks/core-button', 'core-button'); ?>
												<div class="single-webinar__buttons">
													<div class="wp-block-button single-webinar__button"><a class="wp-block-button__link" href="<?php echo esc_url($webinar_video_url); ?>" target="_blank" rel="noopener noreferrer"><?php echo __('Watch the replay', 'ATLAS'); ?></a></div>
												</div>
											<?php endif; ?>

										<?php else : ?>
											<h2 class="wp-block-heading has-dark-grey-light-grey-color has-text-color"><?php echo __('Join this webinar', 'ATLAS'); ?></h2>

											<p><?php echo __('Please contact us for registration details.', 'ATLAS'); ?></p>
										<?php endif; ?>

									</div>
								</div>
							</section>
						</div>
					</div>



				</div>
			</div>
		</section>

		<section class="wp-block-custom-container alignwide block-content  block-content--spacing-top block-content--spacing-bottom">
			<div class="container container--wide">
				<div class="container__body">
					<div class="wp-block-custom-columns columns-row row">
						
						<div class="wp-block-custom-column col col-12 col-xl-8">
							<?php if (!empty($webinar_about)) : ?>
								<div class="single-webinar__about">
									<h2 class="wp-block-heading"><?php echo __('About this webinar', 'ATLAS'); ?></h2>
									<?php echo $webinar_about; ?>
								</div>
							<?php endif; ?>

							<?php if (!empty($webinar_speakers)) : ?>
								<div class="single-webinar__speakers">
									<h2 class="wp-block-heading"><?php echo __('Speakers', 'ATLAS'); ?></h2>
									<div class="single-webinar__speaker-list">
									<?php foreach ($webinar_speakers as $speaker) : ?>
										<?php $speaker_id = is_object($speaker) ? $speaker->ID : $speaker; ?>
										<div class="single-webinar__speaker">
											<div class="single-webinar__speaker-image">
												<?php echo get_the_post_thumbnail($speaker_id, 'thumbnail'); ?>
											</div>
											<div class="single-webinar__speaker-details">
												<h4 class="single-webinar__speaker-name"><?php echo get_the_title($speaker_id); ?></h4>
												<div class="single-webinar__speaker-desc">
													<?php echo get_field('team_description', $speaker_id); ?>
												</div>
												<?php if (!empty(get_field('team_event_desc', $speaker_id))) : ?>
													<div class="single-webinar__speaker-bio">
														<?php echo get_field('team_event_desc', $speaker_id); ?>
													</div>
												<?php endif; ?>
											</div>
										</div>
									<?php endforeach; ?>
									</div>
								</div>
							<?php endif; ?>

						</div>



						<div class="wp-block-custom-column col col-12 col-xl-4">
							
							<?php if (!empty($webinar_date) || !empty($webinar_time_start) || !empty($webinar_duration) || !empty($webinar_format_names) || !empty($webinar_type_names)) : ?>
								<section class="wp-block-custom-container alignwide block-content has-dark-grey-background-color block-content--margin-bottom" style="background-color:#000000">
									<div class="container container--wide">
										<div class="webinar-info container__body">
											<h2 class="wp-block-heading has-white-color has-text-color"><?php echo __('At a glance', 'ATLAS'); ?></h2>

											<?php if (!empty($webinar_date)) : ?>
											<p>
												<?php echo __('Date:', 'ATLAS'); ?><br>
												<?php echo $webinar_date; ?>
											</p>
											<?php endif; ?>

											<?php if (!empty($webinar_time_start)) : ?>
											<p>
												<?php echo __('Time:', 'ATLAS'); ?><br>
												<?php echo $webinar_time_start . (!empty($webinar_time_end) ? ' - ' . $webinar_time_end . ' CET' : ''); ?>
											</p>
											<?php endif; ?>

											<?php if (!empty($webinar_duration)) : ?>
											<p>
												<?php echo __('Duration:', 'ATLAS'); ?><br>
												<?php printf(__('%s min', 'ATLAS'), esc_html($webinar_duration)); ?>
											</p>
											<?php endif; ?>

											<?php if (!empty($webinar_format_names)) : ?>
											<p>
												<?php echo __('Format:', 'ATLAS'); ?><br>
												<?php echo esc_html(implode(', ', $webinar_format_names)); ?>
											</p>
											<?php endif; ?>

										</div>
									</div>
								</section>
							<?php endif; ?>


							<?php // Related webinars ?>
							<?php
							$related_webinars_query = get_latest_webinars(3, get_the_ID());
							if ($related_webinars_query->have_posts()) :
								?>
								<h2><?php echo __('Related webinars', 'ATLAS'); ?></h2>
								<?php while ($related_webinars_query->have_posts()) : $related_webinars_query->the_post();
									$related_webinar_title = get_the_title();
									$related_webinar_permalink = get_permalink();
									$related_webinar_thumbnail = get_the_post_thumbnail_url(get_the_ID(), 'thumbnail');
									?>
									<div class="single-webinar__related-webinar--item">
										<a class="single-webinar__related-webinar" href="<?php echo esc_url($related_webinar_permalink); ?>">
											<?php if ($related_webinar_thumbnail) : ?>
												<img class="single-webinar__related-webinar-image" src="<?php echo esc_url($related_webinar_thumbnail); ?>" alt="<?php echo esc_attr($related_webinar_title); ?>">
											<?php endif; ?>
											<div class="single-webinar__related-webinar-info">
												<h4 class="single-webinar__related-webinar-title"><?php echo esc_html($related_webinar_title); ?></h4>

												<div class="wp-block-button is-style-link-only single-webinar__related-webinar-button">
													<div class="wp-block-button__link">
														<?php echo __('View webinar', 'ATLAS'); ?>
													</div>
												</div>

											</div>
										</a>
									</div>
								<?php endwhile; ?>
								<?php wp_reset_postdata(); ?>
							<?php endif; ?>
						

						</div>
					</div>
				</div>
			</div>
		</section>

	</div>
</main>
<?php
get_footer();
