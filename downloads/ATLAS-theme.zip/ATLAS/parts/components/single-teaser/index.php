<?php
if ( isset($id) ):
	$img = get_the_post_thumbnail($id,'news-image');
	$title = get_the_title($id);
	$short_desc = get_the_excerpt($id);
	$link_url = get_permalink($id);
	$link_title = $btn_txt ? $btn_txt : __('Button', 'ATLAS');
	$name = 'core-button';

	if ( $link_url ):
?>
<a class="single-teaser" href="<?php echo esc_url( $link_url ); ?>" target="_self">
	<?php else: ?>
<div class="single-teaser">
	<?php endif; ?>
	<?php loadStyles(__DIR__, 'single-teaser'); ?>
	<div class="single-teaser__wrapper">
	<?php if (!empty($img)) : ?>
		<figure class="single-teaser__img"><?php echo $img; ?></figure>
	<?php endif; ?>
		<div class="single-teaser__content">
			<h3 class="single-teaser__title" role="heading"><?php echo $title; ?></h3>
		<?php if (!empty($short_desc)) : ?>
			<span class="single-teaser__desc"><?php echo $short_desc; ?></span>
		<?php endif; ?>	
		<?php loadStylesDep('blocks/core-button', $name); ?>

		</div>
		<?php if( $link_url ): ?>
			<div class="wp-block-button single-teaser__button"><div class="wp-block-button__link single-teaser__link"></div></div>
		<?php endif; ?>
	</div>

	<?php if( $link_url ): ?>
</a>
	<?php else: ?>
</div>
	<?php endif; ?>
<?php
endif;