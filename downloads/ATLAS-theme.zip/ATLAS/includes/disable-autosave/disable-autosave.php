<?php

/**
 * Disable Gutenberg Autosave
 *
 * @package WordPress
 * @subpackage ATLAS
 * @since ATLAS 1.0
 */

add_action( 'admin_init', 'disable_autosave' );
function disable_autosave() {
wp_deregister_script( 'autosave' );
}