<?php
add_filter( 'render_block', 'button_block_styles', 10, 2 );
function button_block_styles( $block_content, $block ) {
	if ( 'core/button' === $block['blockName'] ) {
		$block_content = '<div data-styles-id="core-button"></div>' . $block_content;
	}
	return $block_content;
}

function extend_block_button_script() {
	wp_enqueue_script(
		'ATLAS/block_button_script',
		get_template_directory_uri() . '/parts/blocks/core-button/admin.min.js',
		array( 'wp-i18n', 'wp-dom-ready', 'wp-editor', 'wp-blocks' )
	);
	
}
add_action( 'enqueue_block_editor_assets', 'extend_block_button_script' );

function register_block_button_styles() {
	wp_enqueue_style(
		'core/button',
		get_template_directory_uri() . '/parts/blocks/core-button/style.css'
	);
}
add_action( 'enqueue_block_assets', 'register_block_button_styles' );