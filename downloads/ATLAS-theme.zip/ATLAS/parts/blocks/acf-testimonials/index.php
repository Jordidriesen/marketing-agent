<?php
/**
 * Block with testimonial slider
 *
 * @package WordPress
 * @subpackage ATLAS
 * @since ATLAS 1.0
 */
$block_object = new Block( $block );

loadAcfBlockPreviewImage(__DIR__);

if ( have_rows('testimonial_slider') ) :
    $name = $block_object->block_name();
    $slider_class = 'block-testimonial__wrapper';
    $layout_counter = $block['id'];
    $slider_type = get_field('testimonial_slider_type') ?: 'primary';
    $is_secondary = $slider_type === 'secondary';
    $show_dots = $slider_type === 'secondary' ? 1 : 0;
?>
<section class="block-testimonial block-testimonial--<?php echo $slider_type; ?>">
    <?php loadStyles(__DIR__, $name); ?>
    <?php loadStylesThird('splide'); ?>
    <div class="block-testimonial__container">

        <div class="<?php echo $slider_class; ?>" data-slider="<?php echo $layout_counter; ?>" data-dots="<?php echo $show_dots; ?>">
            <?php
            while ( have_rows('testimonial_slider') ) : the_row();
                $content = get_sub_field('content');
                $author_name = get_sub_field('author_name');
                $author_description = get_sub_field('author_description');
            ?>
                <div class="testimonial-slide">
                    <div class="testimonial-slide__wrapper">
                        <?php if ( !empty($content) ) : ?>
                            <div class="testimonial-slide__content">
                                <h3><?php echo $content; ?></h3>
                            </div>
                        <?php endif; ?>
                        <div class="testimonial-slide__meta">
                            <?php if ( !empty($author_name) ) : ?>
                                <span class="testimonial-slide__author-name"><?php echo $author_name; ?></span>
                            <?php endif; ?>
                            <?php if ( !empty($author_description) ) : ?>
                                <span class="testimonial-slide__author-description"><?php echo $author_description; ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php
            endwhile;
            ?>
        </div>
    </div>
</section>
<?php
endif;