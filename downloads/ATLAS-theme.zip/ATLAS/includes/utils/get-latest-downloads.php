<?php
function get_latest_downloads($amount = 3, $exclude_id = 0) {
	return new WP_Query([
		'post_type'      => 'download',
		'post_status'    => 'publish',
		'posts_per_page' => $amount,
		'post__not_in'   => $exclude_id ? [$exclude_id] : [],
		'orderby'        => 'date',
		'order'          => 'DESC',
	]);
}
