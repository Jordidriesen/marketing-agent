<?php
function init_block_archive_events_slider()
{
    if (! function_exists('acf_register_block')) {
        return;
    }

    acf_register_block(array(
        'name'              => 'archive_events',
        'title'             => __('Archiv Events / Archive Events', 'ATLAS'),
        'description'       => __('Events Archiv', 'ATLAS'),
        'category'          => 'custom_blocks',
        'icon'              => 'media-code',
        'mode'              => 'auto',
        'keywords'          => array('archive', 'news', 'articles', 'neu'),
        'align'             => 'full',
        'supports'          => array(
            'align' => false,
        ),
        'example'         => [
            'attributes' => [
                'mode' => 'auto',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-archive-events/index.php',
        'enqueue_assets'  => function () {
            $block_directory = basename(__DIR__);
            wp_enqueue_style(
                'ATLAS/' . $block_directory,
                get_template_directory_uri() . '/parts/blocks/' . $block_directory . '/style.css'
            );
        }
    ));
}

add_action('acf/init', 'init_block_archive_events_slider');
