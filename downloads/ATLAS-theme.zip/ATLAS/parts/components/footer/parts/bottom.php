<?php
$links = get_field('footer_quick_links', 'options');
$copyright = get_field('footer_copyright', 'options');

if ( !empty($copyright) ) :
?>
<div class="main-footer__bottom">
	<div class="container">
		<div class="row">
		<?php if ( !empty($links) ) : ?>
			<div class="col col-12 col-md-6 main-footer__quick-links">
				<nav><?php echo $links; ?></nav>
			</div>
		<?php endif; ?>
		<?php if ( !empty($copyright) ) : ?>
			<div class="col col-12 col-md-6 main-footer__copy">
				<p><?php echo do_shortcode($copyright); ?></p>
			</div>
		<?php endif; ?>
		</div>
	</div>
</div>
<?php 
endif;