import { Slider } from 'lib/sliders';

const initGallerySlider = () => {
    const transitionTime = (typeof(WP) !== "undefined") ? WP.transitionTime : 400;
    [...document.querySelectorAll(".block-slider__wrapper")].forEach( block => {
            return new Slider({
                elem: block,
                fade: false,
                num: 1,
                infinite: true,
                adaptivHeight: true,
                slideSpeed: transitionTime
            });
        }
    );

};

initGallerySlider();

if ( window.acf ) {
    window.acf.addAction( 'render_block_preview/type=slider', initGallerySlider);
}
