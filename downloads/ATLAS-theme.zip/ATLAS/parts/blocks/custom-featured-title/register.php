<?php
function custom_block_registration_featured_title() {
    wp_register_script(
        'custom/featured-title',
        get_template_directory_uri() . '/parts/blocks/custom-featured-title/admin.min.js',
        array('wp-blocks', 'wp-element', 'wp-editor')
    );

    if( is_admin() ) {
        wp_register_style(
            'custom/featured-title-style-editor',
            get_template_directory_uri() . '/parts/blocks/custom-featured-title/style-editor.css',
            array( 'wp-edit-blocks' )
        );
    }

    register_block_type('custom/featured-title', array(
        'editor_script' => 'custom/featured-title',
        'editor_style'  => 'custom/featured-title-style-editor',
    ));
}
add_action( 'enqueue_block_editor_assets', 'custom_block_registration_featured_title' );