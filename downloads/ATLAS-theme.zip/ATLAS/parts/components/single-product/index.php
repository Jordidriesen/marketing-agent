<?php
if ( isset($id) ):
	$title = get_the_title($id);
	$short_desc = get_the_excerpt($id);
	$link_url = get_permalink($id);
	$link_target = isset($link_target) ? $link_target : '_self';
	$link_title = $btn_txt ? $btn_txt : __('More information', 'ATLAS');

	
	$content_post = get_post($id);
	$content = $content_post->post_content;
	$content = apply_filters('the_content', $content);
	$content = str_replace(']]>', ']]&gt;', $content);

	$download_url = get_field('product_download', $id);

	$buttons = get_field('product_buttons', $id);
?>
<div class="single-product">
	<?php loadStyles(__DIR__, 'single-product'); ?>
	<div class="single-product__wrapper">

		<div class="single-product__content">
			<h3 class="single-product__title"><?php echo $title; ?></h3>
			<?php if (!empty($short_desc)) : ?>
				<span class="single-product__desc"><?php echo $short_desc; ?></span>
			<?php endif; ?>	
			
			<?php 
				$terms = get_the_terms($id, 'product-type');
				if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) :
					foreach ($terms as $term) :
			?>
				<div class="single-product__type"><strong><?php echo _e('Type: ', 'ATLAS'); ?></strong><?php echo $term->name; ?></div>
				<?php endforeach; ?>
			<?php endif; ?>

			<?php
			$featured_posts = get_field('product_solution', $id);
			if( $featured_posts ): ?>
				<?php foreach( $featured_posts as $featured_post ): 
					$permalink = get_permalink( $featured_post->ID );
					$title = get_the_title( $featured_post->ID );
					?>
					<div class="single-product__solution"><strong><?php echo _e('Solution: ', 'ATLAS'); ?></strong><a href="<?php echo esc_url( $permalink ); ?>"><?php echo esc_html( $title ); ?></a></div>
				
				<?php endforeach; ?>
			<?php endif; ?>
		
			<div class="single-product__buttons">
			<?php $name = 'core-button';?>
			<?php loadStylesDep('blocks/core-button', $name); ?>

			<?php if( $buttons == 'both') : ?>
				<!-- <div class="wp-block-button single-product__button"><a class="wp-block-button__link" href="<?php //echo '#product-' . $id; ?>"><?php // echo esc_html( $link_title ); ?></a></div> -->
				<div class="wp-block-button single-product__button"><a class="wp-block-button__link" href="<?php echo $link_url; ?>"><?php echo esc_html( $link_title ); ?></a></div>
				
				<?php if( !empty($download_url) ) : ?>
					<?php $name = 'core-button';?>
					<?php loadStylesDep('blocks/core-button', $name); ?>
					<div class="wp-block-button single-product__button"><a class="wp-block-button__link" target="_BLANK" href="<?php echo $download_url; ?>"><?php echo _e( 'Product data sheet', 'ATLAS' ); ?></a></div>
				<?php endif; ?>
			<?php elseif( $buttons == 'page' ) : ?>
				<div class="wp-block-button single-product__button"><a class="wp-block-button__link" href="<?php echo $link_url; ?>"><?php echo esc_html( $link_title ); ?></a></div>
			<?php elseif( $buttons == 'download' && !empty($download_url) ) : ?>
				<div class="wp-block-button single-product__button"><a class="wp-block-button__link" target="_BLANK" href="<?php echo $download_url; ?>"><?php echo _e( 'Product data sheet', 'ATLAS' ); ?></a></div>
			<?php else: ?>
				<div class="wp-block-button single-product__button"><a class="wp-block-button__link" href="<?php echo $link_url; ?>"><?php echo esc_html( $link_title ); ?></a></div>
			<?php endif; ?>
			</div>
		</div>
	</div>
</div>

<?php 
	//if( !empty($content) ) :
?>
<!-- <div id="<?php // echo 'product-' . $id; ?>" class="overlay">
	<div class="popup">
		<div class="popup__inner">
			<div class="popup__content">
			<?php // echo $content; ?>
			</div>
			<div class="popup__footer">
				<div class="popup__buttons">
				<?php //$name = 'core-button';?>
					<?php // loadStylesDep('blocks/core-button', $name); ?>
					<?php
						
						// if( !empty($download_url) ) :
					?>
					<div class="wp-block-button is-style-link-only"><a class="wp-block-button__link" href="<?php // echo $download_url; ?>"><?php // echo _e( 'Product data sheet', 'ATLAS' ); ?></a></div>
					<?php 
						// endif; 
						// $callback = get_field('product_callback', $id);
						// if( $callback ): 
						// 	$callback_url = $callback['url'];
						// 	$callback_title = $callback['title'];
						// 	$callback_target = $callback['target'] ? $callback['target'] : '_self';
					?>
					<div class="wp-block-button callback"><a class="wp-block-button__link" href="<?php // echo esc_url( $callback_url ); ?>" target="<?php // echo esc_attr( $callback_target ); ?>"><?php // echo esc_html( $callback_title ); ?></a></div>
					<?php // endif; ?>
				</div>
			</div>
		</div>
		<a href="#" class="close"></a>
	</div>
</div> -->
<?php
	//endif;
endif;