import { slideUp, slideDown } from 'lib/slide';

class Footer {
    constructor() {
        this.trigger = '.main-footer__header';
    }

    toggleAccordionFooter(e) {
        const el = e.target;
        const parent = el.parentElement;
        const elContent = parent.nextElementSibling;
        const wrapper = parent.closest('.row_columns');

        if (parent.classList.contains('active')) {
            parent.classList.remove('active');
            slideUp(elContent, 250);
        } else {
            if (wrapper && wrapper.classList.contains('singular-open')) {
                wrapper.querySelectorAll('.active').forEach((active) => {
                    active.classList.remove('active');
                    slideUp(active.nextElementSibling, 250);
                });
            }
            parent.classList.add('active');
            slideDown(elContent, 250);
        }
    }

    initAccordionFooter() {
        document.querySelectorAll(this.trigger).forEach((header) => {
            header.addEventListener('click', (e) => {
                if (window.innerWidth <= 1024) {
                    this.toggleAccordionFooter(e);
                }
            });
        });
    }

    backendAccordionInitFooter() {
        document.addEventListener('click', (e) => {
            if (e.target instanceof Element && e.target.matches(this.trigger)) {
                this.toggleAccordionFooter(e);
            }
        });
    }
}

export default Footer;
