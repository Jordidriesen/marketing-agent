import { Slider } from 'lib/sliders';

const initNewsSlider = () => {
    [...document.querySelectorAll(".block-news__wrapper")].forEach( block => {
        const speed = block.getAttribute("data-speed");
        const transition = block.getAttribute("data-transition");
        const auto = block.getAttribute("data-autoplay");

        const transitionTime = transition || 400;
        const autoplaySpeed = speed || 4000;
        const autoplay = !!auto;

        return new Slider({
                elem: block,
                fade: false,
                num: 3,
                tabNum: 2,
                mobNum: 1,
                infinite: false,
                adaptiveHeight: false,
                dots: true,
                arrows: false,
                slideSpeed: transitionTime,
                autoplaySpeed,
                autoplay,
            });
        }
    );

};

initNewsSlider();

if ( window.acf ) {
    window.acf.addAction( 'render_block_preview/type=news', initNewsSlider);
}
