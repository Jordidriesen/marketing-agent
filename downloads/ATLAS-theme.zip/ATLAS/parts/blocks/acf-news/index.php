<?php
/**
 * Block with news slider
 *
 * @package WordPress
 * @subpackage ATLAS
 * @since ATLAS 1.0
 */
$block_object = new Block( $block );

loadAcfBlockPreviewImage(__DIR__);

$latest = get_field('display_latest_news');
$latest_number = get_field('number_of_latest_news');
$news = get_field('slider_news');
$buttons_text = get_field('buttons_text');

if ( $latest ) {
    $num = $latest_number ? $latest_number : 6;
    $args = array(
        'post_type' => 'post',
        'post_status' => 'publish',
        'posts_per_page' => $num,
        'post__not_in' => [get_the_ID()],
    );
    $the_query = new WP_Query( $args );
}

if ( $news || ($latest && $the_query->have_posts()) ) :
    $name = $block_object->block_name();
    $layout_counter = $block['id'];

    $attr = "data-slider='$layout_counter'";

    //slider settings
    $autoplay = get_field('autoplay_news');
    $speed = get_field('autoplay_news_speed');
    $transition = get_field('transition_time_news');

    $autoplay && $attr .= " data-autoplay='true'";
    $speed && $attr .= " data-speed='$speed'";
    $transition && $attr .= " data-transition='$transition'";

?>
<section class="block-news">
    <?php loadStyles(__DIR__, $name); ?>
    <?php loadStylesThird('splide'); ?>
    <?php loadStylesComponents('sliders'); ?>
    <div class="block-news__container">
        <div class="block-news__wrapper" <?php echo $attr; ?>>
        <?php
        if ( $latest ) {
            while ( $the_query->have_posts() ) { $the_query->the_post();
                $id = get_the_ID();
                get_theme_part('components/single-news/index', ['id' => $id, 'btn_txt'=> $buttons_text]);
            }
            wp_reset_postdata();
        } else {
            foreach ($news as $id) :
                get_theme_part('components/single-news/index', ['id' => $id, 'btn_txt'=> $buttons_text]);
            endforeach;            
        }
        ?>
        </div>
    </div>
</section>
<?php
endif;