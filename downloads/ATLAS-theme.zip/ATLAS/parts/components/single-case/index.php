<?php
if ( isset($id) ):
	$img = get_the_post_thumbnail($id,'news-image');
	$title = get_the_title($id);
	$short_desc = get_the_excerpt($id);
	$link_url = get_permalink($id);
	$link_title = $btn_txt ? $btn_txt : __('Button', 'ATLAS');
	$name = 'core-button';
?>
<a href="<?php echo esc_url( $link_url ); ?>" target="_self" class="single-case">
	<?php loadStyles(__DIR__, 'single-case'); ?>
	<div class="single-case__wrapper">
	<?php if (!empty($img)) : ?>
		<figure class="single-case__img"><?php echo $img; ?></figure>
	<?php endif; ?>
		<div class="single-case__content">
			<h3 class="single-case__title" role="heading"><?php echo $title; ?></h3>
		<?php if (!empty($short_desc)) : ?>
			<span class="single-case__desc"><?php echo $short_desc; ?></span>
		<?php endif; ?>	
		<?php loadStylesDep('blocks/core-button', $name); ?>
		<div class="wp-block-button is-style-link-only"><div class="wp-block-button__link"><?php echo esc_html( $link_title ); ?></div></div>
		</div>
	</div>
</a>
<?php
endif;