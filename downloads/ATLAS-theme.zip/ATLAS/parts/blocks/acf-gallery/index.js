/* eslint-disable no-new */
// GALLERY SLIDER
import { Slider } from 'lib/sliders';

const initGallerySliderBlock = () => {
    const slideSpeed = (typeof(WP) !== "undefined") ? WP.transitionGalleryTime : 400;
    const auto = (typeof(WP) !== "undefined") ? WP.galleryAutoplay : false;
    const autoplaySpeed = (typeof(WP) !== "undefined") ? WP.galleryAutoplaySpeed : 4000;
    const autoplay = (auto == "true");
    
    // Init Sliders
    [...document.querySelectorAll(".block-gallery__slider")].forEach( block => {
            const id = block.getAttribute('data-slider');
            const galleryNav = `[data-gallery-nav="${id}"]`;
            const gallery = `[data-slider="${id}"]`;
            
            const mainOptions = {
                elem: block,
                fade: true,
                num: 1,
                arrows: true,
                mobileArrows: true,
                dots: false,
                slideSpeed,
                autoplaySpeed,
                autoplay,
            }
            
            if (document.querySelector(galleryNav)) {
                new Slider({
                    elem: galleryNav,
                    num: 5,
                    tabNum: 3,
                    mobNum: 3,
                    asNavFor: gallery,
                    centerMode: true,
                    arrows:false,
                    slideSpeed,
                    autoplaySpeed,
                    autoplay,
                });
                mainOptions.asNavFor = galleryNav;  
            }

            new Slider(mainOptions);

        }
    );


};

initGallerySliderBlock();

if ( window.acf ) {
    window.acf.addAction( 'render_block_preview/type=gallery', initGallerySliderBlock);
}
