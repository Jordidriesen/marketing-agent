<?php
/**
 * Popups: printed as native <dialog> elements in the footer and opened by
 * assets/js/popups.js.
 *
 * Any element matching `.atlas-popup-{ID}`, `a[href="#atlas-popup-{ID}"]` or the
 * popup's own trigger selector opens it on click.
 *
 * @package AtlasContentBlocks
 */

defined( 'ABSPATH' ) || exit;

class Atlas_CB_Popups {

	/** @var array Popups placed manually (block or shortcode): ID => settings. */
	private static $manual = array();

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
		// Before footer scripts print (priority 20), so assets enqueued by popup content still load.
		add_action( 'wp_footer', array( __CLASS__, 'print_popups' ), 5 );
	}

	public static function register_assets() {
		wp_register_style( 'atlas-cb-popups', ATLAS_CB_URL . 'assets/css/popups.css', array(), ATLAS_CB_VERSION );
		wp_register_script(
			'atlas-cb-popups',
			ATLAS_CB_URL . 'assets/js/popups.js',
			array(),
			ATLAS_CB_VERSION,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);

		if ( Atlas_CB_Renderer::popups() ) {
			wp_enqueue_style( 'atlas-cb-popups' );
			wp_enqueue_script( 'atlas-cb-popups' );
		}
	}

	/**
	 * Print a popup on this page whatever its conditions, because it was placed
	 * by hand.
	 *
	 * @param int   $id       Popup ID.
	 * @param array $settings Popup settings.
	 */
	public static function add( $id, array $settings ) {
		self::$manual[ $id ] = $settings;
		wp_enqueue_style( 'atlas-cb-popups' );
		wp_enqueue_script( 'atlas-cb-popups' );
	}

	public static function print_popups() {
		$popups = Atlas_CB_Renderer::popups() + self::$manual;

		foreach ( $popups as $id => $settings ) {
			echo self::markup( $id, $settings ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in markup().
		}
	}

	/**
	 * @param int   $id       Popup ID.
	 * @param array $settings Popup settings.
	 *
	 * @return string
	 */
	private static function markup( $id, array $settings ) {
		$content = Atlas_CB_Renderer::render( $id, $settings, false );
		if ( '' === trim( $content ) ) {
			return '';
		}

		$popup = $settings['popup'];
		$label = '' !== $popup['label'] ? $popup['label'] : get_the_title( $id );

		$config = array(
			'id'           => (int) $id,
			'trigger'      => $popup['trigger'],
			'selector'     => $popup['selector'],
			'delay'        => (int) $popup['delay'],
			'scroll'       => (int) $popup['scroll'],
			'frequency'    => $popup['frequency'],
			'days'         => (int) $popup['days'],
			'closeOverlay' => (bool) $popup['close_overlay'],
			'hideOn'       => array_values( $settings['hide_on'] ),
		);

		$close = '<svg width="20" height="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M4 4l12 12M16 4L4 16" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';

		return sprintf(
			'<dialog id="atlas-popup-%1$d" class="atlas-popup atlas-popup--%2$s" aria-label="%3$s" data-atlas-popup="%4$s">'
				. '<div class="atlas-popup__box">'
				. '<button type="button" class="atlas-popup__close" aria-label="%5$s">%6$s</button>'
				. '<div class="atlas-popup__content">%7$s</div>'
				. '</div>'
				. "</dialog>\n",
			(int) $id,
			esc_attr( $popup['size'] ),
			esc_attr( $label ),
			esc_attr( wp_json_encode( $config ) ),
			esc_attr__( 'Close', 'atlas-content-blocks' ),
			$close,
			$content
		);
	}
}
