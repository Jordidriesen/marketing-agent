<?php
/**
 * Block with toc
 *
 * @package WordPress
 * @subpackage ATLAS
 * @since ATLAS 1.0
 */
$block_object = new Block( $block );

loadAcfBlockPreviewImage(__DIR__);

$name = $block_object->block_name();


?>
<section class="block-toc">
    <div class="block-toc__wrapper">

        <?php $toc_title = get_field('toc_title'); ?>
        <?php if ($toc_title) : ?>
            <div class="block-toc__header">
                <h3 class="block-toc__title"><?php echo $toc_title; ?></h3>
            </div>
        <?php endif; ?>

        <?php
        $content = get_the_content();
        if (function_exists('generateIndex') && !empty($content)) :
            $result = generateIndex($content);
        ?>
        <div class="block-toc__content">
            <?php echo $result['index']; ?>
        </div>
        <?php endif; ?>
    </div>
</section>