<?php
/**
 * The content block post type.
 *
 * @package AtlasContentBlocks
 */

defined( 'ABSPATH' ) || exit;

class Atlas_CB_Post_Type {

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );

		// Keep the cached index in step with every change to a block.
		add_action( 'save_post_' . ATLAS_CB_POST_TYPE, array( 'Atlas_CB_Settings', 'flush_index' ) );
		add_action( 'deleted_post', array( __CLASS__, 'maybe_flush' ), 10, 2 );
		add_action( 'transition_post_status', array( __CLASS__, 'flush_on_status' ), 10, 3 );

		// Blocks can be previewed by editors but are not public pages.
		add_action( 'template_redirect', array( __CLASS__, 'protect_single' ) );
		add_filter( 'wp_robots', array( __CLASS__, 'noindex' ) );
	}

	public static function register() {
		register_post_type(
			ATLAS_CB_POST_TYPE,
			array(
				'labels'              => array(
					'name'               => __( 'Content Blocks', 'atlas-content-blocks' ),
					'singular_name'      => __( 'Content Block', 'atlas-content-blocks' ),
					'menu_name'          => __( 'Content Blocks', 'atlas-content-blocks' ),
					'add_new'            => __( 'Add New', 'atlas-content-blocks' ),
					'add_new_item'       => __( 'Add New Content Block', 'atlas-content-blocks' ),
					'edit_item'          => __( 'Edit Content Block', 'atlas-content-blocks' ),
					'new_item'           => __( 'New Content Block', 'atlas-content-blocks' ),
					'view_item'          => __( 'Preview Content Block', 'atlas-content-blocks' ),
					'search_items'       => __( 'Search Content Blocks', 'atlas-content-blocks' ),
					'not_found'          => __( 'No content blocks found.', 'atlas-content-blocks' ),
					'not_found_in_trash' => __( 'No content blocks found in Trash.', 'atlas-content-blocks' ),
					'all_items'          => __( 'All Content Blocks', 'atlas-content-blocks' ),
				),
				'public'              => false,
				'publicly_queryable'  => true,
				'exclude_from_search' => true,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_nav_menus'   => false,
				'show_in_admin_bar'   => false,
				'show_in_rest'        => true,
				'menu_position'       => 25,
				'menu_icon'           => 'dashicons-screenoptions',
				'capability_type'     => 'page',
				'map_meta_cap'        => true,
				'hierarchical'        => false,
				'has_archive'         => false,
				'rewrite'             => false,
				'query_var'           => ATLAS_CB_POST_TYPE,
				'supports'            => array( 'title', 'editor', 'revisions', 'page-attributes' ),
			)
		);
	}

	/**
	 * @param int     $post_id Deleted post ID.
	 * @param WP_Post $post    Deleted post.
	 */
	public static function maybe_flush( $post_id, $post = null ) {
		if ( $post instanceof WP_Post && ATLAS_CB_POST_TYPE === $post->post_type ) {
			Atlas_CB_Settings::flush_index();
		}
	}

	/**
	 * Publishing, unpublishing and trashing do not always pass through save_post.
	 *
	 * @param string  $new_status New status.
	 * @param string  $old_status Old status.
	 * @param WP_Post $post       Post.
	 */
	public static function flush_on_status( $new_status, $old_status, $post ) {
		if ( $new_status !== $old_status && ATLAS_CB_POST_TYPE === $post->post_type ) {
			Atlas_CB_Settings::flush_index();
		}
	}

	/**
	 * Only people who can edit a block may view it on its own (preview).
	 */
	public static function protect_single() {
		if ( ! is_singular( ATLAS_CB_POST_TYPE ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', get_queried_object_id() ) ) {
			global $wp_query;
			$wp_query->set_404();
			status_header( 404 );
			nocache_headers();
		}
	}

	/**
	 * @param array $robots Robots directives.
	 *
	 * @return array
	 */
	public static function noindex( $robots ) {
		if ( is_singular( ATLAS_CB_POST_TYPE ) ) {
			$robots['noindex']  = true;
			$robots['nofollow'] = true;
		}
		return $robots;
	}
}
