<?php
/**
 * Block Name: Map
 *
 * This is the template that displays the map block
 */
$block_object = new Block( $block );
$location     = ! empty( $location ) ? $location : get_field( 'location' );
$title        = ! empty( $title ) ? $title : get_field( 'title' );
$description  = ! empty( $description ) ? $description : get_field( 'description' );

loadAcfBlockPreviewImage(__DIR__);

if ( ! empty( $location ) ): 
	$name = $block_object->block_name();
	
	$map_content = 	'<div class="acf-map" data-marker="' . get_stylesheet_directory_uri() . '/parts/blocks/acf-map/assets/marker.png' . '">
	<div class="marker" data-lat="' . $location['lat'] . '" data-lng="' . $location['lng'] . '"></div></div>';
?>
<section class="block-map acf-custom-block">
	<?php loadStyles(__DIR__, $name); ?>
	<?php echo $map_content;?>

	<div class="map-content">
		<?php if ( ! empty( $title ) ) : ?>
			<h2 class="map-title"><?php echo $title ?></h2>
		<?php endif; ?>
		<?php if ( ! empty( $description ) ) : ?>
			<div class="map-description"><?php echo $description ?></div>
		<?php endif; ?>
	</div>

</section>
<?php endif;
