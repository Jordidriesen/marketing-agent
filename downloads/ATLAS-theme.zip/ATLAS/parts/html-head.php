<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="UTF-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<script id="usercentrics-cmp" src="https://web.cmp.usercentrics.eu/ui/loader.js" data-settings-id="7MrpkzZmoD0pvB" async></script>  
    <script>
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({
            'language': document.documentElement.lang || navigator.language || navigator.userLanguage
        });
    </script>

	<?php wp_head(); ?>
	<?php get_supported_colors('styles'); ?>
	<?php get_spacing_styles(); ?>
	<?php echo Theme_App::render_scripts('head_scripts'); ?>
	
    <script async src="https://rum.corewebvitals.io/cwv/679a3a0b57a4869aed7710d1.js"></script>	
</head>
