<?php
/**
 * Plugin Name:       ATLAS Content Blocks
 * Description:       Reusable content blocks placed at theme locations or shown as popups, with display conditions. Built for the ATLAS theme.
 * Version:           1.0.0
 * Requires at least: 6.3
 * Requires PHP:      7.4
 * Author:            Primion
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       atlas-content-blocks
 * Domain Path:       /languages
 *
 * @package AtlasContentBlocks
 */

defined( 'ABSPATH' ) || exit;

define( 'ATLAS_CB_VERSION', '1.0.0' );
define( 'ATLAS_CB_FILE', __FILE__ );
define( 'ATLAS_CB_DIR', plugin_dir_path( __FILE__ ) );
define( 'ATLAS_CB_URL', plugin_dir_url( __FILE__ ) );

/** Post type that holds the content blocks. */
define( 'ATLAS_CB_POST_TYPE', 'atlas_block' );

/** Post meta key holding a block's settings (one array). */
define( 'ATLAS_CB_META', '_atlas_cb_settings' );

require_once ATLAS_CB_DIR . 'includes/class-settings.php';
require_once ATLAS_CB_DIR . 'includes/class-post-type.php';
require_once ATLAS_CB_DIR . 'includes/class-conditions.php';
require_once ATLAS_CB_DIR . 'includes/class-renderer.php';
require_once ATLAS_CB_DIR . 'includes/class-popups.php';
require_once ATLAS_CB_DIR . 'includes/class-manual.php';

if ( is_admin() ) {
	require_once ATLAS_CB_DIR . 'includes/admin/class-meta-box.php';
	require_once ATLAS_CB_DIR . 'includes/admin/class-list-table.php';
}

add_action( 'plugins_loaded', 'atlas_cb_boot' );

/**
 * Start the plugin.
 */
function atlas_cb_boot() {
	load_plugin_textdomain( 'atlas-content-blocks', false, dirname( plugin_basename( ATLAS_CB_FILE ) ) . '/languages' );

	Atlas_CB_Post_Type::init();
	Atlas_CB_Renderer::init();
	Atlas_CB_Popups::init();
	Atlas_CB_Manual::init();

	if ( is_admin() ) {
		Atlas_CB_Meta_Box::init();
		Atlas_CB_List_Table::init();
	}
}

register_activation_hook( __FILE__, 'atlas_cb_activate' );

/**
 * Register the post type before flushing, so its admin screens resolve at once.
 */
function atlas_cb_activate() {
	Atlas_CB_Post_Type::register();
	flush_rewrite_rules();
}
