<?php
add_filter( 'render_block', 'wrap_post_featured_image_block', 10, 2 );
function wrap_post_featured_image_block( $block_content, $block ) {
	if ( 'core/post-featured-image' === $block['blockName'] ) {
		$block_content = '<div data-styles-id="core-post-featured-image"></div>' . $block_content;
	}
	return $block_content;
}
