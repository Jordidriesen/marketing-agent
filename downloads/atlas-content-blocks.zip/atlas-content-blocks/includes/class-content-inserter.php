<?php
/**
 * Finds insertion points between the top-level elements of rendered post
 * content: after the Nth paragraph or before the Nth heading.
 *
 * Walks the HTML with the core HTML Tag Processor and counts nesting depth,
 * so paragraphs and headings inside columns, groups or other blocks are not
 * counted. Content is expected to close its paragraphs explicitly, as the
 * block editor always does.
 *
 * @package AtlasContentBlocks
 */

defined( 'ABSPATH' ) || exit;

class Atlas_CB_Content_Inserter extends WP_HTML_Tag_Processor {

	/** Elements that never have a closing tag. */
	const VOID = array( 'AREA', 'BASE', 'BR', 'COL', 'EMBED', 'HR', 'IMG', 'INPUT', 'LINK', 'META', 'SOURCE', 'TRACK', 'WBR', 'PARAM', 'KEYGEN' );

	/**
	 * Byte offset to insert at, or null when the content has too few matches.
	 *
	 * @param string $html Rendered content.
	 * @param string $mode after_paragraph or before_heading.
	 * @param int    $n    Which paragraph or heading, from 1.
	 *
	 * @return int|null
	 */
	public static function offset( $html, $mode, $n ) {
		$walker  = new self( $html );
		$depth   = 0;
		$foreign = 0;
		$count   = 0;

		while ( $walker->next_tag( array( 'tag_closers' => 'visit' ) ) ) {
			$tag = $walker->get_tag();

			if ( $walker->is_tag_closer() ) {
				if ( in_array( $tag, self::VOID, true ) ) {
					continue;
				}
				if ( 'SVG' === $tag || 'MATH' === $tag ) {
					$foreign = max( 0, $foreign - 1 );
				}
				$depth = max( 0, $depth - 1 );

				if ( 'after_paragraph' === $mode && 0 === $depth && 'P' === $tag && ++$count === $n ) {
					return $walker->bookmark_offset( true );
				}
				continue;
			}

			if ( 'before_heading' === $mode && 0 === $depth && preg_match( '/^H[1-6]$/', $tag ) && ++$count === $n ) {
				return $walker->bookmark_offset( false );
			}

			// Inside SVG or MathML a self-closing tag has no closer; in HTML the flag is ignored.
			if ( in_array( $tag, self::VOID, true ) || ( $foreign && $walker->has_self_closing_flag() ) ) {
				continue;
			}
			if ( 'SVG' === $tag || 'MATH' === $tag ) {
				$foreign++;
			}
			$depth++;
		}

		return null;
	}

	/**
	 * Start or end offset of the current tag.
	 *
	 * @param bool $end End of the tag rather than its start.
	 *
	 * @return int|null
	 */
	private function bookmark_offset( $end ) {
		if ( ! $this->set_bookmark( 'atlas_cb' ) || ! isset( $this->bookmarks['atlas_cb'] ) ) {
			return null;
		}

		$start = (int) $this->bookmarks['atlas_cb']->start;

		if ( ! $end ) {
			return $start;
		}

		// A closing tag has no attributes, so it ends at the first ">".
		$close = strpos( $this->html, '>', $start );
		return false === $close ? null : $close + 1;
	}
}
