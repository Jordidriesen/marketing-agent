import { slideUp, slideDown } from 'lib/slide';

const trigger = '.single-accordion__title';

const toggleAccordion = (e) => {
    const el = e.target;
    const parent = el.parentElement;
    const elContent = parent.nextElementSibling;
    const wrapper = parent.closest('.block-accordion');

    if (parent.classList.contains('active')) {
        parent.classList.remove('active');
        slideUp(elContent, 250);
    } else {
        if (wrapper && wrapper.classList.contains('singular-open')) {
            wrapper.querySelectorAll('.active').forEach((active) => {
                active.classList.remove('active');
                slideUp(active.nextElementSibling, 250);
            });
        }
        parent.classList.add('active');
        slideDown(elContent, 250);
    }
}

const initAccordion = () => {
    document.querySelectorAll(trigger).forEach((title) => {
        title.addEventListener('click', toggleAccordion);
    });
};

const backendAccordionInit = () => {
    document.addEventListener('click', (e) => {
        if (e.target instanceof Element && e.target.matches(trigger)) {
            toggleAccordion(e);
        }
    });
}

initAccordion();
export { backendAccordionInit };
