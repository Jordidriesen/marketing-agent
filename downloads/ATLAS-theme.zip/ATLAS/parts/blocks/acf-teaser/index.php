<?php
$block_object = new Block( $block );
$name = $block_object->block_name();
$img_id = get_field('teaser_image');
$label = get_field('teaser_label');
$title = get_field('teaser_title');
$content = get_field('teaser_content');
$link = get_field('teaser_link');
$image_full_width = get_field('teaser_image_full_width');
$image_size = get_field('teaser_image_size');

if ($image_size === 'big') {
	$img = wp_get_attachment_image($img_id, 'teaser-big', false, 'data-object-fit');
} else if ($image_size === 'small') {
	$img = wp_get_attachment_image($img_id, 'teaser-small', false, 'data-object-fit');
} else {
	$img = wp_get_attachment_image($img_id, 'teaser-img', false, 'data-object-fit');
}

$class = ( $image_full_width || empty($img)) ? $block_object->block_class()  . ' block-teaser--full' : $block_object->block_class();

loadAcfBlockPreviewImage(__DIR__);

if( $link ): 
	$link_url = $link['url'];
	$link_title = $link['title'];
	$link_target = $link['target'] ? $link['target'] : '_self';
?>
<a class="<?php echo $class; ?>" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>">
<?php else: ?>
<div class="<?php echo $class; ?>">
<?php endif; ?>	
	<?php echo loadStyles(__DIR__, $name); ?>
	<div class="block-teaser__row">
	<?php if (!empty($img)) : ?>
		<div class="block-teaser__img-wrapper">
			<?php echo $img; ?>
		</div>
	<?php endif; ?>
		<div class="block-teaser__content-wrapper">
		<?php if (!empty($label)) : ?>
			<span class="block-teaser__label"><?php echo $label; ?></span>
		<?php endif; ?>
		<?php if (!empty($title)) : ?>
			<h3 class="block-teaser__title h2"><?php echo $title; ?></h3>
		<?php endif; ?>
		<?php if (!empty($content)) : ?>
			<div class="block-teaser__content"><?php echo $content; ?></div>
		<?php endif; ?>
		<?php 
		if( $link ): 
		?>
			<div class="wp-block-button block-teaser__button"><div class="wp-block-button__link block-teaser__link"></div></div>
		<?php endif; ?>
		</div>
	</div>

<?php if( $link ): ?>
</a>
<?php else: ?>
</div>
<?php
endif;