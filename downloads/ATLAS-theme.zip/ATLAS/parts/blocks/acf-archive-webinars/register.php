<?php
function init_block_archive_webinars()
{
    if (! function_exists('acf_register_block')) {
        return;
    }

    acf_register_block(array(
        'name'              => 'archive_webinars',
        'title'             => __('Archiv Webinare / Archive Webinars', 'ATLAS'),
        'description'       => __('Webinare Archiv', 'ATLAS'),
        'category'          => 'custom_blocks',
        'icon'              => 'media-code',
        'mode'              => 'auto',
        'keywords'          => array('archive', 'webinar', 'webinare', 'neu'),
        'align'             => 'full',
        'supports'          => array(
            'align' => false,
        ),
        'example'         => [
            'attributes' => [
                'mode' => 'auto',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-archive-webinars/index.php',
        'enqueue_assets'  => function () {
            $block_directory = basename(__DIR__);
            wp_enqueue_style(
                'ATLAS/' . $block_directory,
                get_template_directory_uri() . '/parts/blocks/' . $block_directory . '/style.css'
            );
        }
    ));
}

add_action('acf/init', 'init_block_archive_webinars');
