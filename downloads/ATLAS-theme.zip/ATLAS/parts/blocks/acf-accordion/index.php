<?php
/**
 * Block with accordion
 *
 * @package WordPress
 * @subpackage ATLAS
 * @since ATLAS 1.0
 */
$block_object = new Block( $block );

loadAcfBlockPreviewImage(__DIR__);

$accordion = get_field('accordion_single');

if ( have_rows( 'accordion_single' ) ) :
    $name = $block_object->block_name();
    $layout_counter = $block['id'];
?>
<div class="wp-block-custom-accordion block-accordion">
    <div class="block-accordion__body">
        <?php
            while ( have_rows( 'accordion_single' ) ) : the_row();
            $title = get_sub_field( 'accordion_title' );
            // $content = get_sub_field( 'accordion_content' );
            $is_open = get_sub_field( 'accordion_state' );
            // $modules = get_sub_field( 'accordion_modules' );
            $editor = get_sub_field( 'accordion_editor' );
        ?>

        <div class="wp-block-custom-accordion-single single-accordion">
            <div class="single-accordion__header <?php echo esc_attr( $is_open ? 'active' : '' ); ?>">
                <h3 class="single-accordion__title"><?php echo esc_html( $title ); ?></h3>
            </div>
            
            <div class="single-accordion__content">
            <?php echo apply_filters('the_content', $editor); ?>
            </div>
            
        </div>

        <?php endwhile; ?>
    </div>
</div>

<?php
endif;