const { __ } = wp.i18n;
const {registerBlockStyle} = wp.blocks;

const styles = [
    {
        name: 'fill-secondary',
        label: __('Fill Secondary', 'ATLAS')
    },
    {
        name: 'link-only',
        label: __('Link Only', 'ATLAS')
    }
];

wp.domReady(() => {
    styles.forEach(style => {
        registerBlockStyle('core/button', style);
    });
});