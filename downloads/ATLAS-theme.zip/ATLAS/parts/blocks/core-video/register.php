<?php
add_filter( 'render_block', 'wrap_video_block', 10, 2 );
function wrap_video_block( $block_content, $block ) {
	if ( 'core/video' === $block['blockName'] ) {
		$block_content = '<div data-styles-id="core-video"></div>' . $block_content;
	}
	return $block_content;
}

add_filter( 'render_block_core/video', 'add_aria_label_from_caption_to_video_block', 10, 2 );
function add_aria_label_from_caption_to_video_block( $block_content, $block ) {
	if ( empty( $block_content ) ) {
		return $block_content;
	}

	$caption = '';
	if ( preg_match( '/<figcaption[^>]*>(.*?)<\/figcaption>/is', $block_content, $matches ) ) {
		$caption = trim( wp_strip_all_tags( $matches[1] ) );
	}

	if ( empty( $caption ) ) {
		return $block_content;
	}

	$label_id = 'video-caption-' . uniqid();

	$label_html = sprintf(
		'<span id="%s" class="screen-reader-text">%s</span>',
		esc_attr( $label_id ),
		esc_html( $caption )
	);

	$processor = new WP_HTML_Tag_Processor( $block_content );

	if ( $processor->next_tag( array( 'tag_name' => 'video' ) ) ) {
		$processor->set_attribute( 'aria-labelledby', $label_id );
	}

	return $label_html . $processor->get_updated_html();
}
