<?php

add_action('admin_head', 'custom_admin_style');

function custom_admin_style() {
    echo '<style>
    html {
        font-size: 62.5%;
    } 
    .editor-styles-wrapper {
        font-size: 1.8rem;
        line-height: 1.333;
    }
    </style>';
}
