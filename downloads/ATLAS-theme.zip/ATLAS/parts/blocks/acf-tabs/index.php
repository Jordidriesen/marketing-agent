<?php
$block_object = new Block( $block );
$name = $block_object->block_name();
$tabs = get_field('tabs_row');
$tabs_design = get_field('tabs_design');

loadAcfBlockPreviewImage(__DIR__, $is_preview);

if ( !empty($tabs) ) :
?>
<section class="<?php echo $block_object->block_class(); ?> <?php echo $tabs_design; ?>">
    <?php echo loadStyles(__DIR__, $name); ?>
    <div class="tabs__list-wrapper">
        <div>
            <div class="tabs__head">
                <div class="tabs_head-wrapper">
                    <ul class="tabs__head-list">
                    <?php
                        $iter = 0;
                        foreach ($tabs as $tab) :
                            $el_class = 'tabs__link';
                            if($iter == 0){
                                $el_class .= ' active';
                            }
                            $title = $tab['title'];
                            ?><li class="<?php echo $el_class; ?>"><a class="tabs__link-inner" href="<?php echo '#'.$iter++; ?>"><?php
                                echo $title;
                            ?></a></li><?php
                        endforeach;
                    ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="tabs__content-wrapper">
        <div class="tabs__col">
        <?php
            $iter = 0;
            foreach ($tabs as $tab) :
                $el_class = 'tabs__content';
                if($iter == 0){
                    $el_class .= ' active';
                }
                $content = $tab['content'];
        ?>
            <div class="<?php echo $el_class; ?>" data-tab-id="<?php echo '#'.$iter++; ?>">
                <?php if ($tab['type'] === 'tabs') : ?>
                    <?php echo apply_filters('the_content',$tab['post']->post_content); ?>
                <?php else : ?>
                    <?php echo apply_filters('the_content', $content); ?>
                <?php endif; ?>
            </div>
        <?php
            endforeach;
        ?>
        </div>
    </div>
</section>
<?php
endif;