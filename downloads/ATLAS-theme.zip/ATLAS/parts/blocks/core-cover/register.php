<?php
add_filter( 'render_block', 'wrap_cover_block', 10, 2 );
function wrap_cover_block( $block_content, $block ) {
	if ( 'core/cover' === $block['blockName'] ) {
		$block_content = '<div data-styles-id="core-cover"></div>' . $block_content;
	}
	return $block_content;
}
