/**
 * ATLAS Content Blocks: settings meta box behaviour.
 * Shows the fields that apply to the chosen type, trigger, structure and
 * conditions mode, manages the location rows (one use per location), runs
 * the conditions dialog (Apply keeps the changes, Cancel and Escape restore
 * them) and keeps the summaries up to date. Rules that miss a required value
 * are dropped on save.
 */
(function () {
	'use strict';

	var root = document.querySelector('.atlas-cb-settings');
	if (!root) {
		return;
	}

	var strings = window.atlasCbAdmin || {};
	var counter = Date.now();

	var value = function (selector, fallback) {
		var field = root.querySelector(selector);
		if (!field) {
			return fallback;
		}
		if (field.type === 'checkbox') {
			return field.checked ? '1' : '0';
		}
		return field.value;
	};

	var checked = function (name, fallback) {
		var field = root.querySelector('input[name="' + name + '"]:checked');
		return field ? field.value : fallback;
	};

	// Replace %s, %d and %1$s style placeholders, like sprintf() in the PHP summaries.
	var format = function (text, args) {
		var next = 0;
		return String(text || '').replace(/%(?:(\d+)\$)?[sd]/g, function (match, position) {
			var arg = position ? args[parseInt(position, 10) - 1] : args[next++];
			return arg === undefined ? '' : String(arg);
		});
	};

	var selectedText = function (select) {
		var option = select ? select.options[select.selectedIndex] : null;
		return option ? option.textContent.trim() : '';
	};

	/* Popup trigger and container summaries, as Atlas_CB_Summary::trigger(). */

	var syncDetailsSummaries = function () {
		var trigger = root.querySelector('.atlas-cb-trigger-summary');
		var formats = strings.triggers || {};
		var current = value('#atlas-cb-trigger', 'click');
		var fields = {
			delay: '#atlas-cb-delay',
			scroll: '#atlas-cb-scroll',
			scroll_unit: '#atlas-cb-scroll-unit',
			scroll_element: '#atlas-cb-scroll-element',
			inactivity: '#atlas-cb-inactivity',
			pages: '#atlas-cb-pages'
		};

		if (trigger && formats[current]) {
			trigger.textContent = format(formats[current].format, formats[current].keys.map(function (key) {
				var field = value(fields[key], '');
				// Numbers print as whole numbers, as %d does in PHP.
				return key === 'scroll_unit' || key === 'scroll_element' ? field.trim() : String(parseInt(field, 10) || 0);
			}));
		}

		var structure = root.querySelector('.atlas-cb-structure-summary');
		if (structure) {
			structure.textContent = selectedText(root.querySelector('#atlas-cb-structure'));
		}
	};

	// Mirror the current choices in data attributes; admin.css shows and hides fields from them.
	var sync = function () {
		root.dataset.type = checked('atlas_cb[type]', 'hook');
		root.dataset.placement = checked('atlas_cb[placement]', 'locations');
		root.dataset.mode = checked('atlas_cb[conditions][mode]', 'basic');
		root.dataset.trigger = value('#atlas-cb-trigger', 'click');
		root.dataset.relaunch = value('#atlas-cb-relaunch', 'always');
		root.dataset.size = value('#atlas-cb-size', 'medium');
		root.dataset.structure = value('#atlas-cb-structure', 'default');
		root.dataset.backdrop = value('input[type="checkbox"][name="atlas_cb[popup][backdrop]"]', '1');
		syncDetailsSummaries();
	};

	var template = function (selector) {
		var element = root.querySelector(selector);
		return element ? element.innerHTML : '';
	};

	/* Locations: one select per row, each location used once. */

	var locationList = root.querySelector('.atlas-cb-locations');
	var extrasHolder = root.querySelector('.atlas-cb-location-extras');
	var addLocationButton = root.querySelector('.atlas-cb-add-location');

	var locationSelects = function () {
		return locationList ? Array.prototype.slice.call(locationList.querySelectorAll('.atlas-cb-location-select')) : [];
	};

	// Disable in each row the locations other rows use, move each extra field
	// (paragraph number, heading number, hook name) into the row that needs it,
	// and park the rest so they still submit their value.
	var syncLocations = function () {
		if (!locationList) {
			return;
		}
		var selects = locationSelects();
		var used = selects.map(function (select) {
			return select.value;
		});

		selects.forEach(function (select) {
			Array.prototype.forEach.call(select.options, function (option) {
				option.disabled = option.value !== select.value && used.indexOf(option.value) !== -1;
			});
		});

		root.querySelectorAll('.atlas-cb-location-extra').forEach(function (extra) {
			var index = used.indexOf(extra.getAttribute('data-location'));
			var slot = index === -1 ? extrasHolder : selects[index].closest('.atlas-cb-location').querySelector('.atlas-cb-location-slot');
			if (slot && extra.parentNode !== slot) {
				slot.appendChild(extra);
			}
		});

		if (addLocationButton) {
			var total = selects.length ? selects[0].options.length : 1;
			addLocationButton.disabled = selects.length >= total;
		}
	};

	var addLocation = function () {
		var html = template('.atlas-cb-location-template').replace(/__l__/g, String(counter++));
		locationList.insertAdjacentHTML('beforeend', html);
		var select = locationList.lastElementChild.querySelector('.atlas-cb-location-select');
		var used = locationSelects().map(function (other) {
			return other === select ? null : other.value;
		});
		var free = Array.prototype.filter.call(select.options, function (option) {
			return used.indexOf(option.value) === -1;
		})[0];
		if (free) {
			select.value = free.value;
		}
		syncLocations();
		return select;
	};

	/* Conditions: rule rows, groups and their summary. */

	// Show only the value fields the chosen rule uses.
	var syncRule = function (row) {
		var select = row.querySelector('.atlas-cb-rule-select');
		var option = select.options[select.selectedIndex];
		var fields = option ? (option.getAttribute('data-fields') || '').split(' ') : [];

		row.querySelectorAll('.atlas-cb-field').forEach(function (field) {
			field.hidden = fields.indexOf(field.getAttribute('data-field')) === -1;
		});
	};

	var addRule = function (table) {
		var negation = table.getAttribute('data-negation') === '1' ? '1' : '0';
		var html = template('.atlas-cb-rule-template[data-negation="' + negation + '"]')
			.replace(/__name__/g, table.getAttribute('data-name'))
			.replace(/__i__/g, String(counter++));
		var body = table.querySelector('tbody');
		body.insertAdjacentHTML('beforeend', html);
		var row = body.lastElementChild;
		syncRule(row);
		return row;
	};

	// Value of a rule field, or '' when the rule does not use it.
	var ruleField = function (row, field) {
		var wrap = row.querySelector('.atlas-cb-field[data-field="' + field + '"]');
		if (!wrap || wrap.hidden) {
			return '';
		}
		if (field === 'days') {
			return wrap.querySelectorAll('input:checked').length ? '1' : '';
		}
		var input = wrap.querySelector('input, select');
		return input ? input.value.trim() : '';
	};

	// The values Atlas_CB_Settings::rule_complete() requires; rows without them are dropped on save.
	var required = {
		post_ids: ['ids'],
		child_of: ['ids'],
		post_author: ['ids'],
		post_term: ['taxonomy', 'terms'],
		term_archive: ['taxonomy'],
		page_template: ['value'],
		url: ['value'],
		referer: ['value'],
		cookie: ['name'],
		user_role: ['role'],
		recurring: ['days'],
		language: ['language']
	};

	var ruleComplete = function (row, rule) {
		if (rule === 'date_range') {
			return ruleField(row, 'start') !== '' || ruleField(row, 'end') !== '';
		}
		return (required[rule] || []).every(function (field) {
			return ruleField(row, field) !== '';
		});
	};

	// One rule as Atlas_CB_Summary::rule() describes it, or null if it will not be saved.
	var describeRule = function (row) {
		var select = row.querySelector('.atlas-cb-rule-select');
		if (!select || !ruleComplete(row, select.value)) {
			return null;
		}
		var text = selectedText(select);
		var keys = strings.valueKeys || [];
		for (var i = 0; i < keys.length; i++) {
			var field = keys[i];
			var fieldValue = ruleField(row, field);
			// Lists are saved without spaces, IDs as unique whole numbers.
			if (field === 'ids') {
				fieldValue = fieldValue.split(/[\s,]+/).map(function (id) {
					return Math.abs(parseInt(id, 10)) || 0;
				}).filter(function (id, index, all) {
					return id > 0 && all.indexOf(id) === index;
				}).join(',');
			} else if (field === 'terms') {
				fieldValue = fieldValue.split(',').map(function (term) {
					return term.trim();
				}).filter(function (term) {
					return term !== '';
				}).join(',');
			}
			if (fieldValue !== '') {
				text += ': ' + fieldValue;
				break;
			}
		}
		var not = row.querySelector('.atlas-cb-rule-not');
		return not && not.value === '1' ? strings.not + ' ' + text : text;
	};

	var describeRules = function (container) {
		return Array.prototype.map.call(container.querySelectorAll('.atlas-cb-rule'), describeRule).filter(function (text) {
			return text !== null;
		});
	};

	// The same text as Atlas_CB_Summary::conditions().
	var conditionsSummary = function () {
		if (checked('atlas_cb[conditions][mode]', 'basic') === 'advanced') {
			var groups = [];
			root.querySelectorAll('.atlas-cb-groups .atlas-cb-group').forEach(function (group) {
				var rules = describeRules(group);
				if (rules.length) {
					groups.push('(' + rules.join(' + ') + ')');
				}
			});
			return groups.length ? groups.join(' ' + strings.or + ' ') : strings.nowhere;
		}

		var include = describeRules(root.querySelector('table[data-name="atlas_cb[conditions][include]"]'));
		var exclude = describeRules(root.querySelector('table[data-name="atlas_cb[conditions][exclude]"]'));
		if (!include.length) {
			return strings.nowhere;
		}
		return exclude.length ? format(strings.except, [include.join(', '), exclude.join(', ')]) : include.join(', ');
	};

	/* Conditions dialog. */

	var dialog = root.querySelector('.atlas-cb-dialog');
	var editButton = root.querySelector('.atlas-cb-edit-conditions');
	var summary = root.querySelector('.atlas-cb-conditions-summary');
	var snapshot = null;

	// A copy of the editor that keeps what is typed, ticked and chosen.
	var copyEditor = function () {
		var editor = dialog.querySelector('.atlas-cb-conditions-editor');
		var copy = editor.cloneNode(true);
		var from = editor.querySelectorAll('input, select, textarea');
		var to = copy.querySelectorAll('input, select, textarea');
		Array.prototype.forEach.call(from, function (field, i) {
			if (field.tagName === 'SELECT') {
				Array.prototype.forEach.call(field.options, function (option, j) {
					to[i].options[j].selected = option.selected;
				});
			} else if (field.type === 'checkbox' || field.type === 'radio') {
				to[i].checked = field.checked;
			} else {
				to[i].value = field.value;
			}
		});
		return copy;
	};

	var openDialog = function () {
		snapshot = copyEditor();
		dialog.showModal();
	};

	var closeDialog = function () {
		if (dialog.open) {
			dialog.close();
		}
		snapshot = null;
		editButton.focus();
	};

	var applyDialog = function () {
		summary.textContent = conditionsSummary();
		closeDialog();
	};

	var cancelDialog = function () {
		if (snapshot) {
			dialog.querySelector('.atlas-cb-conditions-editor').replaceWith(snapshot);
			sync();
		}
		closeDialog();
	};

	if (dialog && editButton && typeof dialog.showModal === 'function') {
		editButton.addEventListener('click', openDialog);
		dialog.querySelector('.atlas-cb-dialog-apply').addEventListener('click', applyDialog);
		dialog.querySelector('.atlas-cb-dialog-cancel').addEventListener('click', cancelDialog);
		// Escape cancels.
		dialog.addEventListener('cancel', function (event) {
			event.preventDefault();
			cancelDialog();
		});
		// Closed some other way (the browser can force Escape through): still restore.
		dialog.addEventListener('close', function () {
			if (snapshot) {
				cancelDialog();
			}
		});
	} else if (dialog) {
		// No dialog support: show the editor in place.
		dialog.setAttribute('open', '');
		dialog.classList.add('atlas-cb-dialog-inline');
		if (editButton) {
			editButton.hidden = true;
		}
	}

	/* Events. */

	root.addEventListener('change', function (event) {
		var target = event.target;

		if (target.classList.contains('atlas-cb-rule-select')) {
			syncRule(target.closest('.atlas-cb-rule'));
		}

		if (target.classList.contains('atlas-cb-location-select')) {
			syncLocations();
		}

		// "At these locations" with no rows yet: start with one.
		if (target.name === 'atlas_cb[placement]' && target.value === 'locations' && !locationSelects().length) {
			addLocation();
		}

		// "Default" colour: a disabled colour input sends nothing, which saves as the default.
		if (target.classList.contains('atlas-cb-colour-default')) {
			var input = document.getElementById(target.getAttribute('data-target'));
			if (input) {
				input.disabled = target.checked;
			}
		}

		sync();
	});

	// Typed values (delay, scroll amount and so on) update the trigger summary at once.
	root.addEventListener('input', function (event) {
		if (event.target.closest('.atlas-cb-details')) {
			syncDetailsSummaries();
		}
	});

	root.addEventListener('click', function (event) {
		var target = event.target;

		if (target.classList.contains('atlas-cb-add-location')) {
			addLocation().focus();
		}

		if (target.classList.contains('atlas-cb-remove-location')) {
			target.closest('.atlas-cb-location').remove();
			syncLocations();
			if (!locationSelects().length) {
				// No rows left: the block is placed by hand only.
				var manual = root.querySelector('input[name="atlas_cb[placement]"][value="manual"]');
				if (manual) {
					manual.checked = true;
					sync();
					manual.focus();
				}
			} else {
				addLocationButton.focus();
			}
		}

		if (target.classList.contains('atlas-cb-add-rule')) {
			addRule(target.closest('.atlas-cb-rules')).querySelector('.atlas-cb-rule-select').focus();
		}

		if (target.classList.contains('atlas-cb-remove-rule')) {
			var row = target.closest('.atlas-cb-rule');
			var table = row.closest('.atlas-cb-rules');
			row.remove();
			table.querySelector('.atlas-cb-add-rule').focus();
		}

		if (target.classList.contains('atlas-cb-add-group')) {
			var groups = root.querySelector('.atlas-cb-groups');
			var html = template('.atlas-cb-group-template').replace(/__g__/g, String(counter++));
			groups.insertAdjacentHTML('beforeend', html);
			var group = groups.lastElementChild;
			group.querySelectorAll('.atlas-cb-rule').forEach(syncRule);
			group.querySelector('.atlas-cb-rule-select').focus();
		}

		if (target.classList.contains('atlas-cb-remove-group')) {
			target.closest('.atlas-cb-group').remove();
			root.querySelector('.atlas-cb-add-group').focus();
		}
	});

	root.querySelectorAll('.atlas-cb-groups .atlas-cb-rule, .atlas-cb-only-mode-basic .atlas-cb-rule').forEach(syncRule);
	syncLocations();
	sync();
})();
