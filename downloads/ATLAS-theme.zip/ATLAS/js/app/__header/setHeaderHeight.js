/* eslint-disable import/no-default-export */
const headerHeight = {
    mainHeader: document.querySelector('.main-header'),
    mainHeaderFixed: document.querySelector('.main-header__fixed'),

    setHeaderHeight() {
        if (typeof(this.mainHeader) === 'undefined' && this.mainHeader === null) {
            return;
        }
        const mainHeaderFixedHeight = this.mainHeaderFixed.getBoundingClientRect().height;
    
        // this.mainHeader.style.height = `${mainHeaderFixedHeight}px`;
        // this.mainHeader.style.height = `0px`;
    },

    init() {
        this.setHeaderHeight();
    }
}

export default headerHeight;
