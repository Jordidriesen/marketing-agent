class ThemeToggle {
    constructor(lightSelector = "[data-set-theme='light']", darkSelector = "[data-set-theme='dark']", storageKey = 'theme') {
        this.lightBtn = [...document.querySelectorAll(lightSelector)];
        this.darkBtn = [...document.querySelectorAll(darkSelector)];
        this.storageKey = storageKey;
        this.html = document.documentElement;
    }

    init() {
        if (!this.lightBtn.length && !this.darkBtn.length) return;

        // Theme beim Laden setzen
        this.loadTheme();

        // Event Listener für Buttons
        this.lightBtn.forEach(btn => btn.addEventListener('click', () => this.setTheme('light')));
        this.darkBtn.forEach(btn => btn.addEventListener('click', () => this.setTheme('dark')));
    }

    setTheme(theme) {
        // Attribut setzen
        this.html.setAttribute('data-theme', theme);

        // Im LocalStorage speichern
        localStorage.setItem(this.storageKey, theme);
    }

    loadTheme() {
        const savedTheme = localStorage.getItem(this.storageKey);

        if (savedTheme) {
            // Gespeichertes Theme anwenden
            this.setTheme(savedTheme);
        } else {
            // Kein gespeichertes Theme → Systempräferenz verwenden
            const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            const defaultTheme = prefersDark ? 'dark' : 'light';

            this.setTheme(defaultTheme);
            localStorage.setItem(this.storageKey, defaultTheme);
        }
    }
}

export default new ThemeToggle();
