<?php
if ( isset($id) ):
	$img = get_the_post_thumbnail($id,'news-image');
	$title = get_the_title($id);
	$date = get_field('event_date', $id);
	$date_end = get_field('event_date_end', $id);
	$short_desc = get_the_excerpt($id);
	$link_url = get_permalink($id);
	$link_target = isset($link_target) ? $link_target : '_self';
	$link_title = $btn_txt ? $btn_txt : __('View event', 'ATLAS');

	$event_location = get_field('event_location', $id);
	$event_location_short = get_field('event_location_short', $id);

	$event_formats = get_the_terms($id, 'event-format');
	$term = ($event_formats && !is_wp_error($event_formats)) ? $event_formats[0] : false;
?>
<div class="single-event">
	<?php loadStyles(__DIR__, 'single-event'); ?>
	<div class="single-event__wrapper">
	<?php if (!empty($img)) : ?>
		<figure class="single-event__img">
			<?php if ( $term ) : ?>
			<span class="single-event__term"><?php echo esc_html( $term->name ); ?></span>
			<?php endif; ?>

			<?php echo $img; ?>
		</figure>
	<?php endif; ?>
		<div class="single-event__content">

			<div class="single-event__meta">
				<?php
				if (!empty($date_end)) {
					$start = strtotime($date);
					$end = strtotime($date_end);

					if (date_i18n('Y', $start) !== date_i18n('Y', $end)) {
						$date = date_i18n('j M Y', $start) . ' - ' . date_i18n('j M Y', $end);
					} elseif (date_i18n('n', $start) !== date_i18n('n', $end)) {
						$date = date_i18n('j M', $start) . ' - ' . date_i18n('j M Y', $end);
					} else {
						$date = date_i18n('j', $start) . ' - ' . date_i18n('j M Y', $end);
					}
				}
				if (!empty($date)) : ?>
					<time class="single-event__date" datetime="<?php echo $date; ?>"><?php echo $date; ?></time>
				<?php endif; ?>

				<?php if (!empty($event_location)) : ?>
					<span class="single-event__meta--space"> · </span>
					<span class="single-event__location"><?php echo !empty($event_location_short) ? $event_location_short : $event_location; ?></span>
				<?php endif; ?>
			</div>
			<h3 class="single-event__title" role="heading"><?php echo $title; ?></h3>
			<?php if (!empty($short_desc)) : ?>
			<span class="single-event__desc"><?php echo $short_desc; ?></span>
		<?php endif; ?>	
			<?php $name = 'core-button';?>
			<?php loadStylesDep('blocks/core-button', $name); ?>
			<div class="wp-block-button is-style-link-only"><a class="wp-block-button__link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a></div>
		</div>
	</div>
</div>
<?php
endif;