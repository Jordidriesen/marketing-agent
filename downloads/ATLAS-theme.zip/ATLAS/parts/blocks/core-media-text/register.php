<?php
add_filter( 'render_block', 'wrap_media_text_block', 10, 2 );
function wrap_media_text_block( $block_content, $block ) {
	if ( 'core/media-text' === $block['blockName'] ) {
		$block_content = '<div data-styles-id="core-media-text"></div>' . $block_content;
	}
	return $block_content;
}
