<?php

/**
 * Theme_App
 *
 * This is a class for general / global Theme App settings and methods
 *
 */
class Theme_App {
	public static
		$license_secret_key = '5d84a0c62df833.06541902',
		$license_URL_request = 'http://smarttec-bt.vh';

	public function __construct() {
//		$this->init_theme_licensing();
	}

	private function init_theme_licensing() {
		function check_license_on_init() {
			Theme_App::check_license();
		}

		add_action( 'init', 'check_license_on_init' );
	}


	/**
	 * Render custom theme scripts provided by ACF custom repeater field.
	 * The repeated textarea field for script has to have a `script` slug to work properly in this function
	 *
	 * @param string $field_slug
	 *
	 * @return string
	 */
	public static function render_scripts( string $field_slug ): string {
		if ( empty( $field_slug ) ) {
			return '';
		}

		$field = get_field( $field_slug, 'options' );

		if ( ! isset( $field ) || empty( $field ) || ! is_array( $field ) ) {
			return '';
		}

		$scripts = '';
		foreach ( $field as $script ) {
			if ( isset( $script['script'] ) && ! empty( $script['script'] ) ) {
				$scripts .= $script['script'] . "\r\n";
			}
		}

		return $scripts;
	}

	// TODO : Make it executed once per some time, not with every site refresh
	public static function check_license() {
		$error_html = '';

		if ( ! function_exists( 'get_field' ) ) {
			$error_html = 'ACF Plugin not activated';

			self::render_error_message( $error_html );

			return;
		}

		// prepare the data
		$postURL   = self::$license_URL_request;
		$secretKey = self::$license_secret_key;

		$api_params = [
			'slm_action'  => 'slm_check',
			'secret_key'  => $secretKey,
			'license_key' => get_field( 'license_key', 'options' ),
		];

		// send data to API post URL
		$response = wp_remote_get( add_query_arg( $api_params, $postURL ), array( 'timeout' => 2, 'sslverify' => false ) );

		// Check for error in the response
		if ( is_wp_error( $response ) ) {
			$error_html .= '<h3>' . __( 'Unexpected Error!', 'ATLAS' ) . '</h3>';
			$error_html .= '<p>' . __( 'The query returned with an error.', 'ATLAS' ) . '</p>';

			self::render_error_message( $error_html );

			return;
		}

		// Process the return values
		$decoded_response = json_decode( wp_remote_retrieve_body( $response ) );

		if ( $decoded_response->result != 'success' ) {
			$error_html .= '<p>' . __( 'Bitte aktivieren Sie ', 'ATLAS' );
			$error_html .= '<a href="' . admin_url( 'admin.php?page=acf-options-license' ) . '">' . __( 'Ihre Lizenz im Backend. ', 'ATLAS' ) . '</a>';
			$error_html .= __( 'Der Lizenzschlüssel wurde Ihnen mit der Rechnung zugeschickt. Sollten Sie Fragen haben, steht Ihnen der Smarttec Support gerne zur Seite.', 'ATLAS' ) . '</p>';
			$error_html .= '<p><a href="mailto:support@smarttec.biz">' . __( 'support@smarttec.biz', 'ATLAS' ) . '</a></p>';
			$error_html .= '<p><a href="tel:0621/490998-0">' . __( '0621/490998-0', 'ATLAS' ) . '</a></p>';
			$error_html .= '<p > ' . __( 'The following message was returned from the server: ', 'ATLAS' ) . $decoded_response->message . ' </p > ';

			self::render_error_message( $error_html );

			return;

		}

		if ( $decoded_response->status != 'active' ) {
			$error_html .= '<p > ' . __( 'Your license key has not been activated yet or has been expired/blocked. Contact with Smarttec support team', 'ATLAS' ) . ' </p > ';
			$error_html .= '<p><a href="mailto:support@smarttec.biz">' . __( 'support@smarttec.biz', 'ATLAS' ) . '</a></p>';
			$error_html .= '<p><a href="tel:0621/490998-0">' . __( '0621/490998-0', 'ATLAS' ) . '</a></p>';

			self::render_error_message( $error_html );

			return;
		}
	}

	private static function render_error_message( $error ) {
		if ( ! empty( $error ) ) {
			if ( is_admin() ) {
				add_action( 'admin_notices', function () use ( $error ) { ?>
                    <div class="notice notice-error"><?php echo $error; ?></div>
				<?php } );
			} else {
				wp_die( $error );
			}
		}
	}
}