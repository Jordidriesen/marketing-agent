<?php
/**
 * Script loading hygiene
 * ---------------------------------------------------------------------------------------
 *
 * Front-end only tweaks to how WordPress core scripts load. Each one can be switched
 * off with its filter, which is also the rollback.
 *
 * @package WordPress
 * @subpackage ATLAS
 */

/**
 * Drop jQuery Migrate on the front end. It only adds back APIs that were removed from
 * jQuery and logs warnings about them; the theme does not use them.
 * Runs on wp_enqueue_scripts rather than wp_default_scripts, because a plugin may
 * set up the scripts registry before the theme is loaded.
 * Roll back: add_filter( 'atlas_remove_jquery_migrate', '__return_false' );
 */
function atlas_remove_jquery_migrate() {
	if ( is_admin() || ! apply_filters( 'atlas_remove_jquery_migrate', true ) ) {
		return;
	}

	$scripts = wp_scripts();

	if ( ! isset( $scripts->registered['jquery'] ) ) {
		return;
	}

	$jquery       = $scripts->registered['jquery'];
	$jquery->deps = array_values( array_diff( $jquery->deps, array( 'jquery-migrate' ) ) );
}
add_action( 'wp_enqueue_scripts', 'atlas_remove_jquery_migrate', 1 );

/**
 * Optionally print jQuery in the footer instead of the head, so it stops blocking
 * rendering. Off by default: any inline script that calls jQuery before the footer
 * (in post content, ACF "head_scripts"/"begin_scripts" options or a plugin) would
 * break. Switch on only after checking for those:
 * add_filter( 'atlas_jquery_in_footer', '__return_true' );
 */
function atlas_jquery_in_footer() {
	if ( is_admin() || ! apply_filters( 'atlas_jquery_in_footer', false ) ) {
		return;
	}

	$scripts = wp_scripts();
	foreach ( array( 'jquery', 'jquery-core', 'jquery-migrate' ) as $handle ) {
		if ( isset( $scripts->registered[ $handle ] ) ) {
			$scripts->add_data( $handle, 'group', 1 );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'atlas_jquery_in_footer', 1 );
