<?php
function init_block_testimonials() {
    if ( ! function_exists( 'acf_register_block' ) ) {
        return;
    }

    acf_register_block( array(
        'name'              => 'testimonials',
        'title'             => __( 'Kundenrezensionen / Testimonials', 'ATLAS' ),
        'description'       => __( 'Testimonials', 'ATLAS' ),
        'category'          => 'custom_blocks',
        'icon'              => 'slides',
        'mode'              => 'auto',
        'keywords'          => array( 'slider', 'testimonials' ),
        'align'             => 'full',
        'supports'          => array(
			'align' => false
        ),
		'example'         => [
            'attributes' => [
                'mode' => 'auto',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-testimonials/index.php',
        'enqueue_assets'  => function () {
			wp_enqueue_script(
				'ATLAS/acf-testimonials',
                get_template_directory_uri() . '/parts/blocks/acf-testimonials/index.min.js',
                [ 'splide_script' ],
                false,
                array(
                    'in_footer' => true,
                    'strategy'  => 'defer',
                )
			);
		}
    ));
}

add_action( 'acf/init', 'init_block_testimonials' );