<?php
function custom_block_registration_spacing() {
    wp_register_script(
        'custom/spacing',
        get_template_directory_uri() . '/parts/blocks/custom-spacing/admin.min.js',
        array('wp-blocks', 'wp-element', 'wp-editor', 'wp-i18n')
    );

    if( is_admin() ) {
        wp_register_style(
            'custom/spacing-style-editor',
            get_template_directory_uri() . '/parts/blocks/custom-spacing/style-editor.css',
            array( 'wp-edit-blocks' )
        );
    }

    register_block_type('custom/spacing', array(
        'editor_script' => 'custom/spacing',
        'editor_style'  => 'custom/spacing-style-editor',
    ));
}
add_action( 'enqueue_block_editor_assets', 'custom_block_registration_spacing' );