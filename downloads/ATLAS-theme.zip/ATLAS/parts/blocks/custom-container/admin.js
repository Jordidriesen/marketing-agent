/* global wp */
const { InnerBlocks, InspectorControls, PanelColorSettings, __experimentalPanelColorGradientSettings, __experimentalColorGradientControl, MediaUpload, MediaUploadCheck, getColorClassName, getColorObjectByColorValue } = wp.blockEditor;
const { registerBlockType } = wp.blocks;
const { PanelBody, FocalPointPicker, ToggleControl, Button, RangeControl } = wp.components;
const { select } = wp.data;
const { __ } = wp.i18n;

const generateClass = attributes => {
	const { spacingTop, spacingBottom, marginTop, marginBottom, backgroundColor } = attributes;
    let customClass = 'block-content ';
    if( backgroundColor ) {
        const settings = select( 'core/editor' ).getEditorSettings();
        const colorObject = getColorObjectByColorValue( settings.colors, backgroundColor );
        if ( colorObject ) {
            customClass += getColorClassName( 'background-color', colorObject.slug );
        }
    }

    customClass += spacingTop ? ' block-content--spacing-top' : '';
    customClass += spacingBottom ? ' block-content--spacing-bottom' : '';
    customClass += marginTop ? ' block-content--margin-top' : '';
    customClass += marginBottom ? ' block-content--margin-bottom' : '';

	return customClass;
}

const generateAttr = (attributes, admin) => {
    const { backgroundColor, backgroundGradient, url, focalPoint, bgRepeat } = attributes;
    const attrObj = {};

    if ( backgroundColor || backgroundGradient || url ) {
        attrObj.style = {};
    }

    if (url) {
        attrObj.style = {};
        attrObj.style.backgroundImage = `url(${ url })`;
        attrObj.style.backgroundPosition = `${ focalPoint.x * 100 }% ${ focalPoint.y * 100 }%`;
        if ( ! bgRepeat ) {
            attrObj.style.backgroundRepeat = 'no-repeat';
            attrObj.style.backgroundSize = 'cover';
        }

    } else {
        if ( backgroundColor ) {
            attrObj.style.backgroundColor = backgroundColor;
        }
    
        if ( backgroundGradient ) {
            attrObj.style.background = backgroundGradient;
        }
    }

    return attrObj;
}

const generateOverlayAttr = (attributes, admin) => {
    const { overlayColor, overlayGradient,overlayOpacity, url } = attributes;

    const attrObj = {};

    if (url) {

        if ( overlayColor || overlayGradient || overlayOpacity) {
            attrObj.style = {};
        }

        if ( overlayColor  ) {
            attrObj.style.backgroundColor = overlayColor;
        }

        if ( overlayGradient ) {
            attrObj.style.background = overlayGradient;
        }

        if ( overlayOpacity ) {
            attrObj.style.opacity = overlayOpacity;
        }
    }

    return attrObj;
}

const renderOverlay = (attributes) => {
    if ( attributes.url ) {
        return (
            <div className="container-overlay" {...generateOverlayAttr(attributes, false)} />
        )
    }
}

const attributes =  {
    align: {
        type: 'string',
        default: 'wide'
    },
    backgroundColor: {
        type: 'string'
    },
    backgroundGradient: {
        type: 'string',
    },
    overlayColor: {
        type: 'string'
    },
    overlayGradient: {
        type: 'string'
    },
    overlayOpacity: {
        type: 'number',
        default: 0.5
    },
    spacingTop: {
        type: 'boolean',
        default: false
    },
    spacingBottom: {
        type: 'boolean',
        default: false
    },
    marginTop: {
        type: 'boolean',
        default: false
    },
    marginBottom: {
        type: 'boolean',
        default: false
    },
    url:  {
        type: 'string',
        default: '',
    },
    bgRepeat: {
        type: 'bool',
        default: false,
    },
    focalPoint: {
        type: 'object',
        default: {
            x: 0.5,
            y: 0.5,
        }
    },
};

registerBlockType( 'custom/container', {
    title: 'Container',
    icon: 'welcome-add-page',
    category: 'custom_blocks',
    supports: {
        align: [ 'wide', 'full' ],
        anchor: true
    },

    attributes,

    edit: ( { attributes, setAttributes } ) => {
        const { spacingTop, spacingBottom, marginTop, marginBottom, backgroundColor, backgroundGradient, overlayColor, overlayGradient, overlayOpacity, url, bgRepeat, focalPoint } = attributes;
        
        const ALLOWED_MEDIA_TYPES = [ 'image' ];

        const getImageButton = (openEvent) => {
            if( url ) {
                return (
                <img 
                    src={ url }
                    onClick={ openEvent }
                    className="image"
                    alt="placeholder"
                />
                );
            }
            else {
                return (
                <div className="button-container">
                    <Button 
                    onClick={ openEvent }
                    className="button button-large"
                    >
                    {__('Pick an image')}
                    </Button>
                </div>
                );
            }
        };

        const renderClear = () => {
            if ( url ) {
                return (
                    <Button 
                    onClick={ () => { setAttributes({ url: undefined }); } }
                    className="button button-large"
                    >{__('Clear Image')}</Button>
                )
            }
        }

        const renderFocal = () => {
            if ( url ) {
                return (
                    <FocalPointPicker
                        label={ __( 'Focal point picker' ) }
                        url={ url }
                        value={ focalPoint }
                        onChange={ ( newFocalPoint ) =>
                            setAttributes( {
                                focalPoint: newFocalPoint,
                            } )
                        }
                    />
                )
            }
        }

        return (
            <>
			<InspectorControls>
				<PanelBody title={ __( 'Settings' ) }>
					<ToggleControl
						label={ __( 'Top Spacing' ) }
						checked={ !! spacingTop }
						onChange={ () =>
							setAttributes( { spacingTop: ! spacingTop } )
						}
						help={
							spacingTop
								? 'Adding Top spacing'
								: 'Toggle to add Top spacing.'
						}
					/>
					<ToggleControl
						label={ __( 'Bottom Spacing' ) }
						checked={ !! spacingBottom }
						onChange={ () =>
							setAttributes( { spacingBottom: ! spacingBottom } )
						}
						help={
							spacingBottom
								? 'Adding Bottom spacing'
								: 'Toggle to add Bottom spacing.'
						}
					/>
					<ToggleControl
						label= { __( 'Top margin' ) }
						checked={ !! marginTop }
						onChange={ () =>
							setAttributes( { marginTop: ! marginTop } )
						}
						help={
							marginTop
								? 'Adding Top margin'
								: 'Toggle to add Top margin.'
						}
					/>
					<ToggleControl
						label={ __( 'Bottom margin' ) }
						checked={ !! marginBottom }
						onChange={ () =>
							setAttributes( { marginBottom: ! marginBottom } )
						}
						help={
							marginBottom
								? 'Adding Bottom margin'
								: 'Toggle to add Bottom margin.'
						}
					/>
				</PanelBody>
                <PanelBody title={ __( 'Background Image Settings' ) }>
                    <MediaUploadCheck>
                        <MediaUpload
                        onSelect={ ( media ) => { setAttributes({ url: media.url }); } }
                        allowedTypes={ ALLOWED_MEDIA_TYPES }
                        
                        render={ ( { open } ) => getImageButton(open) }
                        />
                    </MediaUploadCheck>
                    
                    { renderClear() }

                    { renderFocal() }

                    <ToggleControl
						label={ __( 'Background Repeat' ) }
						checked={ !! bgRepeat }
						onChange={ () =>
							setAttributes( { bgRepeat: ! bgRepeat } )
						}
						help={
							bgRepeat
								? 'Repeat background'
								: 'Toggle to repeat background'
						}
					/>

                    <__experimentalColorGradientControl     
                        colorValue={ overlayColor }
                        gradientValue={overlayGradient}
                        onColorChange={ ( colorValue ) => setAttributes( { overlayColor: colorValue } )}
                        onGradientChange={ ( gradientValue ) => setAttributes( { overlayGradient: gradientValue } )}
                        label={ __('Overlay Color')}
                    />
                    
                    <RangeControl
                        label={__("Overlay Opacity")}
                        value={ overlayOpacity }
                        onChange={ ( newOverlayOpacity ) => setAttributes( { overlayOpacity : newOverlayOpacity } ) }
                        min={ 0 }
                        max={ 1 }
                        step={0.05}
                    />

                </PanelBody>

                <__experimentalPanelColorGradientSettings 
                    title={ __( 'Background Color Settings' ) }
                    initialOpen={ true }
                    settings={ [
                        {
                            colorValue: backgroundColor,
                            gradientValue: backgroundGradient,
                            onColorChange: ( colorValue ) => setAttributes( { backgroundColor: colorValue } ),
                            onGradientChange: ( gradientValue ) => setAttributes( { backgroundGradient: gradientValue } ),
                            label: __('Background Color')
                        }
                    ] }
                />
            
                {/* <PanelColorSettings
                    title={ __( 'Color Settings' ) }
                    colorSettings={ [
                        {
                            value: backgroundColor,
                            onChange: ( colorValue ) => setAttributes( { backgroundColor: colorValue } ),
                            label: __( 'Background Color' ),
                        }
                    ] }
                /> */}

			</InspectorControls>

            <section className={ generateClass(attributes) } {...generateAttr(attributes, true)}>
                <div className={ `container container--${attributes.align}` }>
                    <div className="container__body">
                    <InnerBlocks
                        renderAppender={ () => (
                            <InnerBlocks.ButtonBlockAppender />
                        ) }
                    />
                    </div>
                </div>
                {renderOverlay(attributes)}
            </section>
            </>
        );
    },
    save: ( { attributes } ) => {
        return (
            <section className={ generateClass(attributes) } {...generateAttr(attributes, false)}>
                <div data-styles-id="custom-container" />
                <div className={ `container container--${attributes.align}` }>
                    <div className="container__body">
                    <InnerBlocks.Content />
                    </div>
                </div>
                {renderOverlay(attributes)}
            </section>
        );
    },
    deprecated: [
        {
            attributes,
            save: ( { attributes } ) => {
                return (
                    <section className={ generateClass(attributes) } {...generateAttr(attributes, false)}>
                        <div data-styles-id="custom-container" />
                        <div className={ `container container--${attributes.align}` }>
                            <div className="container__body">
                            <InnerBlocks.Content />
                            </div>
                        </div>
                    </section>
                );
            },
        }
    ]
} );