<?php
function init_block_map() {

	if ( ! function_exists( 'acf_register_block' ) ) {
		return;
	}

	acf_register_block( array(
		'name'            => 'map',
		'title'           => __( 'Google Karte / Google Maps' ),
		'description'     => __( 'Custom map block' ),
		'category'        => 'custom_blocks',
		'icon'            => 'location-alt',
		'keywords'        => array( 'map', 'karte' ),
		'mode'            => 'auto',
		'example'         => [
            'attributes' => [
                'mode' => 'auto',
            ]
        ],
        'align'             => 'full',
        'supports'          => array(
			'align' => false,
        ),
		'render_template' => get_template_directory() . '/parts/blocks/acf-map/index.php',
		'enqueue_assets'  => function () {
			wp_enqueue_script(
				'ATLAS/acf-map',
                get_template_directory_uri() . ( is_IE() ? '/parts/blocks/acf-map/index.ie.js#asyncload' : '/parts/blocks/acf-map/index.min.js#asyncload' ),
                ['js-google'],
                false,
                true
			);
		}
	) );
}
add_action( 'acf/init', 'init_block_map' );

// function is_map_block_exists() {
// 	if ( is_admin() ) {
// 		$screen = get_current_screen();
// 		if ( $screen->base != 'post' || ! $screen->is_block_editor ) {
// 			return false;
// 		}
// 	}

// 	$post = get_post();

// 	if ( ! $post || ! has_blocks( $post->post_content ) ) {
// 		return false;
// 	}

// 	$blocks = parse_blocks( $post->post_content );
// 	$names  = array_map( function ( $block ) {
// 		return $block['blockName'];
// 	}, $blocks );

// 	return in_array( 'acf/map', $names );
// }

function my_acf_init() {
	acf_update_setting( 'google_api_key', get_field( 'google_maps_api_key', 'options' ) );
}

add_action( 'acf/init', 'my_acf_init' );


// add_action( 'wp_enqueue_scripts', 'mygoogleapi_enqueue_scripts' );
// add_action( 'admin_enqueue_scripts', 'mygoogleapi_enqueue_scripts' );

// function mygoogleapi_enqueue_scripts() {
// 	if ( is_map_block_exists() && ! empty( get_field( 'google_maps_api_key', 'options' ) ) ) :
// 		wp_register_script( 'js-google', '//maps.googleapis.com/maps/api/js?key=' . get_field( 'google_maps_api_key', 'options' ),[], null, true );
// 	endif;
// }
