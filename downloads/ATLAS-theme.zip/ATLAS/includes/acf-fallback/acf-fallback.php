<?php
/**
 * ACF fallback
 * ---------------------------------------------------------------------------------------
 *
 * The theme's content (header, footer, blocks and options) is built with Advanced Custom
 * Fields Pro, so ACF Pro is required for the theme to work as intended.
 *
 * When ACF Pro is missing or inactive, the theme templates would otherwise stop with a
 * fatal error on the first call to an ACF function. The fallbacks below only prevent those
 * fatal errors, so that the site still loads and an administrator can install or
 * reactivate ACF Pro. They return empty values and render nothing; they do not replace
 * any ACF functionality.
 *
 * Plugins are loaded before the theme, so when ACF is active its functions already exist
 * and none of these fallbacks (nor the admin notice) are ever defined.
 *
 * @package WordPress
 */

defined( 'ABSPATH' ) or die();

if ( function_exists( 'get_field' ) ) {
	return;
}

if ( ! function_exists( 'get_field' ) ) {
	function get_field( $selector, $post_id = false, $format_value = true, $escape_html = false ) {
		return false;
	}
}

if ( ! function_exists( 'get_sub_field' ) ) {
	function get_sub_field( $selector = '', $format_value = true, $escape_html = false ) {
		return false;
	}
}

if ( ! function_exists( 'have_rows' ) ) {
	function have_rows( $selector, $post_id = false ) {
		return false;
	}
}

if ( ! function_exists( 'the_row' ) ) {
	function the_row( $format = false ) {
		return false;
	}
}

if ( ! function_exists( 'get_row_layout' ) ) {
	function get_row_layout() {
		return false;
	}
}

/**
 * Tell administrators that ACF Pro is missing.
 */
function atlas_acf_missing_admin_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	?>
	<div class="notice notice-error">
		<p><?php echo esc_html__( 'The ATLAS theme needs Advanced Custom Fields Pro. Install or activate it to restore the theme\'s header, footer, blocks and options.', 'ATLAS-admin' ); ?></p>
	</div>
	<?php
}
add_action( 'admin_notices', 'atlas_acf_missing_admin_notice' );
