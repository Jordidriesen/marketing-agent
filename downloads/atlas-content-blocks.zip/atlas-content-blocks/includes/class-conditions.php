<?php
/**
 * Evaluates a block's display conditions against the current request.
 *
 * A block shows when at least one include rule matches, no exclude rule
 * matches, the visitor's login state fits and the current time is inside the
 * schedule. Device visibility is handled in CSS, so it works with page caching.
 *
 * @package AtlasContentBlocks
 */

defined( 'ABSPATH' ) || exit;

class Atlas_CB_Conditions {

	/**
	 * @param array $settings Block settings.
	 *
	 * @return bool
	 */
	public static function matches( array $settings ) {
		if ( ! self::user_matches( $settings['user'] ) || ! self::schedule_matches( $settings['start'], $settings['end'] ) ) {
			return false;
		}

		$included = false;
		foreach ( $settings['include'] as $rule ) {
			if ( self::rule_matches( $rule ) ) {
				$included = true;
				break;
			}
		}

		if ( ! $included ) {
			return false;
		}

		foreach ( $settings['exclude'] as $rule ) {
			if ( self::rule_matches( $rule ) ) {
				return false;
			}
		}

		return (bool) apply_filters( 'atlas_cb_matches', true, $settings );
	}

	/**
	 * @param string $user all, logged_in or logged_out.
	 *
	 * @return bool
	 */
	private static function user_matches( $user ) {
		if ( 'logged_in' === $user ) {
			return is_user_logged_in();
		}
		if ( 'logged_out' === $user ) {
			return ! is_user_logged_in();
		}
		return true;
	}

	/**
	 * @param string $start Local datetime (Y-m-d\TH:i) or empty.
	 * @param string $end   Local datetime (Y-m-d\TH:i) or empty.
	 *
	 * @return bool
	 */
	private static function schedule_matches( $start, $end ) {
		if ( '' === $start && '' === $end ) {
			return true;
		}

		$zone = wp_timezone();
		$now  = new DateTimeImmutable( 'now', $zone );

		if ( '' !== $start ) {
			$from = DateTimeImmutable::createFromFormat( 'Y-m-d\TH:i', $start, $zone );
			if ( $from && $now < $from ) {
				return false;
			}
		}

		if ( '' !== $end ) {
			$until = DateTimeImmutable::createFromFormat( 'Y-m-d\TH:i', $end, $zone );
			if ( $until && $now >= $until ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * @param array $rule [ 'rule' => string, 'value' => string ].
	 *
	 * @return bool
	 */
	public static function rule_matches( array $rule ) {
		$name  = (string) ( $rule['rule'] ?? '' );
		$value = (string) ( $rule['value'] ?? '' );

		list( $kind, $arg ) = array_pad( explode( ':', $name, 2 ), 2, '' );

		switch ( $kind ) {
			case 'entire_site':
				return true;

			case 'front_page':
				return is_front_page();

			case 'posts_page':
				return is_home();

			case 'search':
				return is_search();

			case 'not_found':
				return is_404();

			case 'singular':
				return 'any' === $arg ? is_singular() : is_singular( $arg );

			case 'archive':
				if ( 'any' === $arg ) {
					return is_archive() || is_home();
				}
				if ( 'post' === $arg ) {
					return is_home() || is_category() || is_tag() || is_date() || is_author();
				}
				return is_post_type_archive( $arg ) || ( is_tax() && in_array( get_queried_object()->taxonomy ?? '', get_object_taxonomies( $arg ), true ) );

			case 'post_ids':
				return self::matches_post_ids( $value );

			case 'child_of':
				return self::matches_child_of( (int) $value );

			case 'term':
				return self::matches_term( $value );

			case 'page_template':
				return self::matches_template( $value );
		}

		return false;
	}

	/**
	 * IDs entered in one language also match their translations (WPML).
	 *
	 * @param string $value Comma-separated IDs.
	 *
	 * @return bool
	 */
	private static function matches_post_ids( $value ) {
		if ( ! is_singular() && ! is_home() ) {
			return false;
		}

		$current = get_queried_object_id();

		foreach ( wp_parse_id_list( $value ) as $id ) {
			$type       = get_post_type( $id );
			$translated = $type ? (int) apply_filters( 'wpml_object_id', $id, $type, true ) : $id;
			if ( $current && ( $current === $id || $current === $translated ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Pages anywhere below the given parent (not the parent itself).
	 *
	 * @param int $parent Parent page ID.
	 *
	 * @return bool
	 */
	private static function matches_child_of( $parent ) {
		if ( ! $parent || ! is_singular() ) {
			return false;
		}

		$type   = get_post_type( $parent );
		$parent = $type ? (int) apply_filters( 'wpml_object_id', $parent, $type, true ) : $parent;

		return in_array( $parent, array_map( 'intval', get_post_ancestors( get_queried_object_id() ) ), true );
	}

	/**
	 * The term's archive, or a single post that has the term.
	 *
	 * @param string $value taxonomy:slug.
	 *
	 * @return bool
	 */
	private static function matches_term( $value ) {
		if ( false === strpos( $value, ':' ) ) {
			return false;
		}

		list( $taxonomy, $slug ) = array_map( 'trim', explode( ':', $value, 2 ) );

		if ( ! taxonomy_exists( $taxonomy ) || '' === $slug ) {
			return false;
		}

		if ( is_category() || is_tag() || is_tax() ) {
			$term = get_queried_object();
			return $term instanceof WP_Term && $term->taxonomy === $taxonomy && $term->slug === $slug;
		}

		if ( is_singular() ) {
			return has_term( $slug, $taxonomy, get_queried_object_id() );
		}

		return false;
	}

	/**
	 * @param string $value Template file relative to the theme, or "default".
	 *
	 * @return bool
	 */
	private static function matches_template( $value ) {
		if ( ! is_singular() ) {
			return false;
		}

		$template = get_page_template_slug( get_queried_object_id() );

		if ( 'default' === $value ) {
			return '' === $template;
		}

		return '' !== $template && $template === $value;
	}
}
