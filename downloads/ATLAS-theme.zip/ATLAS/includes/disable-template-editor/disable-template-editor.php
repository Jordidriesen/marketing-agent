<?php
    // Since WP 5.8
    remove_theme_support( 'block-templates' );