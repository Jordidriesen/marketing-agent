<?php
/**
 * Menu Item Template: Menu Template
 */
$rows = ! empty( $rows ) ? $rows : []; ?>
<div class="mega-menu-wrapper">    
    <div class="mega-menu-wrapper__container">
    <?php
    foreach ( $rows as $row ) : 
        $columns = ! empty( $row['menu_columns'] ) ? $row['menu_columns'] : [];
        ?>
        <div class="sub-menu-wrapper__row">
            <?php 
            foreach ( $columns as $column ) : 
                $heading_type = $column['type'];
                $text = $column['text'];
                $link = $column['link'];
                $editor = $column['editor'];
                $deactivate_menu = $column['deactivate_menu'];

                if ($heading_type === 'link' || (isset($deactivate_menu) && $deactivate_menu === false)) :
            ?>
            <div class="sub-menu-wrapper">
                <?php if ( ! empty( $link ) || !empty( $text ) ) : ?>
                    <p class="sub-menu-text"><?php 
                    if ( $heading_type === 'link' ) {
                        echo '<span class="h3">';
                        echo get_theme_part( 'elements/link', [ 'link' => $link ] );
                        echo '</span>';
                    } else {
                        echo '<span class="h3">' . $text . '</span>';
                    }
                    ?></p>
                <?php else: ?>
                    <div class="sub-menu-spacing"></div>
                <?php endif; ?>
                <?php
                    
                    if ( isset( $column['menu'] ) && ! empty( $column['menu'] ) && ! $deactivate_menu ) :
                        wp_nav_menu(
                            array(
                                'menu'       => intval( $column['menu'] ),
                                'container'  => false,
                                'menu_class' => 'sub-menu',
                            )
                        );
                    endif; ?>
            </div>
            <?php 
                endif;
            endforeach; 
            ?>
        </div>
    <?php endforeach; ?>
    </div>
</div>
