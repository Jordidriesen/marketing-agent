<?php
if ( isset($id) ):
	$title = get_the_title($id);
	$short_desc = get_field('partner_description', $id);
	$link_url = get_field('partner_website', $id);
	$link_target = isset($link_target) ? $link_target : '_self';
	$link_title = $btn_txt ? $btn_txt : __('Link to partner', 'ATLAS');
?>
<div class="single-partner">
	<?php loadStyles(__DIR__, 'single-partner'); ?>
	<div class="single-partner__wrapper">

		<div class="single-partner__content">
			<h3 class="single-partner__title"><?php echo $title; ?></h3>
			<?php if (!empty($short_desc)) : ?>
				<span class="single-partner__desc"><?php echo $short_desc; ?></span>
			<?php endif; ?>	
		
			<div class="single-partner__buttons">
			<?php $name = 'core-button';?>
			<?php loadStylesDep('blocks/core-button', $name); ?>

			<?php if( $link_url ) : ?>
				<div class="wp-block-button single-partner__button"><a class="wp-block-button__link" href="<?php echo $link_url; ?>"><?php echo esc_html( $link_title ); ?></a></div>
			<?php endif; ?>
			</div>
		</div>
	</div>
</div>

<?php 

endif;