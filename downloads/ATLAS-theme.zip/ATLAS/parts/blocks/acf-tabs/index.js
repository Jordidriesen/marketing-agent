class Tabs {
    static tabsWrapperClass = '.block-tabs';

    static activeClass = 'active';

    static navItemClass = '.tabs__link';

    constructor(block) {
        this.block = block;
        this.navItems = block.querySelectorAll(Tabs.navItemClass);
    }

    init() {
        this.navItems.forEach(navItem => {
            navItem.addEventListener('click', event => this.changeTab(event));
        });
    }

    changeTab(event) {
        event.preventDefault();

        const { parentNode, hash } = event.target;
        const activeElements = this.block.querySelectorAll(`.${Tabs.activeClass}`);

        [...activeElements].forEach(tab => {
            tab.classList.remove(Tabs.activeClass);
        });

        parentNode.classList.add(Tabs.activeClass);
        this.block.querySelector(`[data-tab-id="${hash}"`).classList.add(Tabs.activeClass);
    }
}

const initBlock = () => {
    [...document.querySelectorAll(Tabs.tabsWrapperClass)].forEach(block => {
        const newTab = new Tabs(block);
        newTab.init()
    });
};

initBlock();

if ( window.acf ) {
    window.acf.addAction( 'render_block_preview/type=tabs', initBlock);
}
