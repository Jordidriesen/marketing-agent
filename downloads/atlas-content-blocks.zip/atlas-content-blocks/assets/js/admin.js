/**
 * ATLAS Content Blocks: settings meta box behaviour.
 * Shows the fields that apply to the chosen type, location and trigger, and
 * adds and removes display rule rows. Rules that need a value and have none
 * are dropped on save.
 */
(function () {
	'use strict';

	var root = document.querySelector('.atlas-cb-settings');
	if (!root) {
		return;
	}

	var sync = function () {
		var type = root.querySelector('input[name="atlas_cb[type]"]:checked');
		var location = root.querySelector('#atlas-cb-location');
		var trigger = root.querySelector('#atlas-cb-trigger');
		var frequency = root.querySelector('#atlas-cb-frequency');

		root.dataset.type = type ? type.value : 'hook';
		root.dataset.location = location ? location.value : '';
		root.dataset.trigger = trigger ? trigger.value : 'click';
		root.dataset.frequency = frequency ? frequency.value : 'always';
	};

	var syncValue = function (row) {
		var select = row.querySelector('.atlas-cb-rule-select');
		var input = row.querySelector('.atlas-cb-rule-value');
		var option = select.options[select.selectedIndex];
		var placeholder = option ? option.getAttribute('data-placeholder') : null;

		input.hidden = !placeholder;
		input.placeholder = placeholder || '';
		if (!placeholder) {
			input.value = '';
		}
	};

	var counter = Date.now();

	root.addEventListener('change', function (event) {
		if (event.target.classList.contains('atlas-cb-rule-select')) {
			syncValue(event.target.closest('.atlas-cb-rule'));
		}
		sync();
	});

	root.addEventListener('click', function (event) {
		var target = event.target;

		if (target.classList.contains('atlas-cb-add-rule')) {
			var table = target.closest('.atlas-cb-rules');
			var template = table.nextElementSibling;
			var html = template.innerHTML.replace(/__i__/g, String(counter++));
			var body = table.querySelector('tbody');
			body.insertAdjacentHTML('beforeend', html);
			var row = body.lastElementChild;
			syncValue(row);
			row.querySelector('select').focus();
		}

		if (target.classList.contains('atlas-cb-remove-rule')) {
			var current = target.closest('.atlas-cb-rule');
			var tableOf = current.closest('.atlas-cb-rules');
			current.remove();
			var add = tableOf.querySelector('.atlas-cb-add-rule');
			if (add) {
				add.focus();
			}
		}
	});

	root.querySelectorAll('.atlas-cb-rule').forEach(syncValue);
	sync();
})();
