<?php
// Remove admin color scheme picker from admin panel for all users except admins
if ( !current_user_can('manage_options') ) 
    remove_action( 'admin_color_scheme_picker', 'admin_color_scheme_picker' );


$text_color = '#fff';
$base_color =  '#11213b';
$icon_color = '#959eac';
$menu_submenu_background = '#d63b38';
$highlight_color = '#b72926';
$notification_color = '#00a0d2';

wp_admin_css_color(
    'smarttec',
    _x( 'Smarttec', 'admin color scheme' ),
    get_template_directory_uri().'/css/admin/colors/theme/colors.css',
    array( $base_color, $highlight_color, $menu_submenu_background, $notification_color ),
    array(
        'base'    => $icon_color,
        'focus'   => $text_color,
        'current' => $text_color,
    )
);

function set_default_admin_color($user_id) {
    $args = array(
        'ID' => $user_id,
        'admin_color' => 'smarttec'
    );
    wp_update_user( $args );
}
add_action('user_register', 'set_default_admin_color');