<?php
if ( isset($id) ):
	$title = get_the_title($id);
	$short_desc = get_the_excerpt($id);
	$link_url = get_permalink($id);
	$link_target = isset($link_target) ? $link_target : '_self';
	$link_title = $btn_txt ? $btn_txt : __('Mehr erfahren', 'ATLAS');
	$name = 'core-button';
?>
<div class="single-search">
	<?php loadStyles(__DIR__, 'single-search'); ?>
	<div class="single-search__wrapper">

		<div class="single-search__content">
			<h2 class="single-search__title h4" role="heading"><?php echo $title; ?></h2>
		<?php if (!empty($short_desc)) : ?>
			<span class="single-search__desc"><?php echo $short_desc; ?></span>
		<?php endif; ?>	
			<div class="single-search__button">
				<?php loadStylesDep('blocks/core-button', $name); ?>
				<div class="wp-block-button is-style-link-only"><a class="wp-block-button__link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a></div>
			</div>
		</div>
	</div>
</div>
<?php
endif;