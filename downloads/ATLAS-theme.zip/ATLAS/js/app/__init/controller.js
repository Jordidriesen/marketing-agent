import vhUnit from '../__constants/vhUnit';
import {detectDevice} from '../__constants/detectDevice';

import megaMenu from '../__header/megaMenu';
import headerHeight from '../__header/setHeaderHeight';
import mobileMenu from '../__header/mobileMenu';
import HeaderSearch from '../__modules/headerSearch';
import HeaderAccordion from '../__modules/headerAccordion';
import HeaderLanguageDropdown from '../__modules/headerLanguageDropdown';
import Footer from '../__modules/footer';
import ThemeToggle from '../__modules/themeToggle';

// GLOBAL APP CONTROLLER
const controller = {
    init() {
        vhUnit();
        detectDevice();
        mobileMenu.init();
        HeaderSearch.init();
        const headerAccordion = new HeaderAccordion();
        headerAccordion.initHeaderAccordion();
        const footer = new Footer();
        footer.initAccordionFooter();
        HeaderLanguageDropdown.init();
        ThemeToggle.init();
    },
    loaded() {
        headerHeight.init();
        megaMenu.init();
        document.querySelector('body').classList.add('page-has-loaded');
    },
    resized() {
        vhUnit();
        headerHeight.setHeaderHeight();
        mobileMenu.resize();
    },
    mouseUp(e) {
        mobileMenu.hideOutsideClick(e);
    },
    scrolled(e) {
    },
};
export default controller;


