<?php
/**
 * Block with Pricing Columns
 *
 * @package WordPress
 * @subpackage ATLAS
 * @since ATLAS 1.0
 */
$block_object = new Block( $block );

loadAcfBlockPreviewImage(__DIR__);

$name = $block_object->block_name();
$members = get_field('team_overview');

if ( !empty($members) ) :
?>
<section class="block-team-overview">
    <?php loadStyles(__DIR__, $name); ?>
    <div class="block-team-overview__container">
        <div class="block-team-overview__row row small-gutter">
        <?php foreach( $members as $id ): ?>
            <div class="block-team-overview__col col col-12 col-md-6 col-xl-3">
                <?php get_theme_part('components/member/index', ['id' => $id]); ?>
            </div>
        <?php endforeach; ?>
        </div>
    </div>
</section>
<?php
endif;