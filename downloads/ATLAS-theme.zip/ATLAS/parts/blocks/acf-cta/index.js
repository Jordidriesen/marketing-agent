import BackgroundVideo from 'lib/video-bg/index';

const BgVid = new BackgroundVideo();

const initBlock = () => {
    BgVid.init();
    window.addEventListener('resize', () => {
        BgVid.resized();
    });
};

initBlock();

if (window.acf) {
    window.acf.addAction('render_block_preview/type=cta', initBlock);
}
