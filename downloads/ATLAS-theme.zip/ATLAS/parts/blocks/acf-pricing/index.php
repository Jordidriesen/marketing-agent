<?php
/**
 * Block with Pricing Columns
 *
 * @package WordPress
 * @subpackage ATLAS
 * @since ATLAS 1.0
 */
$block_object = new Block( $block );
$more_btn = get_field('pricing_more');

loadAcfBlockPreviewImage(__DIR__);

if ( have_rows('pricing_row') ) :
    $name = $block_object->block_name();

?>
<section class="block-pricing">
    <?php loadStyles(__DIR__, $name); ?>
    <div class="block-pricing__container">
        <div class="block-pricing__row">
        <?php
        while ( have_rows('pricing_row') ) : the_row() ;
            $recommended = get_sub_field('recommended');
            $title = get_sub_field('title');
            $price = get_sub_field('price');
            $price_description = get_sub_field('price_description');
            $description = get_sub_field('description');
            $link = get_sub_field('button');
            $recommended_text = '';

            $single_class = 'pricing-box';

            $button_class = 'wp-block-button is-style-outline';

            $more_btn_class = 'pricing-box__more pricing-box__more--closed';

            if (is_admin()) {
                $more_btn_class = 'pricing-box__more pricing-box__more--open';
            }

            if ($recommended) {
                $recommended_text = get_sub_field('recommended_text');
                $single_class .= ' pricing-box--recommended';
                $button_class = 'wp-block-button';
            }
        ?>
            <div class="<?php echo $single_class; ?>">
                <div class="pricing-box__wrapper">
                <?php if ( $recommended && !empty($recommended_text) ) : ?>
                    <span class="pricing-box__recommended"><?php echo $recommended_text; ?></span>
                <?php endif; ?>                    
                <?php if ( !empty($title) ) : ?>
                    <span class="pricing-box__title"><?php echo $title; ?></span>
                <?php endif; ?>
                    <div class="pricing-box__price-wrapper">
                    <?php if ( !empty($price) ) : ?>
                        <span class="pricing-box__price"><?php echo $price; ?></span>
                    <?php endif; ?>
                    <?php if ( !empty($price_description) ) : ?>
                        <span class="pricing-box__price-description"><?php echo $price_description; ?></span>
                    <?php endif; ?>
                    </div>
                <?php if ( !empty($description) ) : ?>
                    <p class="pricing-box__description"><?php echo $description; ?></p>
                <?php 
                endif;

                if ( have_rows('inner_row') ) :
                ?>
                <?php if ( $more_btn ) : ?>
                    <button class="<?php echo $more_btn_class; ?>"><span class="text text--more"><?php _e('Show More', 'ATLAS'); ?></span><span class="text text--less"><?php _e('Show Less', 'ATLAS'); ?></span></button>
                <?php else: ?>
                    <hr class="pricing-box__hr" />
                <?php endif; ?>
                    <dl class="pricing-box__rows">
                <?php
                    while ( have_rows('inner_row') ) : the_row() ;
                        $term = get_sub_field('term');
                        $description = get_sub_field('description');
                ?>
                        <dt class="pricing-box__rows-term"><?php echo $term; ?></dt>
                        <dd class="pricing-box__rows-desc"><?php echo $description; ?></dd>
                <?php endwhile; ?>
                    </dl>
                <?php endif; ?>
                <?php
                if( $link ): 
                    $link_url = $link['url'];
                    $link_title = $link['title'];
                    $link_target = $link['target'] ? $link['target'] : '_self';
                ?>
                    <div data-styles-id="core-button"></div>
                    <div class="<?php echo $button_class; ?>"><a class="wp-block-button__link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a></div>
                <?php endif; ?>
                </div>
            </div>
        <?php
        endwhile;
        ?>
        </div>
    </div>
</section>
<?php
endif;