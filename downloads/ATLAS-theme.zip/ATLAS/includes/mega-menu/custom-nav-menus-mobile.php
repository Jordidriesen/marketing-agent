<?php

/**
 * Custom Walker
 * This is custom walker for menu which implement a menu-dropdown
 * template for menu item (only parent ones) containing 'menu_rows'
 * sub field provided by ACF plugin
 */

class Custom_Nav__Mobile_Menu_Walker extends Walker_Nav_Menu {
	public function end_el( &$output, $item, $depth = 0, $args = array() ) {

		$rows = get_field( 'menu_rows', $item );

		$title = $item->title;
		$url = $item->url;
		$target = $item->target;

		if ( empty( $item->menu_item_parent ) && ! empty( $rows ) ) {

			ob_start();

			get_theme_part( 'components/menu-dropdown/menu-item-template-mobile', [ 'rows' => $rows, 'title' => $title, 'url' => $url, 'target' => $target, 'mobile' => true ] );

			$output .= ob_get_clean();
		} 
		$output .= "</li>\n";
	}
}
