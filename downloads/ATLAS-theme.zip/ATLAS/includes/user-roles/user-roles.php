<?php
function create_user_roles() {
	$args = get_role( 'editor' )->capabilities;


	// Register Custom Roles with basic editor capabilities
	add_role( 'client', 'Client', $args);

	add_role( 'smarttec', 'Smarttec', $args);

	//remove_role( 'smarttec' );


}
add_action( 'init', 'create_user_roles', 99 );

function hide_menu(){
	global $current_user;
	if ( $current_user->roles[0] == 'client' ) {
		remove_menu_page('acf-options-general');
		remove_menu_page('tools.php');
	}
	if ( $current_user->roles[0] == 'smarttec' ) {
		remove_menu_page( 'options-general.php' );
		remove_menu_page( 'edit.php?post_type=acf-field-group' );
    }
}
add_action('admin_head', 'hide_menu', 99);

/**
 * Helper function get getting roles that the user is allowed to create/edit/delete.
 *
 * @param   WP_User $user
 * @return  array
 */
function wpse_188863_get_allowed_roles( $user ) {
    $allowed = array();

    if ( in_array( 'administrator', $user->roles ) ) { // Admin can edit all roles
        $allowed = array_keys( $GLOBALS['wp_roles']->roles );
    } elseif ( in_array( 'smarttec', $user->roles ) ) {
        $allowed[] = 'smarttec';
        $allowed[] = 'client';
        $allowed[] = 'contributor';
        $allowed[] = 'customer';
        $allowed[] = 'subscriber';
    } elseif ( in_array( 'client', $user->roles ) ) {
		$allowed[] = 'client';
        $allowed[] = 'contributor';
        $allowed[] = 'customer';
        $allowed[] = 'subscriber';
    }

    return $allowed;
}

/**
 * Remove roles that are not allowed for the current user role.
 */
function wpse_188863_editable_roles( $roles ) {
    if ( $user = wp_get_current_user() ) {
        $allowed = wpse_188863_get_allowed_roles( $user );

        foreach ( $roles as $role => $caps ) {
            if ( ! in_array( $role, $allowed ) )
                unset( $roles[ $role ] );
        }
    }

    return $roles;
}

add_filter( 'editable_roles', 'wpse_188863_editable_roles' );

/**
 * Prevent users deleting/editing users with a role outside their allowance.
 */
function wpse_188863_map_meta_cap( $caps, $cap, $user_ID, $args ) {
    if ( ( $cap === 'edit_user' || $cap === 'delete_user' ) && $args ) {
        $the_user = get_userdata( $user_ID ); // The user performing the task
        $user     = get_userdata( $args[0] ); // The user being edited/deleted

        if ( $the_user && $user && $the_user->ID != $user->ID /* User can always edit self */ ) {
            $allowed = wpse_188863_get_allowed_roles( $the_user );

            if ( array_diff( $user->roles, $allowed ) ) {
                // Target user has roles outside of our limits
                $caps[] = 'not_allowed';
            }
        }
    }

    return $caps;
}

add_filter( 'map_meta_cap', 'wpse_188863_map_meta_cap', 10, 4 );

// Delete comments out of menu

function remove_menus() {
    remove_menu_page( 'edit-comments.php' );
}
add_action( 'admin_menu', 'remove_menus' );