/* eslint-disable import/no-default-export */
import breakpoints from '../__constants/breakpoints';

const megaMenu = {
    menuItems: document.querySelectorAll('.main-nav > .menu > .menu-item-has-children'),
    menuWrapper: document.querySelector('.main-header .main-nav'),

    setMegaMenuWrappersWidth() {
        if (!breakpoints.desktopMin.matches || typeof(this.menuItems) === 'undefined' && this.menuItems === null) {
            return;
        }

        const menuWrapperDimensions = this.menuWrapper.getBoundingClientRect();
        const menuWrapperWidth = menuWrapperDimensions.width;
        const menuWrapperRight = menuWrapperDimensions.right;
        const menuWrapperLeft = menuWrapperDimensions.left;

        this.menuItems.forEach(item => {
            if (item.classList.contains('columns-count-2') || item.classList.contains('columns-count-1')) {
                const classes = ['column-align-right', 'column-align-left'];
                item.classList.remove(...classes);
        
                const megaMenuWrapper = item.querySelector('.mega-menu-wrapper');
                const megaMenuWrapperWidth = item.classList.contains('columns-count-1') ? menuWrapperWidth / 4 : menuWrapperWidth / 2;
                
                megaMenuWrapper.style.width = `${megaMenuWrapperWidth}px`;
                
                const megaMenuWrapperDimensions = megaMenuWrapper.getBoundingClientRect();
                const megaMenuWrapperRight = megaMenuWrapperDimensions.right;
                const megaMenuWrapperLeft = megaMenuWrapperDimensions.left;

                if (megaMenuWrapperRight > menuWrapperRight) {
                    item.classList.add(classes[0]);
                } else if (megaMenuWrapperLeft < menuWrapperLeft) {
                    item.classList.add(classes[1]);
                }
            }
        });
    },

    showMenu() {
        this.classList.add('open');
    },

    hideMenu() {
        this.classList.remove('open');
    },

    init() {
        // this.setMegaMenuWrappersWidth();

        this.menuItems.forEach(item => {
            item.addEventListener('mouseenter', this.showMenu, {passive: true});
            item.addEventListener('mouseleave', this.hideMenu, {passive: true});
        });

    }
}

window.addEventListener("scroll", () => {
    const scrolled = window.pageYOffset > 1;
    document.querySelectorAll(".main-header__fixed-header").forEach((el) => el.classList.toggle("fixed", scrolled));
    document.querySelectorAll(".main-header__wrapper").forEach((el) => el.classList.toggle("scaled", scrolled));
}, { passive: true });


const initDropdownBodyClass = () => {
    document.querySelectorAll('.main-header .main-nav>.menu>.menu-item.menu-item-has-children').forEach((dropdown) => {
        dropdown.addEventListener('mouseover', () => {
            document.body.classList.add('dropdown--isOpen');
        });
        dropdown.addEventListener('mouseout', () => {
            document.body.classList.remove('dropdown--isOpen');
        });
    });
};

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initDropdownBodyClass);
} else {
    initDropdownBodyClass();
}

export default megaMenu;
