<?php
/**
 * The Header for theme.
 *
 * Displays all of the <head> section and page header
 *
 * Hooks for placing content (used by the ATLAS Content Blocks plugin):
 * - wp_body_open        Right after <body>
 * - atlas_before_header Before the site header
 * - atlas_after_header  After the site header, before the page content
 *
 * @package    WordPress
 * @subpackage ATLAS
 * @since      ATLAS 1.0
 */

get_theme_part( 'html-head' );

?>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<?php echo Theme_App::render_scripts( 'begin_scripts' ); ?>
<div id="page">
	<?php do_action( 'atlas_before_header' ); ?>
	<?php get_theme_part('components/header/main'); ?>
	<?php do_action( 'atlas_after_header' ); ?>
