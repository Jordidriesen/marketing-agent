<?php
add_filter( 'render_block', 'wrap_post_terms_block', 10, 2 );
function wrap_post_terms_block( $block_content, $block ) {
	if ( 'core/post-terms' === $block['blockName'] ) {
		$block_content = '<div data-styles-id="core-post-terms"></div>' . $block_content;
	}
	return $block_content;
}
