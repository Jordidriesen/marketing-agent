const $ = jQuery.noConflict();

$(document).ready(() => {
    const user_login_input = $('input#user_login');
    const user_login_parent = user_login_input.parent();

    const user_pass_input = $('input#user_pass');
    const user_pass_parent = user_pass_input.parent().parent();

    const handleValue = (input, parent) => {
        const inputValue = input.val();
        if (inputValue || inputValue !== '') {
            parent.addClass('valued');
        }
    };

    const handleFocus = (input, parent) => {
        handleValue(input, parent);

        input.on('change', () => {
            handleValue(input, parent);
        });

        input.on('focus', () => {
            parent.addClass('valued');
        });

        input.on('focusout', (e) => {
            const val = $(e.currentTarget).val();
            if (!val || val === '') {
                parent.removeClass('valued');
            }
        })
    };

    handleFocus(user_login_input, user_login_parent);
    handleFocus(user_pass_input, user_pass_parent);
});
