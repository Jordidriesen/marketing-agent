<?php
function get_spacing_styles() {
	$large = get_field('spacing_large', 'options') ? get_field('spacing_large', 'options') / 10 . 'rem' : '12rem';
	$medium = get_field('spacing_medium', 'options') ? get_field('spacing_medium', 'options') / 10 . 'rem' : '8rem';
	$small = get_field('spacing_small', 'options') ? get_field('spacing_small', 'options') / 10 . 'rem' : '4rem';
	$arr = ['mobile', 'tablet', 'small-desktop', 'desktop'];

	$html = '<style type="text/css">';

	foreach ($arr as $point) {
		$html .= ($point === 'tablet') ? '@media (min-width: 768px) {': '';
		$html .= ($point === 'small-desktop') ? '@media (min-width: 992px) {': '';
		$html .= ($point === 'desktop') ? '@media (min-width: 1200px) {': '';
		$html .= ".spacing-$point--none{height: 0}";
		$html .= ".spacing-$point--small{height: $small}";
		$html .= ".spacing-$point--medium{height: $medium}";
		$html .= ".spacing-$point--large{height: $large}";
		$html .= ($point !== 'mobile') ? '}': '';
	}

	$html .= '</style>';

	echo $html;
}
