<?php
$block_object = new Block( $block );
$name = $block_object->block_name();
$img_id = get_field('icon_text_image');
$title = get_field('icon_text_title');
$content = get_field('icon_text_content');
$image_full_width = get_field('icon_text_image_full_width');

$img = wp_get_attachment_image($img_id, 'thumbnail', false, 'data-object-fit');

$class = ( $image_full_width || empty($img)) ? $block_object->block_class()  . ' block-icon-text--full' : $block_object->block_class();

loadAcfBlockPreviewImage(__DIR__);

if (!empty($title) || !empty($content)) :
?>
<div class="<?php echo $class; ?>">
	<?php echo loadStyles(__DIR__, $name); ?>
	<div class="block-icon-text__row">
	<?php if (!empty($img)) : ?>
		<div class="block-icon-text__img-wrapper">
			<?php echo $img; ?>
		</div>
	<?php endif; ?>
		<div class="block-icon-text__content-wrapper">
		<?php if (!empty($title)) : ?>
			<h2 class="block-icon-text__title"><?php echo $title; ?></h2>
		<?php endif; ?>
		<?php if (!empty($content)) : ?>
			<div class="block-icon-text__content">
				<?php echo $content; ?>
			</div>
		<?php endif; ?>
		</div>
	</div>
</div>
<?php
endif;