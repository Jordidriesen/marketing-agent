/**
 * ATLAS Content Blocks: popups.
 *
 * Opens the <dialog> popups printed by the plugin. Native dialog behaviour
 * handles the focus trap, Escape to close and returning focus on close.
 *
 * Triggers:
 * - click: `.atlas-popup-{ID}`, `a[href="#atlas-popup-{ID}"]` or the popup's
 *   own selector (always active, whatever the automatic trigger)
 * - load: after a delay in seconds
 * - scroll: after scrolling a percentage of the page
 * - exit: when the pointer leaves through the top of the window (desktop)
 *
 * Frequency limits apply to automatic triggers only; a click always opens.
 *
 * Events on document: `atlas-popup:open` and `atlas-popup:close`, with
 * `detail.id` and `detail.dialog`, for example to start a form inside a popup
 * only when it opens.
 */
(function () {
	'use strict';

	var STORAGE_PREFIX = 'atlasPopupSeen-';

	var media = {
		mobile: '(max-width: 767px)',
		tablet: '(min-width: 768px) and (max-width: 1199px)',
		desktop: '(min-width: 1200px)'
	};

	var hiddenHere = function (config) {
		return (config.hideOn || []).some(function (device) {
			return media[device] && window.matchMedia(media[device]).matches;
		});
	};

	var storage = function (type) {
		try {
			var store = window[type];
			var probe = '__atlas_cb__';
			store.setItem(probe, probe);
			store.removeItem(probe);
			return store;
		} catch (e) {
			return null;
		}
	};

	var seenRecently = function (config) {
		var key = STORAGE_PREFIX + config.id;

		if (config.frequency === 'session') {
			var session = storage('sessionStorage');
			return !!(session && session.getItem(key));
		}

		if (config.frequency === 'days') {
			var local = storage('localStorage');
			var at = local ? parseInt(local.getItem(key), 10) : 0;
			return !!at && Date.now() - at < config.days * 86400000;
		}

		return false;
	};

	var markSeen = function (config) {
		var key = STORAGE_PREFIX + config.id;

		if (config.frequency === 'session') {
			var session = storage('sessionStorage');
			if (session) {
				session.setItem(key, '1');
			}
		} else if (config.frequency === 'days') {
			var local = storage('localStorage');
			if (local) {
				local.setItem(key, String(Date.now()));
			}
		}
	};

	var emit = function (name, popup) {
		var event;
		var detail = { id: popup.config.id, dialog: popup.dialog };
		try {
			event = new CustomEvent(name, { detail: detail });
		} catch (e) {
			event = document.createEvent('CustomEvent');
			event.initCustomEvent(name, false, false, detail);
		}
		document.dispatchEvent(event);
	};

	var open = function (popup, automatic) {
		var dialog = popup.dialog;

		if (dialog.open || hiddenHere(popup.config)) {
			return;
		}

		if (automatic) {
			// Never interrupt another open popup with an automatic one.
			if (document.querySelector('dialog.atlas-popup[open]')) {
				return;
			}
			if (seenRecently(popup.config)) {
				return;
			}
		}

		if (typeof dialog.showModal === 'function') {
			dialog.showModal();
		} else {
			dialog.setAttribute('open', '');
		}

		document.documentElement.classList.add('atlas-popup-open');
		markSeen(popup.config);
		emit('atlas-popup:open', popup);
	};

	var close = function (popup) {
		if (typeof popup.dialog.close === 'function') {
			popup.dialog.close();
		} else {
			popup.dialog.removeAttribute('open');
			popup.dialog.dispatchEvent(new Event('close'));
		}
	};

	var setupAutomatic = function (popup) {
		var config = popup.config;

		if (config.trigger === 'load') {
			window.setTimeout(function () {
				open(popup, true);
			}, Math.max(0, config.delay) * 1000);
		}

		if (config.trigger === 'scroll') {
			var onScroll = function () {
				var doc = document.documentElement;
				var max = doc.scrollHeight - window.innerHeight;
				var percent = max > 0 ? (window.pageYOffset / max) * 100 : 100;
				if (percent >= config.scroll) {
					window.removeEventListener('scroll', onScroll);
					open(popup, true);
				}
			};
			window.addEventListener('scroll', onScroll, { passive: true });
			onScroll();
		}

		if (config.trigger === 'exit' && window.matchMedia('(pointer: fine)').matches) {
			var onLeave = function (event) {
				if (!event.relatedTarget && event.clientY <= 0) {
					document.removeEventListener('mouseout', onLeave);
					open(popup, true);
				}
			};
			document.addEventListener('mouseout', onLeave);
		}
	};

	var init = function () {
		var popups = [];

		document.querySelectorAll('dialog.atlas-popup[data-atlas-popup]').forEach(function (dialog) {
			var config;
			try {
				config = JSON.parse(dialog.getAttribute('data-atlas-popup'));
			} catch (e) {
				return;
			}

			var popup = { dialog: dialog, config: config };
			var selectors = ['.atlas-popup-' + config.id, 'a[href="#atlas-popup-' + config.id + '"]'];

			if (config.selector) {
				try {
					document.querySelector(config.selector);
					selectors.push(config.selector);
				} catch (e) {
					// Ignore an invalid selector rather than break every popup.
				}
			}

			popup.selector = selectors.join(',');
			popups.push(popup);

			dialog.querySelector('.atlas-popup__close').addEventListener('click', function () {
				close(popup);
			});

			// A click on the backdrop lands on the dialog itself, outside the box.
			dialog.addEventListener('click', function (event) {
				if (config.closeOverlay && event.target === dialog) {
					close(popup);
				}
			});

			dialog.addEventListener('close', function () {
				if (!document.querySelector('dialog.atlas-popup[open]')) {
					document.documentElement.classList.remove('atlas-popup-open');
				}
				emit('atlas-popup:close', popup);
			});

			setupAutomatic(popup);
		});

		if (!popups.length) {
			return;
		}

		document.addEventListener('click', function (event) {
			if (!(event.target instanceof Element)) {
				return;
			}
			popups.some(function (popup) {
				if (event.target.closest(popup.selector)) {
					event.preventDefault();
					open(popup, false);
					return true;
				}
				return false;
			});
		});

		// Open from a link to the popup's anchor, e.g. a shared URL ending in #atlas-popup-123.
		var hash = window.location.hash.replace('#', '');
		popups.forEach(function (popup) {
			if (hash === popup.dialog.id) {
				open(popup, false);
			}
		});

		window.atlasPopups = {
			open: function (id) {
				popups.forEach(function (popup) {
					if (popup.config.id === Number(id)) {
						open(popup, false);
					}
				});
			},
			close: function (id) {
				popups.forEach(function (popup) {
					if (popup.config.id === Number(id)) {
						close(popup);
					}
				});
			}
		};
	};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
