class HeaderLanguageDropdown {
  constructor () {
    this.wrapper = [...document.querySelectorAll('.main-header__icons-language, .main-header__icons-user')]
    this.trigger = this.wrapper.flatMap(el => [...el.querySelectorAll('#language-icon, #icon-user')])
    this.active = false
  }

  init () {
    this.registerListeners()
  }

  registerListeners () {
    this.trigger.forEach(trigger => {
      trigger.addEventListener('click', event => {
        event.currentTarget.parentElement.classList.toggle('active')
      })
    })
  }

  toggleList () {
    if (this.active) {
      this.hideList()
    } else {
      this.showList()
    }
  }

  hideList () {
    this.active = false
    this.wrapper.forEach(el => el.classList.remove('active'))
  }

  showList () {
    this.active = true
    this.wrapper.forEach(el => el.classList.add('active'))
  }

  hideOutsideClick (e) {
    const clicked = e.target
    const containerActive = this.wrapper.length > 0 && this.wrapper[0].classList.contains('active')

    if (this.trigger.length > 0 && containerActive && !this.trigger[0].contains(clicked)) {
      if (!this.wrapper.some(el => el.contains(clicked))) {
        this.wrapper.forEach(el => el.classList.remove('active'))
      }
    }
  }
}

export default new HeaderLanguageDropdown()
