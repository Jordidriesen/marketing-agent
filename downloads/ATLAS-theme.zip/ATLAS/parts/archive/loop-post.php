<?php
/**
 * Loop for home page.
 *
 * @package    WordPress
 * @subpackage ATLAS
 * @since      ATLAS 1.0
 */

?>
<section class="posts-content">
	<div class="row">
	<?php 
	while ( have_posts() ) : the_post(); 
		$id = get_the_ID();
	?>
        <div class="col col-12 col-md-6 col-lg-4"><?php get_theme_part('components/single-news/index', ['id' => $id, 'btn_txt'=> __('Read More', 'ATLAS')]); ?></div>
	<?php endwhile; ?>
	</div>
</section>
