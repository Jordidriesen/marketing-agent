class Map {
    constructor(block) {
        this.block = block;
        this.mapReference = null;
        this.mapDefaultOptions = {
            zoom: 16,
            center: new google.maps.LatLng(0, 0),
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            zoomControl: false,
            mapTypeControl: false,
            scaleControl: false,
            streetViewControl: false,
            rotateControl: false,
            fullscreenControl: false,
        };
        this.mapMarkerIcon = this.block.getAttribute('data-marker');
        this.mapMarker = this.block.querySelector('.marker');
        this.mapMarkerLat = this.mapMarker.getAttribute('data-lat');
        this.mapMarkerLng = this.mapMarker.getAttribute('data-lng');
        this.init();
    }

    init() {
        this.renderMap();
        this.renderMarker();
        this.setMapPosition();
    }

    renderMap() {
        this.mapReference = new google.maps.Map(this.block, this.mapDefaultOptions);
    }

    renderMarker() {
        const latlng = new google.maps.LatLng(this.mapMarkerLat, this.mapMarkerLng);

        new google.maps.Marker({
            position: latlng,
            map: this.mapReference,
            icon: this.mapMarkerIcon,
        });
    }

    setMapPosition() {
        const bounds = new google.maps.LatLngBounds();
        const windowWidth = document.documentElement.clientWidth;

        const latlng = new google.maps.LatLng(this.mapMarkerLat, this.mapMarkerLng);
        bounds.extend(latlng);

        this.mapReference.fitBounds(bounds, {right: 1000});

        let panX = window.matchMedia('(max-width: 1200px)').matches ? windowWidth / 3 : windowWidth / 6;

        if (window.matchMedia('(max-width: 991px)').matches) {
            panX = 0;
        }

        google.maps.event.addListenerOnce(this.mapReference, 'bounds_changed', () => {
            this.mapReference.setZoom(this.mapDefaultOptions.zoom);
            this.mapReference.panBy(panX, 0);
        });
    }
}

const initBlock = () => {
    [...document.querySelectorAll('.acf-map')].forEach(block => new Map(block));
};

initBlock();

if (window.acf) {
    window.acf.addAction('render_block_preview/type=map', initBlock);
}