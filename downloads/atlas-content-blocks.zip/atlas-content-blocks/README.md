# ATLAS Content Blocks

Reusable content built in the block editor, shown automatically at theme locations or as popups, with display conditions. It works like Blocksy's Content Blocks extension, built for the ATLAS theme.

## Requirements

- WordPress 6.3 or later, PHP 7.4 or later.
- **The ATLAS theme hook points are required for most locations.** `header.php` and `footer.php` call `wp_body_open`, `atlas_before_header`, `atlas_after_header`, `atlas_before_footer` and `atlas_after_footer`. Without those theme changes, only "Start/End of post content", custom hooks and manual placement work.

## Using it

**Content Blocks** appears in the admin menu. Build the content with any block, including the ATLAS ACF blocks. Then set the following in **Display settings**:

| Setting | Options |
|---|---|
| Type | Content block (placed at a location) or Popup |
| Location | Right after `<body>`, before or after the header, start or end of post content, before or after the footer, a custom hook, or "nowhere automatically" (manual placement only) |
| Order | Lower numbers run first when several blocks share a location |
| Display conditions | "Show on" and "Hide on" rules. A block shows where any Show rule matches, unless a Hide rule matches. Rules cover the entire site, front page, blog page, search, 404, single or archive per post type, specific IDs, pages below a parent, taxonomy terms and page templates. Also: visitors (everyone, logged out, logged in) and a schedule (from and until, site time zone) |
| Hide on devices | Mobile (below 768 px), tablet (768 to 1199 px), desktop (1200 px and up). Done in CSS, so it is safe with page caching |

### Popups

Popups are native `<dialog>` elements and need no jQuery. The dialog handles the focus trap, closing with Escape and returning focus to the trigger.

- **Opens:** on click only, after a delay, after scrolling a percentage of the page, or on exit intent (desktop).
- **Click triggers always work:** any element with the class `atlas-popup-{ID}`, any link to `#atlas-popup-{ID}`, and the optional CSS selector you enter. The selector makes migrating from Popup Maker easy: enter the old trigger selectors, such as `#ebookwfm`.
- **Frequency** (automatic triggers only): every page view, once per visit, or once every N days. Stored in the visitor's browser.
- **Other settings:** size (small, medium, large, full screen), whether a click on the background closes it, and the name screen readers announce.
- **JavaScript:** `window.atlasPopups.open(id)` and `.close(id)` open and close a popup from code. The events `atlas-popup:open` and `atlas-popup:close` fire on `document`, with `detail.id` and `detail.dialog`. Use them, for example, to load a HubSpot form only when its popup opens.

### Manual placement

Place a block by hand with the **Content Block** editor block or with the shortcode `[atlas_content_block id="123"]`.

- By default it always shows where you place it. Turn on "Apply its display conditions" (block), or add `conditions="yes"` (shortcode), to respect the block's own rules.
- Placing a popup by hand prints it on that page so its triggers work there. Nothing appears in place.

## WPML

`wpml-config.xml` makes the post type translatable. Settings are copied once into a new translation and can then differ per language.

- Each language shows its own translated blocks.
- IDs entered in rules also match their translations.
- Manual placements use the translation of the chosen block.

## Caching

Display conditions are evaluated on the server when the page is built:

- Rules about the page (post type, IDs, terms and so on) are safe with full-page caching.
- The "logged in/out" rule and the schedule are only as precise as the cache lifetime. Logged-in users usually bypass the cache, so the login rule normally works in practice.

The list of blocks and their settings is cached and cleared whenever a block is saved, published, unpublished, trashed or deleted.

## Developer hooks

| Hook | Purpose |
|---|---|
| `atlas_cb_locations` (filter) | Add locations: `$locations['my_hook'] = 'Label';` |
| `atlas_cb_matches` (filter) | Final say on whether a block shows: `( bool $show, array $settings )` |
| `atlas_cb_content` (filter) | Change a block's rendered HTML: `( string $html, int $id, array $settings )` |
| `atlas_cb_resolved` (action) | Fires after matching, with the hook blocks and popups for the request |

## Uninstalling

Uninstalling removes the plugin's cache, but **keeps the content blocks** (posts of type `atlas_block`). Delete them first if they are no longer needed.
