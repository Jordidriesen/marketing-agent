<?php
// Register CPT Team if doesn't exists
custom_register_team_cpt();

// Register block
function init_block_team_tile() {
    if ( ! function_exists( 'acf_register_block' ) ) {
        return;
    }

    acf_register_block( array(
        'name'              => 'team-tile',
        'title'             => __( 'Mitarbeiter Kachel / Team Tile', 'ATLAS' ),
        'description'       => __( 'Team Tile', 'ATLAS' ),
        'category'          => 'custom_blocks',
        'icon'              => 'businessman',
        'mode'              => 'auto',
        'keywords'          => array( 'team', 'team tile', 'tile', 'kachel', 'mitarbeiter' ),
        'supports'          => array(
			'align' => false,
        ),
		'example'         => [
            'attributes' => [
                'mode' => 'auto',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-team-tile/index.php',
    ));
}

add_action( 'acf/init', 'init_block_team_tile' );