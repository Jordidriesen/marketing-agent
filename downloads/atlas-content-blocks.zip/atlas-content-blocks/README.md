# ATLAS Content Blocks

Reusable content built in the block editor, shown automatically at theme locations, inside the post content or as popups, with display conditions. It matches the hook and popup parts of Blocksy's Content Blocks extension, built for the ATLAS theme.

## Requirements

- WordPress 6.5 or later (the in-content locations use the core HTML Tag Processor), PHP 7.4 or later.
- **The ATLAS theme hook points are required for most locations.** `header.php` and `footer.php` call `wp_body_open`, `atlas_before_header`, `atlas_after_header`, `atlas_before_footer` and `atlas_after_footer`. Without them, only the in-content locations, custom hooks and manual placement work.

## Using it

**Content Blocks** appears in the admin menu. Build the content with any block, including the ATLAS ACF blocks, then set the options in **Display settings**. Every block keeps revisions of its content, and the list screen has a **Duplicate** row action (the copy is a draft titled "(copy)", with the same content and settings).

### Type

- **Content block:** placed at one or more locations in the page.
- **Popup:** a native `<dialog>`, opened by a trigger.

### Placement (content blocks)

Tick any number of locations; the block renders at each of them.

| Location | Where |
|---|---|
| Right after `<body>` | `wp_body_open` |
| Before or after header | `atlas_before_header`, `atlas_after_header` |
| Before or after footer | `atlas_before_footer`, `atlas_after_footer` |
| Start or end of post content | The main post's content only |
| After paragraph N | After the Nth top-level paragraph of the main post content. With fewer paragraphs, the block goes at the end of the content |
| Before heading N | Before the Nth top-level heading (h1 to h6). With fewer headings, the block is left out |
| Custom hook | Any action name, for example one fired by another plugin |

With no location ticked, the block only shows where it is placed by hand (see below). **Priority** orders blocks that share a location (lower runs first).

In-content locations count only the top-level paragraphs and headings of the main post's own content: paragraphs inside groups, columns or other blocks are not counted, and nothing is injected into excerpts, nested `the_content` calls or other content blocks.

### Container (content blocks)

| Structure | Result |
|---|---|
| Default | No wrapper styling (the content decides its own spacing) |
| None | The wrapper and the first and last child lose their margins and padding |
| Custom | Wrapped in the theme's own grid container. **Layout width:** Boxed uses `.container` (460px, 710px, 1020px and 1320px at the theme breakpoints, 24px side padding); Wide uses `.container.container--full` (full width, same side padding). **Content layout:** Standard, or Narrow (710px wide, centred) |

**Spacing above and below** (Default and Custom): none, small, medium or large. These use the theme's spacing scale from Theme settings (spacing small, medium and large; 4rem, 8rem and 12rem unless changed), the same values as the theme's spacer classes.

### Conditions

Two modes:

- **Basic: include and exclude.** Include rules are grouped by kind (page rules, date and time, requests, visitor, language). The block shows when, for every kind used, at least one include rule matches, and no exclude rule matches. For example "Entire website" + "Logged in" + "Recurring: Mon to Fri" means logged-in visitors on weekdays, anywhere. No include rules means nowhere.
- **Advanced: groups.** The block shows when every rule in at least one group matches (OR between groups, AND inside a group). Each rule can be set to "is" or "is not".

| Kind | Rules |
|---|---|
| General | Entire website, All singulars, All archives, Front page, Blog (latest posts page), Search results, 404 page, Privacy policy page, Author archives (optionally specific author IDs) |
| Posts and pages | Post archives, Post category archives, Post tag archives, Single post, Single page |
| Post types | Single and archive for every public custom post type |
| Specific | Specific posts, pages or items (IDs), Pages below a parent (IDs), Posts with a taxonomy term (taxonomy plus term IDs or slugs), Posts by author (user IDs), Taxonomy term archive (taxonomy plus optional term IDs or slugs), Page template |
| Date and time | Date range (from and until, site time zone), Recurring days (weekdays, optionally between two times; a window like 22:00 to 06:00 runs over midnight) |
| Requests | Page URL, Referrer (contains, is exactly or starts with; case insensitive), Cookie (name, optionally with a value) |
| Visitor | Logged in, Logged out, User role |
| Languages | Language (only offered with WPML active; without WPML a stored language rule never matches and never causes an error) |

The URL rule compares with both the full URL and the path plus query string, so `/offer/` and `utm_source=newsletter` both work.

### Devices

Hide a block or popup on mobile (below 768px), tablet (768 to 1199px) or desktop (1200px and wider). Content blocks are hidden with CSS, so this is safe with page caching; popups also refuse to open on a hidden device.

### Popups

Popups are native `<dialog>` elements and need no jQuery.

**Triggers** (one automatic trigger per popup):

- Only on click; on page load; after a number of seconds
- On scroll down (pixels, or percent of the page); on scroll up (once the visitor scrolls back up 50px or more); when an element (CSS selector) comes into view
- After a number of seconds of inactivity (no pointer, key, wheel, touch or scroll input)
- After a number of pages visited (counted in the visitor's `localStorage` on every page while such a popup exists)
- Exit intent: the pointer leaves through the top of the window (desktop pointers only)

Click triggers always work, whatever the automatic trigger: any element with the class `atlas-popup-{ID}`, any link to `#atlas-popup-{ID}`, and the optional CSS selector (handy when migrating from Popup Maker: enter the old trigger selectors such as `#ebookwfm`). A URL ending in `#atlas-popup-{ID}` opens the popup on load.

**Relaunch** (automatic triggers only, stored in the visitor's browser): always, once per visit, or again after a number of minutes, hours or days. A click always opens.

**Closing:** the X button; Escape (can be turned off); a click on the backdrop (modal popups); when a form inside is submitted (native `submit` events, plus HubSpot's `onFormSubmitted` message and `hs-form-event:on-submission:success` event); a click on elements matching a CSS selector; scrolling back up past the point where the popup opened (needs scroll lock off). The selector and form closes wait for the optional delay in seconds.

**Behaviour:**

- **Animation:** none, fade, zoom, or slide from the top, bottom, left or right, both opening and closing. Off for visitors who prefer reduced motion.
- **Focus trap:** on opens the popup with `showModal()` (the browser traps focus, shows the backdrop and returns focus on close). Off opens it with `show()`: no backdrop, no scroll lock, and the page stays usable; Escape still closes it.
- **Scroll lock:** stops the page scrolling while a modal popup is open.
- **Load content on demand:** the content is printed inside a `<template>` and only put in the page on the first open. Scripts in it run at that moment (checked in Chromium). Assets the content enqueues still load with the page.
- **Stop videos and audio on close:** pauses `<video>` and `<audio>` and reloads YouTube, Vimeo and Wistia iframes.
- **Stacking:** a popup can open another popup (for example a button with the class `atlas-popup-{ID}` inside it). Automatic triggers never interrupt an open popup.

**Design:** size (small 420px, medium 640px, large 960px, full screen, or a custom width), maximum height, position (top left, top, top right, left, centre, right, bottom left, bottom, bottom right), offset from the edges, padding, border radius, shadow, content overflow (scroll, clip or visible), background colour, close button position (inside, or outside above the corner) and colours, backdrop on or off, backdrop colour, opacity and blur. Per-popup values are set as CSS custom properties on the dialog (`--atlas-popup-width`, `--atlas-popup-max-height`, `--atlas-popup-offset`, `--atlas-popup-padding`, `--atlas-popup-radius`, `--atlas-popup-bg`, `--atlas-popup-close-color`, `--atlas-popup-close-bg`, `--atlas-popup-backdrop`, `--atlas-popup-blur`), so the theme can override them.

**JavaScript:**

- `window.atlasPopups.open(id)`, `.close(id)`, `.closeAll()` and `.isOpen(id)`.
- The events `atlas-popup:open` and `atlas-popup:close` bubble from the dialog to `document`, with `detail.id` and `detail.dialog`. Use them, for example, to load a HubSpot form only when its popup opens.

Note: Chromium only lets a page keep a modal popup open on Escape after the visitor has interacted with the page, so "Close with the Escape key" off cannot always be enforced.

### Manual placement

Place a block by hand with the **Content Block** editor block or with the shortcode `[atlas_content_block id="123"]`.

- By default it always shows where you place it. Turn on "Apply its display conditions" (block), or add `conditions="yes"` (shortcode), to respect the block's own conditions.
- Placing a popup by hand prints it on that page so its triggers work there. Nothing appears in place.

### Admin toolbar

On the front end, people who can edit content blocks get a **Content Blocks (N)** menu in the toolbar, listing every block and popup output on the current page with a link to edit it. To list blocks rendered anywhere in the page, the plugin prints the toolbar in the footer for these users instead of right after `<body>` (it is fixed in place, so it looks the same).

## WPML

`wpml-config.xml` makes the post type translatable. Settings are copied once into a new translation and can then differ per language.

- Each language shows its own translated blocks.
- IDs entered in rules (posts, parents, the privacy page, term IDs) also match their translations.
- Manual placements use the translation of the chosen block.

## Caching

Conditions are evaluated on the server when the page is built.

- Page rules (post types, IDs, terms and so on) are safe with full-page caching.
- **Date and time, request (URL, referrer, cookie) and visitor rules do not work with full-page caching unless the cache varies on them** (or is bypassed for those pages). Logged-in users usually bypass the cache, so login and role rules normally work in practice; a cached page shows whatever matched when it was cached for the other rules.
- Device visibility and popup relaunch limits run in the browser and are safe with caching.

The list of blocks and their settings is cached and cleared whenever a block is saved, published, unpublished, trashed or deleted.

## Developer hooks

| Hook | Purpose |
|---|---|
| `atlas_cb_locations` (filter) | Add theme locations: `$locations['my_hook'] = 'Label';` |
| `atlas_cb_rule_matches` (filter) | Change the result of one rule: `( bool $result, array $rule )` |
| `atlas_cb_matches` (filter) | Final say on whether a block shows: `( bool $show, array $settings )` |
| `atlas_cb_content` (filter) | Change a block's rendered HTML: `( string $html, int $id, array $settings )` |
| `atlas_cb_resolved` (action) | Fires after matching, with the hook blocks and popups for the request |

## Upgrading from 1.0

Settings saved by 1.0 are converted when read: the single location becomes a list ("nowhere automatically" becomes no locations), the visitor and schedule fields become Logged in/out and Date range rules, `taxonomy:slug` term rules become "Posts with a taxonomy term", the scroll percentage trigger becomes "scroll down" in percent, and "once every N days" becomes "again after N days". Saving the block stores the new format.

## Compared with Blocksy

Equivalent:

- Hooks: multiple locations with priority, custom hooks, after paragraph N and before heading N, device visibility, user role and login state, language, date range and recurring schedules, container structure (Default, None, Custom with Boxed or Wide and Standard or Narrow) and vertical spacing, the Content Block editor block and shortcode, duplicate, revisions, and the admin toolbar menu.
- Conditions: every rule listed in Blocksy's conditions builder except WooCommerce, with basic include and exclude and advanced groups.
- Popups: every trigger, relaunch, close action, animation, focus trap, scroll lock, stacking, stopping videos, the design options, a JavaScript API and events.

Different or deliberately not included:

- **Templates** (header, footer, single, archive, 404, nothing found, maintenance): not included; ATLAS has its own templates.
- **WooCommerce rules:** not included; the site does not use WooCommerce.
- **Code editor mode:** not included; use the block editor (a Custom HTML block for code).
- **Load content on demand** uses a `<template>` element in the page instead of an AJAX request: no extra request and it works with page caching, but the content is still part of the page HTML.
- **Basic mode** combines include rules of different kinds with AND (see Conditions), so visitor and date rules restrict page rules instead of widening them.

## Uninstalling

Uninstalling removes the plugin's cache, but **keeps the content blocks** (posts of type `atlas_block`). Delete them first if they are no longer needed.
