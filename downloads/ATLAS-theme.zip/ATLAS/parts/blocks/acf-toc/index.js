import { slideUp, slideDown } from 'lib/slide';

const trigger = '.block-toc__title';

const toggleToc = (e) => {
    const el = e.target;
    const parent = el.parentElement;
    const elContent = parent.nextElementSibling;
    const wrapper = parent.closest('.block-toc');

    if (parent.classList.contains('active')) {
        parent.classList.remove('active');
        slideUp(elContent, 250);
    } else {
        if (wrapper && wrapper.classList.contains('singular-open')) {
            wrapper.querySelectorAll('.active').forEach((active) => {
                active.classList.remove('active');
                slideUp(active.nextElementSibling, 250);
            });
        }
        parent.classList.add('active');
        slideDown(elContent, 250);
    }
}

const initToc = () => {
    document.querySelectorAll(trigger).forEach((title) => {
        title.addEventListener('click', toggleToc);
    });
};

const backendTocInit = () => {
    document.addEventListener('click', (e) => {
        if (e.target instanceof Element && e.target.matches(trigger)) {
            toggleToc(e);
        }
    });
}

initToc();
export { backendTocInit };
