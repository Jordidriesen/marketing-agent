<?php
/**
 * Block with cases_archive slider
 *
 * @package WordPress
 * @subpackage ATLAS
 * @since ATLAS 1.0
 */
$block_object = new Block( $block );

loadAcfBlockPreviewImage(__DIR__);

$latest = get_field('display_latest_cases_archive');
$latest_number = get_field('number_of_latest_cases_archive');
$cases_archive = get_field('slider_cases_archive');
$buttons_text = get_field('buttons_text');

if ( $latest ) {
    $num = $latest_number ? $latest_number : 6;
    $args = array(
        'post_type' => 'case',
        'post_status' => 'publish',
        'posts_per_page' => $num,
        'facetwp' => true,
        'post_parent__not_in' => array(0) // Exclude parent pages
    );
    $the_query = new WP_Query( $args );
}

if ( $cases_archive || ($latest && $the_query->have_posts()) ) :
    $name = $block_object->block_name();
?>
<section class="block-cases-archive">
    <?php loadStyles(__DIR__, $name); ?>
    <div class="block-cases-archive__container">
        <div class="block-cases-archive__wrapper">
        <?php
        if ( $latest ) {
            if( $the_query->have_posts() ) {
                while ( $the_query->have_posts() ) { $the_query->the_post();
                    $id = get_the_ID();
                    get_theme_part('components/single-case/index', ['id' => $id, 'btn_txt'=> $buttons_text]);
                }
            }
            wp_reset_postdata();
        } else {
            foreach ($cases_archive as $id) :
                $id = apply_filters( 'wpml_object_id', $id, 'product', TRUE  );
                get_theme_part('components/single-case/index', ['id' => $id, 'btn_txt'=> $buttons_text]);
            endforeach;            
        }
        ?>
        </div>
    </div>
</section>
<?php
endif;