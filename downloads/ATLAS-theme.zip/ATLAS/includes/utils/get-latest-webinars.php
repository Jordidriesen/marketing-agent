<?php
function get_latest_webinars($amount = 3, $exclude_id = 0) {
	return new WP_Query([
		'post_type'      => 'webinar',
		'post_status'    => 'publish',
		'posts_per_page' => $amount,
		'post__not_in'   => $exclude_id ? [$exclude_id] : [],
		'orderby'        => 'date',
		'order'          => 'DESC',
	]);
}
