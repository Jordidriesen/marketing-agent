<?php
/**
 * The single post page template.
 *
 * @package    WordPress
 * @subpackage ATLAS
 * @since      ATLAS 1.0
 */

get_header();
the_post();
?>
	<main class="page-content page-content--single">
		<div class="page-entry">
			<?php the_content(); ?>
		</div>
	</main>
<?php
get_footer();
