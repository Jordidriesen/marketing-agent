<?php
$block_object = new Block( $block );
$name = $block_object->block_name();
$title = get_field('gallery_title');
$nav = get_field('show_thumbnail_navigation');
$gallery = get_field('gallery_row');

loadAcfBlockPreviewImage(__DIR__);

if ( !empty($gallery) ) :
    $gallery_length = count($gallery);
    $layout_counter = $block['id'];
?>
<section class="<?php echo $block_object->block_class(); ?>">
    <?php loadStyles(__DIR__, $name); ?>
    <?php loadStylesThird('splide'); ?>
    <div class="block-gallery__container">
        <div class="block-gallery__wrapper">
        <?php if (!empty($title)) : ?>
            <h2 class="section-heading is-style-underline"><?php echo $title; ?></h2>
        <?php endif; ?>
            <div class="block-gallery__slider" data-slider="<?php echo $layout_counter; ?>">
            <?php
            for($i = 0; $i < $gallery_length; $i++):
                $img = wp_get_attachment_image($gallery[$i]['image'], 'slider-gallery-full', false, 'data-object-fit');
                $title = $gallery[$i]['title'];
                $text = $gallery[$i]['text'];

                if (!empty($img)):
            ?>
                <div class="block-gallery__single-slide">
                    <figure class="block-gallery__slide-image"><?php echo $img; ?></figure>
                <?php if (!empty($title) || !empty($text)) : ?>
                    <div class="block-gallery__content-wrapper">
                    <?php if (!empty($title)) : ?>
                        <span class="block-gallery__content-title" role="heading"><?php echo $title; ?></span>
                    <?php endif; ?>
                    <?php if (!empty($text)) : ?>
                        <p class="block-gallery__content"><?php echo $text; ?></p>
                    <?php endif; ?>
                    </div>
                <?php endif; ?>
                </div>
            <?php
                endif;
            endfor;
            ?></div>
        <?php if ($nav) : ?>
            <div class="block-gallery__nav row" data-slider="<?php echo $layout_counter .'_nav'; ?>" data-gallery-nav="<?php echo $layout_counter; ?>">
            <?php
            for($i = 0; $i < $gallery_length; $i++):
                $img = wp_get_attachment_image($gallery[$i]['image'], 'slider-gallery-nav');

                if (!empty($img)):
            ?>
                <div class="block-gallery__nav-single col">
                    <figure class="block-gallery__nav-image"><?php echo $img; ?></figure>
                </div>
            <?php
                endif;
            endfor;
            ?></div>
        <?php endif; ?>
        </div>
	</div>
</section>
<?php
endif;