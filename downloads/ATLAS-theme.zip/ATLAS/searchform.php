<?php
/**
 * The search form template.
 *
 * @package    WordPress
 * @subpackage ATLAS
 * @since      ATLAS 1.0
 */

?>

<div class="main-header-search main-header-search__close">
	<div id="close-icon" class="close-icon"></div>
</div>

<form class="search-form" method="get" action="<?php bloginfo( 'url' ); ?>">
	<input type="text" name="s" id="s" placeholder="<?php echo __( 'Search ...', 'ATLAS' ); ?>"/>
	<button type="submit" class="search-submit"></button>
</form>