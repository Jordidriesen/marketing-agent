<?php
/**
 * Block with archive slider
 *
 * @package WordPress
 * @subpackage ATLAS
 * @since ATLAS 1.0
 */
$block_object = new Block( $block );

loadAcfBlockPreviewImage(__DIR__);

$latest = get_field('display_latest_products');
$latest_number = get_field('number_of_latest_products');
$archive = get_field('slider_products');
$buttons_text = get_field('buttons_text');

if ( $latest ) {
    $num = $latest_number ? $latest_number : 6;
    $args = array(
        'post_type' => 'product',
        'post_status' => 'publish',
        'posts_per_page' => $num,
        'orderby' => 'post_title',
        'order' => 'ASC',
        'facetwp' => true,
    );

    $the_query = new WP_Query( $args );
}

if ( $archive || ($latest && $the_query->have_posts()) ) :
    $name = $block_object->block_name();
    $layout_counter = $block['id'];
?>
<section class="block-archive-products">
    <div class="block-archive-products__container">
        <div class="block-archive-products__wrapper">
        <?php
        if ( $latest ) {
            while ( $the_query->have_posts() ) { $the_query->the_post();
                $id = get_the_ID();
                $id = apply_filters( 'wpml_object_id', $id, 'product', TRUE  );
                get_theme_part('components/single-product/index', ['id' => $id, 'btn_txt'=> $buttons_text]);
            }            
        } else {
            foreach ($archive as $id) :
                $id = apply_filters( 'wpml_object_id', $id, 'product', TRUE  );
                get_theme_part('components/single-product/index', ['id' => $id, 'btn_txt'=> $buttons_text]);
            endforeach;         
        }
        ?>
        </div>
    </div>
</section>
<?php
endif;