const moreBtn = document.querySelectorAll('.pricing-box__more');

const initPricing = () => {
    moreBtn.forEach(item => {
        item.addEventListener('click', e => {
            e.preventDefault();
            const el = item;
            const closedClass = 'pricing-box__more--closed';
            const openClass = 'pricing-box__more--open';
            
            if (el.classList.contains(closedClass)) {
                el.classList.remove(closedClass);
                el.classList.add(openClass);
            } else {
                el.classList.add(closedClass);
                el.classList.remove(openClass);
            }
        }, false);
    });
};

initPricing();
