<?php
add_filter( 'render_block', 'styles_table_block', 10, 2 );
function styles_table_block( $block_content, $block ) {
  if ( 'core/table' === $block['blockName'] ) {
    $block_content = '<div data-styles-id="core-table"></div>' . $block_content;
  }
  return $block_content;
}

function extend_block_table_script() {
	wp_enqueue_script(
		'ATLAS/block_table_script',
		get_template_directory_uri() . '/parts/blocks/core-table/admin.min.js',
		array( 'wp-i18n', 'wp-dom-ready', 'wp-blocks' ),
		false,
		true
	);
}

function extend_table_styles() {
	if ( is_admin()) {
		wp_enqueue_style(
			'ATLAS/block_table_style',
			get_template_directory_uri() . '/parts/blocks/core-table/style.css'
		);
	}
}

add_action( 'enqueue_block_editor_assets', 'extend_block_table_script' );
add_action( 'enqueue_block_assets', 'extend_table_styles' );