<?php
function init_block_tabs()
{
    if (!function_exists('acf_register_block')) {
        return;
    }

    acf_register_block(array(
        'name'              => 'tabs',
        'title'             => __('Registerkarten / Tabs', 'ATLAS'),
        'description'       => __('Tabs block', 'ATLAS'),
        'category'          => 'custom_blocks',
        'icon'              => 'category',
        'mode'              => 'auto',
        'keywords'          => array('tab', 'tabs'),
        'align'             => 'full',
        'example'         => [
            'attributes' => [
                'mode' => 'preview',
            ]
        ],
        'supports'          => array(
            'align' => false,
        ),
        'render_template'   => get_template_directory() . '/parts/blocks/acf-tabs/index.php',
        'enqueue_assets'  => function () {
            wp_enqueue_script(
                'ATLAS/acf-tabs/',
                get_template_directory_uri() . (is_IE() ? '/parts/blocks/acf-tabs/index.ie.js' : '/parts/blocks/acf-tabs/index.min.js' ),
                [],
                false,
                array(
                    'in_footer' => true,
                    'strategy'  => 'defer',
                )
            );
        }
    ));
}
add_action('acf/init', 'init_block_tabs');

function register_tabs_init() {
	$labels = array(
		'name'                  => _x( 'Tabs', 'Post type general name', 'ATLAS' ),
		'singular_name'         => _x( 'Tabs', 'Post type singular name', 'ATLAS' ),
		'menu_name'             => _x( 'Tabs', 'Admin Menu text', 'ATLAS' ),
		'name_admin_bar'        => _x( 'Tabs', 'Add New on Toolbar', 'ATLAS' ),
		'add_new'               => __( 'Add New', 'ATLAS' ),
		'add_new_item'          => __( 'Add New Tabs', 'ATLAS' ),
		'new_item'              => __( 'New Tabs', 'ATLAS' ),
		'edit_item'             => __( 'Edit Tabs', 'ATLAS' ),
		'view_item'             => __( 'View Tabs', 'ATLAS' ),
		'all_items'             => __( 'All Tabs', 'ATLAS' ),
		'search_items'          => __( 'Search Tabs', 'ATLAS' ),
		'parent_item_colon'     => __( 'Parent Tabs:', 'ATLAS' ),
		'not_found'             => __( 'No Tabs found.', 'ATLAS' ),
		'not_found_in_trash'    => __( 'No Tabs found in Trash.', 'ATLAS' ),
		'archives'              => _x( 'Tabs archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'ATLAS' ),
		'insert_into_item'      => _x( 'Insert into Tabs', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'ATLAS' ),
		'uploaded_to_this_item' => _x( 'Uploaded to this Tabs', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'ATLAS' ),
		'filter_items_list'     => _x( 'Filter Tabs list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'ATLAS' ),
		'items_list_navigation' => _x( 'Tabs list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'ATLAS' ),
		'items_list'            => _x( 'Tabs list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'ATLAS' ),
	);
	
	$args = array(
		'labels'              => $labels,
		'public'              => false,
		'publicly_queryable'  => false,
		'exclude_from_search' => true,
		'show_in_nav_menus'   => false,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'rewrite'             => false,
		'query_var'           => false,
		'capability_type'     => 'post',
		'show_in_rest'        => true,
		'menu_icon'           => 'dashicons-category',
		'has_archive'         => false,
		'hierarchical'        => true,
		'supports'            => array( 'title', 'editor', 'page-attributes'),
	);
	
	register_post_type( 'tabs', $args );
}
add_action( 'init', 'register_tabs_init' );
