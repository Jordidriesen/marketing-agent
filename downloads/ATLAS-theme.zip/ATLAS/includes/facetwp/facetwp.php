<?php

add_filter( 'facetwp_index_row', function( $params, $class ) {
    if ( 'archive_year' == $params['facet_name'] ) { // change "archive_year" to the name of your facet
      $raw_value = $params['facet_value'];
      $params['facet_value'] = date( 'Y', strtotime( $raw_value ) ); // Use "11-2024" for the facet choice in the URL, so you can set the facet's "Sort by" setting to "Raw value" and order the months correctly.
      $params['facet_display_value'] = date( 'Y', strtotime( $raw_value ) ); // Use "November 2024" for the facet choice's display value
    }
    return $params;
}, 10, 2 );