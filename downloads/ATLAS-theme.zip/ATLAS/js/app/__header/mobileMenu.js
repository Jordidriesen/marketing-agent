/* eslint-disable no-unused-expressions */
/* eslint-disable import/no-default-export */
import ScreenLock from '../__constants/lock-screen';
import breakpoints from '../__constants/breakpoints';

const mobileMenu = {
    openBtn: document.querySelector('.mobile-menu-js__open'),
    closeBtn: document.querySelector('.mobile-menu-js__close'),
    mobileHeader: document.querySelector('.main-header__mobile--main'),
    mobileHeaderLink: document.querySelector('.mega-menu-header__link a'),
    mobileNav: document.querySelector('.main-nav-mobile'),
    mainLinks: document.querySelectorAll(
        '.main-header__mobile--main .main-nav-mobile > .menu > .menu-item > a'
    ),
    parentLinks: document.querySelectorAll(
        '.main-header__mobile--main .menu-item-has-children > a'
    ),
    subMenuBack: document.querySelectorAll(
        '.main-header__mobile--main .mobile-submenu-back'
    ),
    bottomButtons: document.querySelector(
        '.main-header__mobile--main .main-header__mobile-buttons'
    ),
    searchSideBar: document.querySelector('.main-header .meeting-search'),

    setTranistionDelay(items, setButtons = false, offset = 0.05) {
        // Set Transition delay
        const revealOffset = offset;
        let revealTime = 0;
        items.forEach((element) => {
            revealTime += revealOffset;
            // eslint-disable-next-line no-param-reassign
            element.style.transitionDelay = `${revealTime}s`;
        });

        // if (setButtons) {
        //     mobileMenu.bottomButtons.style.transitionDelay = `${
        //         revealTime + revealOffset
        //     }s`;
        // }
    },

    setSubMenuItem(currentMegaMenu, setButtonsTransition = false) {
        // Find visible mega menu items and set transition delay
        const children = [
            ...currentMegaMenu.querySelectorAll('.sub-menu-text, li'),
        ];
        const visibleChildren = children.filter((el) => {
            const top = el.offsetTop;
            const height = el.offsetHeight;
            const currentScroll = currentMegaMenu.scrollTop;
            const currentHeight = currentMegaMenu.offsetHeight;

            return (
                top >= currentScroll - 50 &&
                top + height <= currentHeight + currentScroll + 50
            );
        });
        this.setTranistionDelay(visibleChildren, setButtonsTransition);
    },

    openNav() {
        // If buttons bar transition was manipulated updated it
        // eslint-disable-next-line sonarjs/no-duplicate-string
        if (
            mobileMenu.mobileHeader.classList.contains(
                'change-btn-transition'
            ) &&
            !mobileMenu.mobileHeader.classList.contains('second')
        ) {
            mobileMenu.setTranistionDelay(mobileMenu.mainLinks, true);
            mobileMenu.mobileHeader.classList.remove('change-btn-transition');
        }

        mobileMenu.mobileHeader.classList.add('open');

        mobileMenu.mainLinks.forEach((item) => item.classList.add('revealed'));

        mobileMenu.setmobileHeaderHeight();
        ScreenLock.lock();
    },

    closeNav() {
        mobileMenu.mobileHeader.classList.remove('open');

        mobileMenu.mainLinks.forEach((item) =>
            item.classList.remove('revealed')
        );

        // If Mega Menu is open update visible items and set transition delay
        if (mobileMenu.mobileHeader.classList.contains('second')) {
            const currentMegaMenu = document.querySelector(
                '.main-nav-mobile .mega-menu-wrapper.active'
            );
            mobileMenu.setSubMenuItem(currentMegaMenu, true);
            mobileMenu.mobileHeader.classList.add('change-btn-transition');
        }

        ScreenLock.unlock();
    },

    setmobileHeaderHeight() {
        if (
            breakpoints.desktopMin.matches ||
            (typeof this.mobileHeader === 'undefined' &&
                this.mobileHeader === null)
        ) {
            return;
        }
        this.mobileHeader.style.height = `${window.innerHeight}px`;
    },

    showSubMenu(e) {
        e.preventDefault();
        // Find current Mega Menu and set transition to visible elements
        const currentMegaMenu = this.nextElementSibling;
        mobileMenu.setSubMenuItem(currentMegaMenu);

        // Open Mega Menu
        mobileMenu.mobileNav.classList.add('active');
        mobileMenu.mobileNav.classList.add('visible');
        mobileMenu.mobileHeader.classList.add('second');
        currentMegaMenu.classList.add('active');

        // Set Mega Menu Parent Link Attributes
        mobileMenu.mobileHeaderLink.textContent = this.textContent;
        mobileMenu.mobileHeaderLink.href = this.href;
        mobileMenu.mobileHeaderLink.setAttribute = this.getAttribute('target');
    },

    closeSubMenu() {
        // Find current Mega Menu and set transition to visible elements
        const currentMegaMenu = document.querySelector(
            '.main-nav-mobile .mega-menu-wrapper.active'
        );
        mobileMenu.setSubMenuItem(currentMegaMenu);

        // Close current Mega Menu
        currentMegaMenu.classList.remove('active');
        mobileMenu.mobileNav.classList.remove('active');
        mobileMenu.mobileNav.classList.remove('visible');
        mobileMenu.mobileHeader.classList.remove('second');
    },

    resize() {
        const condition = this.mobileHeader.classList.contains('open');
        if (!breakpoints.desktopMin.matches) {
            condition && this.setmobileHeaderHeight();
        } else {
            condition && this.closeNav();
        }
    },

    hideOutsideClick(e) {
        let condition =
            this.mobileHeader.classList.contains('open') &&
            !this.mobileHeader.contains(e.target);
        if (this.searchSideBar) {
            condition =
                this.mobileHeader.classList.contains('open') &&
                !this.mobileHeader.contains(e.target) &&
                !this.searchSideBar.classList.contains('open');
        }
        if (condition) {
            this.closeNav();
        }
    },

    init() {
        this.openBtn.addEventListener('click', this.openNav);
        this.closeBtn.addEventListener('click', this.closeNav);

        if (this.mainLinks.length > 0) {
            this.setTranistionDelay(this.mainLinks, true);
        }

        if (this.parentLinks.length > 0) {
            this.parentLinks.forEach((item) => {
                item.addEventListener('click', this.showSubMenu);
            });

            this.subMenuBack.forEach((item) => {
                item.addEventListener('click', this.closeSubMenu);
            });
        }        
    },
};

export default mobileMenu;
