<?php
/**
 * Block with content slider
 *
 * @package WordPress
 * @subpackage ATLAS
 * @since ATLAS 1.0
 */
$block_object = new Block( $block );

$slider_style = get_field('slider_style');

loadAcfBlockPreviewImage(__DIR__);

if ( have_rows('slider_row') ) :
    $name = $block_object->block_name();
    $slider_class = 'block-slider__wrapper block-slider__wrapper--' . $slider_style;
    $layout_counter = $block['id'];
?>
<section class="block-slider">
    <?php loadStyles(__DIR__, $name); ?>
    <?php loadStylesComponents('sliders'); ?>
    <?php loadStylesThird('splide'); ?>
    <div class="block-slider__container">
        <div class="<?php echo $slider_class; ?>" data-slider="<?php echo $layout_counter; ?>">
        <?php
        while ( have_rows('slider_row') ) : the_row() ;
            $slide_img = wp_get_attachment_image(get_sub_field('image'), 'full', false, 'data-object-fit');

            $content = get_sub_field('content');
            $primary_button = get_sub_field('primary_button');
            $secondary_button = get_sub_field('secondary_button');

            $single_class = "single-slide single-slide--$slider_style";
            $content_row = 'row single-slide__content-row';

            $bg_html = '';

            if ( $slider_style === 'full-width' ) {
                $content_box_background = get_sub_field('content_box_background');
                $content_position = get_sub_field('content_position');

                $content_row .= " single-slide__content-row--$content_position";
                $content_row .= $content_box_background ? ' single-slide--content-bg' : '';
            } else {
                $image_position = get_sub_field('image_position');
                $single_class .= " single-slide--image-$image_position";
                if ($image_position === 'left') {
                    $content_row .= " single-slide__content-row--right";
                }
            }

            if ( !empty($slide_img) ) :
        ?>
            <div class="<?php echo $single_class; ?>">
                <div class="single-slide__wrapper">
                    <div class="single-slide__bg"><?php 
                        echo $slide_img;
                    ?></div>
                    <div class="single-slide__content-wrapper">
                        <div class="container single-slide__content-container">
                            <div class="<?php echo $content_row; ?>">
                                <div class="single-slide__content">
                                    <?php echo $content; ?>
                                <?php if ( !empty($primary_button) || !empty($secondary_button) ) : ?>
                                    <div class="single-slide__buttons">
                                        <div data-styles-id="core-button"></div>
                                    <?php 
                                    if (!empty($primary_button)) :
                                        $link = $primary_button;
                                        $link_url = $link['url'];
                                        $link_title = $link['title'];
                                        $link_target = $link['target'] ? $link['target'] : '_self';
                                    ?>
                                        <div class="wp-block-button"><a class="wp-block-button__link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a></div>
                                    <?php endif; ?>
                                    <?php 
                                    if (!empty($secondary_button)) :
                                        $link = $secondary_button;
                                        $link_url = $link['url'];
                                        $link_title = $link['title'];
                                        $link_target = $link['target'] ? $link['target'] : '_self';
                                    ?>
                                        <div class="wp-block-button is-style-link-only is-style-link-only-icon"><a class="wp-block-button__link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a></div>
                                    <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php
            endif;
        endwhile;
        ?>
        </div>
    </div>
</section>
<?php
endif;