<?php 
/**
* Disable Gutenberg Autosave
*
* @package WordPress
* @subpackage ATLAS
* @since ATLAS 1.0
*/

remove_filter( 'admin_head', 'wp_check_widget_editor_deps' );