<?php
add_filter( 'gform_init_scripts_footer', '__return_true' );
add_filter( 'gform_footer_init_scripts_filter', 'add_gravity_styles', 10, 3 );

function add_gravity_styles($form_string, $form, $current_page) {
	$name = 'gravity-forms';
	$form_string .= loadStyles(__DIR__, $name);
	return $form_string;
}

function custom_block_registration_gravity_forms() {

    if( is_admin() ) {
        wp_enqueue_style(
            'custom/gravity-forms',
            get_template_directory_uri() . '/parts/blocks/gravity-forms/style.css',
            array( 'wp-edit-blocks' )
        );
    }
}
add_action( 'enqueue_block_editor_assets', 'custom_block_registration_gravity_forms' );