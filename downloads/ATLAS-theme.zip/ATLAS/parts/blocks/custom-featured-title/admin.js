const { InnerBlocks, InspectorControls, MediaUpload, MediaUploadCheck } = wp.blockEditor;
const { PanelBody, FocalPointPicker, Button, ToggleControl, TextControl, PanelRow, SelectControl } = wp.components;
const { registerBlockType } = wp.blocks;
const { __ } = wp.i18n;

const headingName = 'core/paragraph';
const buttonName  = 'core/button';
const customClass = 'featured-title';

const generateStyle = attributes => {
    const { focalPoint, url, bgRepeat } = attributes;
    const attrObj = {};

    if (url) {
        attrObj.style = {};
        attrObj.style.backgroundImage = `url(${ url })`;
        attrObj.style.backgroundPosition = `${ focalPoint.x * 100 }% ${ focalPoint.y * 100 }%`;
        if ( ! bgRepeat ) {
            attrObj.style.backgroundRepeat = 'no-repeat';
            attrObj.style.backgroundSize = 'cover';
        }
    }

    return attrObj;
}

const renderTabletBg = attributes => {
    const { focalPointTablet, urlTablet, bgRepeat } = attributes;
    const attrObj = {};

    if (urlTablet) {
        attrObj.style = {};
        attrObj.style.backgroundImage = `url(${ urlTablet })`;
        attrObj.style.backgroundPosition = `${ focalPointTablet.x * 100 }% ${ focalPointTablet.y * 100 }%`;
        
        if ( ! bgRepeat ) {
            attrObj.style.backgroundRepeat = 'no-repeat';
            attrObj.style.backgroundSize = 'cover';
        }
        
        return (
            <div className={ `${customClass}__bg ${customClass}__bg--tablet` } {...attrObj}/>
        );
    }
}

const renderMobileBg = attributes => {
    const { focalPointMobile, urlMobile, bgRepeat } = attributes;
    const attrObj = {};

    if (urlMobile) {
        attrObj.style = {};
        attrObj.style.backgroundImage = `url(${ urlMobile })`;
        attrObj.style.backgroundPosition = `${ focalPointMobile.x * 100 }% ${ focalPointMobile.y * 100 }%`;
        
        if ( ! bgRepeat ) {
            attrObj.style.backgroundRepeat = 'no-repeat';
            attrObj.style.backgroundSize = 'cover';
        }
        
        return (
            <div className={ `${customClass}__bg ${customClass}__bg--mobile` } {...attrObj}/>
        );
    }
}

const alignClass = attributes => {
    const { verticalAlign, horizontalAlign } = attributes;
    let addClass = verticalAlign ? ` align-vertical--${ verticalAlign }` : '';

    addClass += horizontalAlign ? ` align-horizontal--${ horizontalAlign }` : '';

    return addClass;
}

registerBlockType( 'custom/featured-title', {
    title: 'Featured Title',
    icon: 'welcome-write-blog',
    category: 'custom_blocks',
    attributes: {
        // height: {
        //     type: 'string',
        //     default: '500',
        // },
        // heightTablet: {
        //     type: 'string',
        //     default: '350',
        // },
        // heightMobile: {
        //     type: 'string',
        //     default: '250',
        // },
        verticalAlign: {
            type: 'string',
            default: 'top',
        },
        horizontalAlign: {
            type: 'string',
            default: 'left',
        },
        bgRepeat: {
            type: 'bool',
            default: false,
        },
        url:  {
            type: 'string',
            default: '',
        },
        focalPoint: {
            type: 'object',
            default: {
                x: 0.5,
                y: 0.5,
            }
        },
        urlTablet:  {
            type: 'string',
            default: '',
        },
        focalPointTablet: {
            type: 'object',
            default: {
                x: 0.5,
                y: 0.5,
            }
        },
        urlMobile:  {
            type: 'string',
            default: '',
        },
        focalPointMobile: {
            type: 'object',
            default: {
                x: 0.5,
                y: 0.5,
            }
        },
    },
    example: {
        attributes: {
            url: 'https://via.placeholder.com/350x150/f1f5f8',
        },
		innerBlocks: [
			{
				name: headingName,
				attributes: {
					content: __( 'Featured Title' ),
					align: 'left',
				},
			},
            {
				name: buttonName,
				attributes: {
					content: __( 'Button' ),
					align: 'left',
				},
			}
		],
    },
    edit: ( { attributes, className, setAttributes } ) => {

        const ALLOWED_BLOCKS = [ headingName, buttonName ];

        const { /* height, heightTablet, heightMobile, */ verticalAlign, horizontalAlign, focalPoint, url, focalPointTablet, urlTablet, focalPointMobile, urlMobile, bgRepeat } = attributes;

        const ALLOWED_MEDIA_TYPES = [ 'image' ];

        // Desktop Elements
        const getImageButton = (openEvent) => {
            if( url ) {
                return (
                <img 
                    src={ url }
                    onClick={ openEvent }
                    className="image"
                    alt="placeholder"
                />
                );
            }
            else {
                return (
                <div className="button-container">
                    <Button 
                    onClick={ openEvent }
                    className="button button-large"
                    >
                    {__('Pick an image')}
                    </Button>
                </div>
                );
            }
        };

        const renderClear = () => {
            if ( url ) {
                return (
                    <Button 
                    onClick={ () => { setAttributes({ url: undefined }); } }
                    className="button button-large"
                    >{__('Clear Image')}</Button>
                )
            }
        }

        const renderFocal = () => {
            if ( url ) {
                return (
                    <FocalPointPicker
                        label={ __( 'Focal point picker' ) }
                        url={ url }
                        value={ focalPoint }
                        onChange={ ( newFocalPoint ) =>
                            setAttributes( {
                                focalPoint: newFocalPoint,
                            } )
                        }
                    />
                )
            }
        }
        // Tablet Elements
        const getImageButtonTablet = (openEvent) => {
            if( urlTablet ) {
                return (
                <img 
                    src={ urlTablet }
                    onClick={ openEvent }
                    className="image"
                    alt="placeholder"
                />
                );
            }
            else {
                return (
                <div className="button-container">
                    <Button 
                    onClick={ openEvent }
                    className="button button-large"
                    >
                    {__('Pick an Tablet image')}
                    </Button>
                </div>
                );
            }
        };

        const renderClearTablet = () => {
            if ( urlTablet ) {
                return (
                    <Button 
                    onClick={ () => { setAttributes({ urlTablet: undefined }); } }
                    className="button button-large"
                    >{__('Clear Tablet Image')}</Button>
                )
            }
        }

        const renderFocalTablet = () => {
            if ( urlTablet ) {
                return (
                    <FocalPointPicker
                        label={ __( 'Focal point tablet picker' ) }
                        url={ urlTablet }
                        value={ focalPointTablet }
                        onChange={ ( newFocalPoint ) =>
                            setAttributes( {
                                focalPointTablet: newFocalPoint,
                            } )
                        }
                    />
                )
            }
        }

        // Mobile Elements
        const getImageButtonMobile = (openEvent) => {
            if( urlMobile ) {
                return (
                <img 
                    src={ urlMobile }
                    onClick={ openEvent }
                    className="image"
                    alt="placeholder"
                />
                );
            }
            else {
                return (
                <div className="button-container">
                    <Button 
                    onClick={ openEvent }
                    className="button button-large"
                    >
                    {__('Pick an mobile image')}
                    </Button>
                </div>
                );
            }
        };

        const renderClearMobile = () => {
            if ( urlMobile ) {
                return (
                    <Button 
                    onClick={ () => { setAttributes({ urlMobile: undefined }); } }
                    className="button button-large"
                    >{__('Clear Mobile Image')}</Button>
                )
            }
        }

        const renderFocalMobile = () => {
            if ( urlMobile ) {
                return (
                    <FocalPointPicker
                        label={ __( 'Focal point mobile picker' ) }
                        url={ urlMobile }
                        value={ focalPointMobile }
                        onChange={ ( newFocalPoint ) =>
                            setAttributes( {
                                focalPointMobile: newFocalPoint,
                            } )
                        }
                    />
                )
            }
        }
        
        return (
            <>
			<InspectorControls>
				<PanelBody title={ __( 'Settings' ) }>
                    {/* <TextControl
                        label="Height"
                        value={ height }
                        onChange={ ( newHeight ) => setAttributes( { height: newHeight } )  }
                    /> */}
                    <SelectControl
                        label="Vertical Align"
                        value={ verticalAlign }
                        options={ [
                            { label: 'Top', value: 'top' },
                            { label: 'Center', value: 'center' },
                            { label: 'Bottom', value: 'bottom' },
                        ] }
                        onChange={ ( newVerticalAlign ) => { setAttributes( { verticalAlign: newVerticalAlign } ) } }
                    />
                    <SelectControl
                        label="Horizontal Align"
                        value={ horizontalAlign }
                        options={ [
                            { label: 'Left', value: 'left' },
                            { label: 'Center', value: 'center' },
                            { label: 'Right', value: 'right' },
                        ] }
                        onChange={ ( newHorizontalAlign ) => { setAttributes( { horizontalAlign: newHorizontalAlign } ) } }
                    />
                    <ToggleControl
						label={ __( 'Background Repeat' ) }
						checked={ !! bgRepeat }
						onChange={ () =>
							setAttributes( { bgRepeat: ! bgRepeat } )
						}
						help={
							bgRepeat
								? 'Repeat background'
								: 'Toggle to repeat background'
						}
					/>
					<PanelRow>
                        <p>{ __( 'Desktop Image') }</p>
                    </PanelRow>
                    <MediaUploadCheck>
                        <MediaUpload
                        onSelect={ ( media ) => { setAttributes({ url: media.url }); } }
                        allowedTypes={ ALLOWED_MEDIA_TYPES }
                        
                        render={ ( { open } ) => getImageButton(open) }
                        />
                    </MediaUploadCheck>
                    
                    { renderClear() }

                    { renderFocal() }

					<PanelRow>
                        <p>{ __( 'Tablet Image') }</p>
                    </PanelRow>                
                    <MediaUploadCheck>
                        <MediaUpload
                        onSelect={ ( media ) => { setAttributes({ urlTablet: media.url }); } }
                        allowedTypes={ ALLOWED_MEDIA_TYPES }
                        
                        render={ ( { open } ) => getImageButtonTablet(open) }
                        />
                    </MediaUploadCheck>
                    
                    { renderClearTablet() }

                    { renderFocalTablet() }

					<PanelRow>
                        <p>{ __( 'Mobile Image') }</p>
                    </PanelRow>
                    <MediaUploadCheck>
                        <MediaUpload
                        onSelect={ ( media ) => { setAttributes({ urlMobile: media.url }); } }
                        allowedTypes={ ALLOWED_MEDIA_TYPES }
                        
                        render={ ( { open } ) => getImageButtonMobile(open) }
                        />
                    </MediaUploadCheck>
                    
                    { renderClearMobile() }

                    { renderFocalMobile() }
        
                </PanelBody>
            </InspectorControls>
            <div className={ `${customClass} ${className} ${alignClass(attributes)}` }>
                { renderMobileBg(attributes) }
                { renderTabletBg(attributes) }
                <div className={ `${customClass}__bg`} {...generateStyle(attributes)}/>
                <div className={ `${customClass}__body` }>
                <InnerBlocks
                    //allowedBlocks={ ALLOWED_BLOCKS }
                    //templateLock='all'
                    renderAppender={ () => (
                        <InnerBlocks.ButtonBlockAppender />
                    ) }
                    template={[
                        [
                            headingName,
                            { placeholder: 'Enter featured title...' }
                        ],
                    ]}
                />
                </div>
            </div>
            </>
        );
    },
    save: ( { attributes } ) => {
        
        return (
            <div className={ `${customClass} ${alignClass(attributes)}` }>
                <div data-styles-id="custom-featured-title" />
                { renderMobileBg(attributes) }
                { renderTabletBg(attributes) }
                <div className={ `${customClass}__bg` } {...generateStyle(attributes)}/>
                <div className={ `${customClass}__body` }>
                    <div className="container">
                        <InnerBlocks.Content />
                    </div>
                </div>
            </div>
        );
    },
} );