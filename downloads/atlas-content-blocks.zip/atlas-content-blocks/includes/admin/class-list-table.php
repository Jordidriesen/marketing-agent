<?php
/**
 * Extra columns on the content block list screen.
 *
 * @package AtlasContentBlocks
 */

defined( 'ABSPATH' ) || exit;

class Atlas_CB_List_Table {

	public static function init() {
		add_filter( 'manage_' . ATLAS_CB_POST_TYPE . '_posts_columns', array( __CLASS__, 'columns' ) );
		add_action( 'manage_' . ATLAS_CB_POST_TYPE . '_posts_custom_column', array( __CLASS__, 'column' ), 10, 2 );
	}

	/**
	 * @param array $columns Columns.
	 *
	 * @return array
	 */
	public static function columns( $columns ) {
		$date = $columns['date'] ?? null;
		unset( $columns['date'] );

		$columns['atlas_cb_type']       = __( 'Type', 'atlas-content-blocks' );
		$columns['atlas_cb_placement']  = __( 'Placement / trigger', 'atlas-content-blocks' );
		$columns['atlas_cb_conditions'] = __( 'Shown on', 'atlas-content-blocks' );
		$columns['atlas_cb_shortcode']  = __( 'Shortcode', 'atlas-content-blocks' );

		if ( $date ) {
			$columns['date'] = $date;
		}

		return $columns;
	}

	/**
	 * @param string $column  Column key.
	 * @param int    $post_id Block ID.
	 */
	public static function column( $column, $post_id ) {
		$s = Atlas_CB_Settings::get( $post_id );

		switch ( $column ) {
			case 'atlas_cb_type':
				echo 'popup' === $s['type'] ? esc_html__( 'Popup', 'atlas-content-blocks' ) : esc_html__( 'Content block', 'atlas-content-blocks' );
				break;

			case 'atlas_cb_placement':
				echo esc_html( self::placement( $s ) );
				break;

			case 'atlas_cb_conditions':
				echo esc_html( self::conditions( $s ) );
				break;

			case 'atlas_cb_shortcode':
				printf( '<code>[atlas_content_block id="%d"]</code>', (int) $post_id );
				break;
		}
	}

	/**
	 * @param array $s Settings.
	 *
	 * @return string
	 */
	private static function placement( array $s ) {
		if ( 'popup' === $s['type'] ) {
			$triggers = array(
				'click'  => __( 'On click', 'atlas-content-blocks' ),
				/* translators: %d: seconds */
				'load'   => sprintf( __( 'After %d s', 'atlas-content-blocks' ), $s['popup']['delay'] ),
				/* translators: %d: percentage */
				'scroll' => sprintf( __( 'At %d%% scrolled', 'atlas-content-blocks' ), $s['popup']['scroll'] ),
				'exit'   => __( 'On exit intent', 'atlas-content-blocks' ),
			);
			return $triggers[ $s['popup']['trigger'] ] ?? '';
		}

		if ( 'custom' === $s['location'] ) {
			return $s['custom_hook'];
		}

		$locations = Atlas_CB_Settings::locations();
		return $locations[ $s['location'] ] ?? $s['location'];
	}

	/**
	 * @param array $s Settings.
	 *
	 * @return string
	 */
	private static function conditions( array $s ) {
		if ( 'hook' === $s['type'] && 'manual' === $s['location'] ) {
			return __( 'Where placed by hand', 'atlas-content-blocks' );
		}
		if ( ! $s['include'] ) {
			return __( 'Nowhere (no rules)', 'atlas-content-blocks' );
		}

		$labels = array();
		foreach ( Atlas_CB_Settings::rule_choices() as $group ) {
			$labels += $group;
		}

		$describe = function ( $rule ) use ( $labels ) {
			$label = $labels[ $rule['rule'] ] ?? $rule['rule'];
			return '' !== $rule['value'] ? $label . ': ' . $rule['value'] : $label;
		};

		$text = implode( ', ', array_map( $describe, $s['include'] ) );

		if ( $s['exclude'] ) {
			/* translators: %s: list of excluded rules */
			$text .= ' ' . sprintf( __( '(except %s)', 'atlas-content-blocks' ), implode( ', ', array_map( $describe, $s['exclude'] ) ) );
		}

		if ( $s['start'] || $s['end'] ) {
			$text .= ' · ' . __( 'scheduled', 'atlas-content-blocks' );
		}

		return $text;
	}
}
