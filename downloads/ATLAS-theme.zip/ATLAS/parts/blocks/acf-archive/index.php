<?php
/**
 * Block with archive slider
 *
 * @package WordPress
 * @subpackage ATLAS
 * @since ATLAS 1.0
 */
$block_object = new Block( $block );

loadAcfBlockPreviewImage(__DIR__);

$latest = true;
$archive = get_field('slider_archive');
$buttons_text = get_field('buttons_text');

if ( $latest ) {
    $num = 6;
    $args = array(
        'post_type'           => 'post',
        'post_status'         => 'publish',
        'posts_per_page'      => $num,
        'facetwp'             => true,
    );
    $args['paged'] = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;

    $the_query = new WP_Query( $args );
}

if ( $the_query->have_posts() ) :
    $name = $block_object->block_name();
    $layout_counter = $block['id'];
?>
<section class="block-archive">
    <div class="block-archive__container">
        <div class="block-archive__wrapper">
        <?php
            while ( $the_query->have_posts() ) { $the_query->the_post();
                $id = get_the_ID();
                // $id = apply_filters( 'wpml_object_id', $id, 'post', TRUE  );
                get_theme_part('components/single-news/index', ['id' => $id, 'btn_txt'=> $buttons_text]);
            }
        ?>
        </div>
            <div class="block-archive__pagination">
            <?php
                
                 echo paginate_links( array(
                    'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                    'total'        => $the_query->max_num_pages,
                    'current'      => max( 1, get_query_var( 'paged' ) ),
                    'format'       => '?paged=%#%',
                    'show_all'     => false,
                    'type'         => 'plain',
                    'end_size'     => 2,
                    'mid_size'     => 1,
                    'prev_next'    => true,
                    'prev_text'    => sprintf( '<i></i> %1$s', __( '<', 'ATLAS' ) ),
                    'next_text'    => sprintf( '%1$s <i></i>', __( '>', 'ATLAS' ) ),
                    'add_args'     => false,
                    'add_fragment' => '',
                ) );
            
            ?>
            </div>
            <?php
                wp_reset_postdata();
            ?>
    </div>
</section>
<?php
endif;