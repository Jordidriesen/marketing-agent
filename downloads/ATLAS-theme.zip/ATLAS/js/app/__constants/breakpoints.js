/* eslint-disable import/no-default-export */
const breakpoints = {
    desktopMin: window.matchMedia('screen and (min-width: 1200px)'),
}

export default breakpoints;
