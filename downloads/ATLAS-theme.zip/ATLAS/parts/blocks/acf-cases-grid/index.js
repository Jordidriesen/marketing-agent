import { Slider } from 'lib/sliders';

const setCasesGrid = () => {
    [...document.querySelectorAll(".block-cases-grid__wrapper")].forEach( block => {
        const speed = block.getAttribute("data-speed");
        const transition = block.getAttribute("data-transition");
        const auto = block.getAttribute("data-autoplay");

        const transitionTime = transition || 400;
        const autoplaySpeed = speed || 4000;
        const autoplay = !!auto;

        return new Slider({
                elem: block,
                fade: false,
                num: 1,
                tabNum: 1,
                mobNum: 1,
                infinite: false,
                adaptiveHeight: false,
                dots: true,
                arrows: false,
                slideSpeed: transitionTime,
                autoplaySpeed,
                autoplay,
            });
        }
    );

};

const initCasesGrid = () => {
    if (window.innerWidth <= 1024) {
        setCasesGrid();
    }
};


initCasesGrid();

if ( window.acf ) {
    window.acf.addAction( 'render_block_preview/type=news', initCasesGrid);
}
