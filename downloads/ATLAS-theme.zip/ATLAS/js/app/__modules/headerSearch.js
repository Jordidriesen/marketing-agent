import mobileMenu from '../__header/mobileMenu';

class HeaderSearch {
    constructor() {
        this.body = document.querySelector('#page');
        this.trigger = document.querySelector('#search-icon');
        this.close = document.querySelector('#close-icon');
        this.searchWrapper = [...document.querySelectorAll('.main-header__search')];
        this.active = false;
    }

    init() {
        this.registerListeners();
    }

    registerListeners() {
        if (this.trigger) {
            this.trigger.addEventListener('click', this.toggleList.bind(this));
        }

        if (this.close) {
            this.close.addEventListener('click', this.toggleList.bind(this));
        }
    }

    toggleList() {
        if (this.active) {
            this.hideSearch();
        } else {
            this.showSearch();
        }
    }

    hideSearch() {
        this.active = false;
        this.searchWrapper.forEach(el => el.classList.remove('show'));
        if (this.body) {
            this.body.classList.remove('searchIsOpen');
        }
    }

    showSearch() {
        let timeout = 0;

        if (mobileMenu.menuOpened) {
            mobileMenu.closeNav();
            timeout = mobileMenu.speedMenu;
        }

        setTimeout(() => {
            this.active = true;
            this.searchWrapper.forEach(el => el.classList.add('show'));
            if (this.body) {
                this.body.classList.add('searchIsOpen');
            }
        }, timeout);
    }

    
    hideOutsideClick(e) {
        const clicked = e.target;
        const shown = this.searchWrapper.length > 0 && this.searchWrapper[0].classList.contains('show');

        if (this.trigger && shown && !this.trigger.contains(clicked)) {
            
            if (!this.searchWrapper.some(el => el.contains(clicked))) {
                this.toggleList();
            }
        }
    }
}

export default new HeaderSearch();
