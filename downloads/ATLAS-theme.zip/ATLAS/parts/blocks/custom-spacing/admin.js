const { InspectorControls } = wp.blockEditor;
const { registerBlockType } = wp.blocks;
const { PanelBody, SelectControl } = wp.components;
const { __ } = wp.i18n;

const generateClass = ( attributes ) => {
	const {spacing, tablet, smallDesktop, desktop} = attributes;
	let customClass = 'spacing-element';

	customClass += spacing &&  ` spacing-mobile--${spacing}`;
	customClass += tablet &&  ` spacing-tablet--${tablet}`;
	customClass += smallDesktop &&  ` spacing-small-desktop--${smallDesktop}`;
	customClass += desktop &&  ` spacing-desktop--${desktop}`;

	return customClass;
}

registerBlockType( 'custom/spacing', {
    title: 'Spacing',
    icon: 'image-flip-vertical',
    category: 'custom_blocks',
    attributes: {
        spacing:  {
            type: 'string',
            default: 'small',
		},
        tablet:  {
            type: 'string',
            default: 'small',
		},
        smallDesktop:  {
            type: 'string',
            default: 'small',
		},
        desktop:  {
            type: 'string',
            default: 'small',
		},
		
	},
    edit: ( props ) => {
		const { attributes, setAttributes} = props;
		const {spacing, tablet, smallDesktop, desktop} = attributes;

        return (
            <>
			<InspectorControls>
				<PanelBody 
					title="Settings" 
				>
					<SelectControl
						label="Mobile"
						value={ spacing }
						options={ [
							{ label: 'Small', value: 'small' },
							{ label: 'Medium', value: 'medium' },
							{ label: 'Large', value: 'large' },
							{ label: 'None', value: 'none' },
						] }
						onChange={ ( size ) => { setAttributes( { spacing: size } ); } }
					/>
					<SelectControl
						label="Tablet"
						value={ tablet }
						options={ [
							{ label: 'Small', value: 'small' },
							{ label: 'Medium', value: 'medium' },
							{ label: 'Large', value: 'large' },
							{ label: 'None', value: 'none' },
						] }
						onChange={ ( size ) => { setAttributes( { tablet: size } ); } }
					/>
					<SelectControl
						label="Small Desktop"
						value={ smallDesktop }
						options={ [
							{ label: 'Small', value: 'small' },
							{ label: 'Medium', value: 'medium' },
							{ label: 'Large', value: 'large' },
							{ label: 'None', value: 'none' },
						] }
						onChange={ ( size ) => { setAttributes( { smallDesktop: size } ); } }
					/>
					<SelectControl
						label="Desktop"
						value={ desktop }
						options={ [
							{ label: 'Small', value: 'small' },
							{ label: 'Medium', value: 'medium' },
							{ label: 'Large', value: 'large' },
							{ label: 'None', value: 'none' },
						] }
						onChange={ ( size ) => { setAttributes( { desktop: size } ); } }
					/>

				</PanelBody>
			</InspectorControls>
			<div className={ generateClass(attributes) } />
            </>
        );
    },
    save: ( { attributes } ) => {
        return (
			<div className={ generateClass(attributes) } />
        );
    },
} );