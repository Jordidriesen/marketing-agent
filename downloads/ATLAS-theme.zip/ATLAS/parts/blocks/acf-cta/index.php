<?php
/**
 * Block Name: CTA
 *
 * This is the template that displays the cta block
 * 
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   int|string $post_id The post ID this block is saved to.
 */

$block_object = new Block( $block );
$name = $block_object->block_name();
$block_id = $block['id'] ?? '';


// BLOCK CLASSES
$classes = '';
if( !empty($block['className']) ) {
    $classes .= sprintf( ' %s', esc_attr($block['className']) );
}
if( !empty($block['align']) ) {
    $classes .= sprintf( ' align%s', esc_attr($block['align']) );
}
if( !empty($block['align_text']) ) {
    $classes .= sprintf( ' align-text-%s', esc_attr($block['align_text']) );
}
if( !empty($block['align_content']) ) {
    $classes .= sprintf( ' is-position-%s', esc_attr(str_replace(' ','-',$block['align_content'])) );
}


loadAcfBlockPreviewImage(__DIR__);

// BACKGROUND
$bg_img_id = get_field('cta_background_image');
$bg_img = wp_get_attachment_image($bg_img_id, 'full', false, 'data-object-fit');
$enable_overlay = get_field('cta_enable_background_overlay');
$image_overlay_type = get_field('image_overlay_type');
$image_overlay_color = get_field('image_overlay_color');
$image_overlay_gradient = get_field('image_overlay_gradient');
$image_overlay_opacity = get_field('image_overlay_opacity');

$video_bool = get_field('cta_show_video');

// CONTENT BOX
// $title = get_field('cta_title');
// $subtitle = get_field('cta_subtitle');
// $content = get_field('cta_content');
// $button = get_field('cta_button');
// $box_position = get_field('cta_box_position');
$disable_box_background = get_field('cta_disable_box_background');
$box_background_type = get_field('box_background_type');
$box_background_color = get_field('box_background_color');
$box_background_gradient = get_field('box_background_gradient');
$box_background_opacity = get_field('box_background_opacity');

// SETTINGS
$margin_top = get_field('cta_margin_top');
$margin_bottom = get_field('cta_margin_bottom');


$class = 'block-cta';
$wrapper_class = 'block-cta__wrapper';
$box_class = 'block-cta__box';

$enable_overlay && $class .= ' block-cta--overlay';
$margin_top && $class .= ' margin-top';
$margin_bottom && $class .= ' margin-bottom';
//$box_position && $wrapper_class .= ' align-' . $box_position;
$disable_box_background && $box_class .= ' block-cta__box--no-bg';

if ( $video_bool ) {
    $class .= ' block-cta--video';
	$video_background     = get_field('video_background');
	$video_background_url = get_field('video_background', false, false);
}
?>
<section id="<?php echo $block_id; ?>" class="<?php echo $class; ?> <?php echo esc_attr($classes); ?>">
	<?php loadStyles(__DIR__, $name); ?>
	
		<style>
			<?php if($enable_overlay) : ?>
			<?php echo '#'.$block_id; ?>.block-cta--overlay:before {
				<?php if ($image_overlay_type == 'gradient') : ?>
					background: linear-gradient(<?php echo $image_overlay_gradient['angle'] ?? ''; ?>deg, <?php echo $image_overlay_gradient['from'] ?? ''; ?>, <?php echo $image_overlay_gradient['to'] ?? ''; ?>);
				<?php endif; ?>
				<?php if ($image_overlay_type == 'color') : ?>
					background-color: <?php echo $image_overlay_color; ?>;
				<?php endif; ?>
				opacity: <?php echo $image_overlay_opacity; ?>;
			}
			<?php endif; ?>
			<?php echo '#'.$block_id; ?>  .block-cta__box {
				<?php if ($box_background_type == 'gradient') : ?>
					<?php
					$box_background_gradient_angle = $box_background_gradient['angle'] ??'';
					$box_background_gradient_from = isset($box_background_gradient['from']) ? hex2rgba($box_background_gradient['from'],$box_background_opacity)  : '';
					$box_background_gradient_to = isset($box_background_gradient['to']) ? hex2rgba($box_background_gradient['to'],$box_background_opacity)  : '';
					?>
					<?php if($box_background_gradient_angle && $box_background_gradient_from && $box_background_gradient_to ) : ?>
						background: linear-gradient(<?php echo $box_background_gradient_angle; ?>deg, <?php echo $box_background_gradient_from; ?>, <?php echo $box_background_gradient_to; ?>);
					<?php endif; ?>
				<?php endif; ?>
				<?php if ($box_background_type == 'color') : ?>
					background-color: <?php echo hex2rgba($box_background_color,$box_background_opacity); ?>;
				<?php endif; ?>
			}
		</style>
	
<?php if (!empty($bg_img) && !$video_bool) : ?>
	<div class="block-cta__bg"><?php echo $bg_img; ?></div>
<?php elseif ( $video_bool && ! empty( $video_background ) ) : ?>
	<?php get_theme_part('components/video-background/index', ['video_background' => $video_background, 'video_background_url'=>$video_background_url]); ?>
<?php endif; ?>
	<div class="container block-cta__container">
		<div class="<?php echo $wrapper_class; ?>">
			<div class="<?php echo $box_class; ?>">
				<div class="block-cta__box-wrapper">
					<InnerBlocks />
				</div>
			</div>
		</div>
	</div>
</section>
