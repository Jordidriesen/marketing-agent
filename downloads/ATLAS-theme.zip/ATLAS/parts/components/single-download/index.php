<?php
if ( isset($id) ):
	$img = get_the_post_thumbnail($id,'news-image');
	$title = get_the_title($id);
	$short_desc = get_the_excerpt($id);
	$link_url = get_permalink($id);
	$link_target = isset($link_target) ? $link_target : '_self';
	$link_title = !empty($btn_txt) ? $btn_txt : __('View Download', 'ATLAS');

	//File as Array (url, filename, filesize, subtype, ...)
	$file = get_field('download_file', $id);
	$pages = get_field('download_pages', $id);

	// "12 pages · PDF" — built from whatever information is available
	$meta = [];
	if (!empty($pages)) {
		$meta[] = sprintf(_n('%s page', '%s pages', $pages, 'ATLAS'), $pages);
	}
	if (!empty($file['subtype'])) {
		$meta[] = strtoupper($file['subtype']);
	}

	$download_types = get_the_terms($id, 'download-type');
	$term = ($download_types && !is_wp_error($download_types)) ? $download_types[0] : false;
?>
<div class="single-download-card">
	<?php loadStyles(__DIR__, 'single-download-card'); ?>
	<div class="single-download-card__wrapper">
	<?php if (!empty($img)) : ?>
		<figure class="single-download-card__img">
			<?php if ( $term ) : ?>
			<span class="single-download-card__term"><?php echo esc_html( $term->name ); ?></span>
			<?php endif; ?>

			<?php echo $img; ?>
		</figure>
	<?php endif; ?>
		<div class="single-download-card__content">

			<?php if (!empty($meta)) : ?>
				<div class="single-download-card__meta">
					<span class="single-download-card__meta-text"><?php echo esc_html(implode(' · ', $meta)); ?></span>
				</div>
			<?php endif; ?>
			<h3 class="single-download-card__title" role="heading"><?php echo $title; ?></h3>
			<?php if (!empty($short_desc)) : ?>
				<span class="single-download-card__desc"><?php echo $short_desc; ?></span>
			<?php endif; ?>
			<?php $name = 'core-button';?>
			<?php loadStylesDep('blocks/core-button', $name); ?>
			<div class="wp-block-button is-style-link-only"><a class="wp-block-button__link" href="<?php echo esc_url( $link_url ); ?>" target="<?php echo esc_attr( $link_target ); ?>"><?php echo esc_html( $link_title ); ?></a></div>
		</div>
	</div>
</div>
<?php
endif;
