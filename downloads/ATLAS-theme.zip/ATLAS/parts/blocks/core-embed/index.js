import { fadeOut } from 'lib/slide';

const video = {
    init() {
        document.querySelectorAll('.iframe-wrapper__overlay').forEach((overlay) => {
            overlay.addEventListener('click', this.hideOverlay);
        });

        document.querySelectorAll('.iframe-wrapper iframe').forEach((el) => {
            let srcVideo = el.src;
            el.src = '';
            setTimeout(() => {
                el.src = srcVideo;
            }, 0);
        });
    },
    hideOverlay(e) {
        e.preventDefault();
        const overlay = this;
        const parent = overlay.parentElement.closest('.iframe-wrapper');
        const iframe = parent.querySelector('iframe');

        if (!parent.classList.contains('wistia')) {
            iframe.src += '&autoplay=1&loop=1&rel=0&wmode=transparent';
        } else {
            iframe.src = `https://fast.wistia.net/embed/iframe/${parent.dataset.videoId}?autoplay=1`;
        }

        // Same timing as jQuery's .delay(300).fadeOut()
        setTimeout(() => fadeOut(overlay, 400), 300);
    },
};


video.init();
