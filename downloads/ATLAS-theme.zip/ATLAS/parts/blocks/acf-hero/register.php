<?php
function init_block_hero() {
    if ( ! function_exists( 'acf_register_block' ) ) {
        return;
    }

    acf_register_block( array(
        'name'              => 'hero',
        'title'             => __( 'Heldenbild / Hero', 'ATLAS' ),
        'description'       => __( 'hero', 'ATLAS' ),
        'category'          => 'custom_blocks',
        'icon'              => 'format-image',
        'mode'              => 'auto',
        'keywords'          => array( 'main', 'hero', 'images' ),
        'align'             => 'full',
        'supports'          => array(
			'align' => false,
        ),
		'example'         => [
            'attributes' => [
                'mode' => 'auto',
            ]
        ],
        'render_template'   => get_template_directory() . '/parts/blocks/acf-hero/index.php',
    ));
}

add_action( 'acf/init', 'init_block_hero' );