<?php
if (!function_exists('auto_id_heading2')) {
    function auto_id_heading2( $content ) {
        $content = preg_replace_callback( '/(\<h[2](.*?))\>(.*)(<\/h[2]>)/i', function( $matches ) {
            if ( ! stripos( $matches[0], 'id=' ) ) :
                $text = html_entity_decode($matches[3], ENT_QUOTES, 'UTF-8');
                $text = str_replace(['ä', 'ö', 'ü', 'ß', '&'], ['ae', 'oe', 'ue', 'ss', 'and'], $text);
                $matches[0] = $matches[1] . $matches[2] . ' id="' . sanitize_title_with_dashes( $text, '', 'save' ) . '">' . $matches[3] . $matches[4];
            endif;
            return $matches[0];
        }, $content );

        return $content;
    }
    add_filter( 'the_content', 'auto_id_heading2' );
}

if (!function_exists('generateIndex')) {
    function generateIndex($html) {
        preg_match_all('/<h([2])*[^>]*>(.*?)<\/h[2]>/',$html,$matches);

        $index = "<ol>";
        $prev = 2;

        foreach ($matches[0] as $i => $match){

            $curr = $matches[1][$i];
            $text = strip_tags($matches[2][$i]);
            $text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');
            $slugText = str_replace(['ä', 'ö', 'ü', 'ß', '&'], ['ae', 'oe', 'ue', 'ss', 'and'], $text);
            $slug = strtolower(
                preg_replace(
                    ['/[^a-z0-9\-]+/i', '/-+/'],
                    ['-', '-'],
                    $slugText
                )
            );
            $slug = trim($slug, '-');
            $anchor = '<a name="'.$slug.'">'.$text.'</a>';
            $html = str_replace($text,$anchor,$html);
            
            $prev <= $curr ?: $index .= str_repeat('</ol>',($prev - $curr));
            $prev >= $curr ?: $index .= "<ol>";
            
            $index .= '<li><a href="#'.$slug.'">'.$text.'</a></li>';
            
            $prev = $curr;
        }

        $index .= str_repeat('</ol>', $prev - 1) . "</ol>";

        return ["html" => $html, "index" => $index];
    }
}