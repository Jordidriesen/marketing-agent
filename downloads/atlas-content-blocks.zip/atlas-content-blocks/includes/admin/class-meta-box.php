<?php
/**
 * Settings meta box on the content block edit screen. Locations are rows of
 * grouped selects, the display conditions are edited in a dialog (its fields
 * stay inside the post form) and popup settings sit in collapsible sections.
 *
 * Every checkbox is preceded by a hidden input with value 0, so an unchecked
 * box saves as off rather than falling back to its default.
 *
 * @package AtlasContentBlocks
 */

defined( 'ABSPATH' ) || exit;

class Atlas_CB_Meta_Box {

	const NONCE = 'atlas_cb_settings_nonce';

	public static function init() {
		add_action( 'add_meta_boxes_' . ATLAS_CB_POST_TYPE, array( __CLASS__, 'add' ) );
		add_action( 'save_post_' . ATLAS_CB_POST_TYPE, array( __CLASS__, 'save' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	public static function add() {
		add_meta_box(
			'atlas-cb-settings',
			__( 'Display settings', 'atlas-content-blocks' ),
			array( __CLASS__, 'render' ),
			ATLAS_CB_POST_TYPE,
			'normal',
			'high'
		);
	}

	/**
	 * @param string $hook Admin page hook.
	 */
	public static function assets( $hook ) {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) || ATLAS_CB_POST_TYPE !== get_current_screen()->post_type ) {
			return;
		}
		wp_enqueue_style( 'atlas-cb-admin', ATLAS_CB_URL . 'assets/css/admin.css', array(), ATLAS_CB_VERSION );
		wp_enqueue_script( 'atlas-cb-admin', ATLAS_CB_URL . 'assets/js/admin.js', array(), ATLAS_CB_VERSION, true );
		wp_localize_script( 'atlas-cb-admin', 'atlasCbAdmin', Atlas_CB_Summary::script_strings() );
	}

	/**
	 * A checkbox that always submits a value (0 or 1).
	 *
	 * @param string $name    Field name.
	 * @param mixed  $checked Current value.
	 * @param string $label   Label.
	 */
	private static function checkbox( $name, $checked, $label ) {
		?>
		<label class="atlas-cb-check">
			<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="0">
			<input type="checkbox" name="<?php echo esc_attr( $name ); ?>" value="1" <?php checked( ! empty( $checked ) ); ?>>
			<?php echo esc_html( $label ); ?>
		</label>
		<?php
	}

	/**
	 * A labelled select.
	 *
	 * @param string $id      Field ID.
	 * @param string $name    Field name.
	 * @param string $current Current value.
	 * @param array  $options Value => label.
	 * @param string $label   Label.
	 */
	private static function select( $id, $name, $current, array $options, $label ) {
		?>
		<p class="atlas-cb-field-row">
			<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
			<select id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>">
				<?php foreach ( $options as $value => $text ) : ?>
					<option value="<?php echo esc_attr( $value ); ?>" <?php selected( (string) $current, (string) $value ); ?>><?php echo esc_html( $text ); ?></option>
				<?php endforeach; ?>
			</select>
		</p>
		<?php
	}

	/**
	 * A labelled number input with an optional unit after it.
	 *
	 * @param string $id    Field ID.
	 * @param string $name  Field name.
	 * @param int    $value Current value.
	 * @param string $label Label.
	 * @param int    $min   Minimum.
	 * @param int    $max   Maximum.
	 * @param string $unit  Unit shown after the field.
	 */
	private static function number( $id, $name, $value, $label, $min, $max, $unit = '' ) {
		?>
		<p class="atlas-cb-field-row">
			<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
			<input type="number" id="<?php echo esc_attr( $id ); ?>" class="small-text" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" min="<?php echo esc_attr( $min ); ?>" max="<?php echo esc_attr( $max ); ?>">
			<?php echo '' !== $unit ? '<span class="atlas-cb-unit">' . esc_html( $unit ) . '</span>' : ''; ?>
		</p>
		<?php
	}

	/**
	 * A colour input that can fall back to the default (empty value).
	 *
	 * @param string $id       Field ID.
	 * @param string $name     Field name.
	 * @param string $value    Hex colour or empty.
	 * @param string $label    Label.
	 * @param string $fallback Colour shown while the default is used.
	 */
	private static function colour( $id, $name, $value, $label, $fallback ) {
		$default = '' === $value;
		?>
		<p class="atlas-cb-field-row atlas-cb-colour">
			<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
			<input type="color" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $default ? $fallback : $value ); ?>" <?php disabled( $default ); ?>>
			<label class="atlas-cb-check"><input type="checkbox" class="atlas-cb-colour-default" data-target="<?php echo esc_attr( $id ); ?>" <?php checked( $default ); ?>> <?php esc_html_e( 'Default', 'atlas-content-blocks' ); ?></label>
		</p>
		<?php
	}

	/**
	 * One location row: a grouped select, the extra field the location needs
	 * and a "Remove" button. admin.js moves the extra fields between rows.
	 *
	 * @param string $index   Row index.
	 * @param string $current Chosen location, or empty for the template row.
	 * @param array  $s       Settings.
	 */
	private static function location_row( $index, $current, array $s ) {
		$id = 'atlas-cb-location-' . $index;
		?>
		<li class="atlas-cb-location">
			<label class="screen-reader-text" for="<?php echo esc_attr( $id ); ?>"><?php esc_html_e( 'Location', 'atlas-content-blocks' ); ?></label>
			<select id="<?php echo esc_attr( $id ); ?>" name="atlas_cb[locations][]" class="atlas-cb-location-select">
				<?php foreach ( Atlas_CB_Settings::location_groups() as $group => $options ) : ?>
					<optgroup label="<?php echo esc_attr( $group ); ?>">
						<?php foreach ( $options as $value => $label ) : ?>
							<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $current, $value ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</optgroup>
				<?php endforeach; ?>
			</select>
			<span class="atlas-cb-location-slot">
				<?php
				if ( in_array( $current, array( 'after_paragraph', 'before_heading', 'custom' ), true ) ) {
					self::location_extra( $current, $s );
				}
				?>
			</span>
			<button type="button" class="button-link atlas-cb-remove-location"><?php esc_html_e( 'Remove', 'atlas-content-blocks' ); ?></button>
		</li>
		<?php
	}

	/**
	 * The extra field of a location: paragraph number, heading number or hook
	 * name. Each is printed once, so it always submits exactly one value.
	 *
	 * @param string $location after_paragraph, before_heading or custom.
	 * @param array  $s        Settings.
	 */
	private static function location_extra( $location, array $s ) {
		if ( 'custom' === $location ) {
			?>
			<span class="atlas-cb-location-extra" data-location="custom">
				<label for="atlas-cb-custom-hook"><?php esc_html_e( 'Hook name', 'atlas-content-blocks' ); ?></label>
				<input type="text" id="atlas-cb-custom-hook" class="regular-text code" name="atlas_cb[custom_hook]" value="<?php echo esc_attr( $s['custom_hook'] ); ?>" placeholder="my_theme_hook">
			</span>
			<?php
			return;
		}

		$key   = 'after_paragraph' === $location ? 'paragraph' : 'heading';
		$label = 'paragraph' === $key ? __( 'Paragraph number', 'atlas-content-blocks' ) : __( 'Heading number', 'atlas-content-blocks' );
		?>
		<span class="atlas-cb-location-extra" data-location="<?php echo esc_attr( $location ); ?>">
			<label for="<?php echo esc_attr( 'atlas-cb-' . $key ); ?>"><?php echo esc_html( $label ); ?></label>
			<input type="number" id="<?php echo esc_attr( 'atlas-cb-' . $key ); ?>" class="small-text" name="<?php echo esc_attr( 'atlas_cb[' . $key . ']' ); ?>" value="<?php echo esc_attr( $s[ $key ] ); ?>" min="1" max="100">
		</span>
		<?php
	}

	/**
	 * @param WP_Post $post Block being edited.
	 */
	public static function render( $post ) {
		$s      = Atlas_CB_Settings::get( $post->ID );
		$popup  = $s['popup'];
		$c      = $s['container'];
		$n      = 'atlas_cb[popup]';
		$manual = ! $s['locations'];

		$structures = array(
			'default' => __( 'Default (no wrapper styling)', 'atlas-content-blocks' ),
			'none'    => __( 'None (no spacing around the block)', 'atlas-content-blocks' ),
			'custom'  => __( 'Custom (theme container)', 'atlas-content-blocks' ),
		);

		wp_nonce_field( 'atlas_cb_save_' . $post->ID, self::NONCE );
		?>
		<div class="atlas-cb-settings" data-type="<?php echo esc_attr( $s['type'] ); ?>" data-trigger="<?php echo esc_attr( $popup['trigger'] ); ?>" data-relaunch="<?php echo esc_attr( $popup['relaunch'] ); ?>" data-size="<?php echo esc_attr( $popup['size'] ); ?>" data-structure="<?php echo esc_attr( $c['structure'] ); ?>" data-mode="<?php echo esc_attr( $s['conditions']['mode'] ); ?>" data-placement="<?php echo $manual ? 'manual' : 'locations'; ?>" data-backdrop="<?php echo esc_attr( $popup['backdrop'] ); ?>">

			<fieldset class="atlas-cb-section atlas-cb-type">
				<legend><?php esc_html_e( 'Type', 'atlas-content-blocks' ); ?></legend>
				<label><input type="radio" name="atlas_cb[type]" value="hook" <?php checked( $s['type'], 'hook' ); ?>> <?php esc_html_e( 'Content block (placed at locations in the page)', 'atlas-content-blocks' ); ?></label>
				<label><input type="radio" name="atlas_cb[type]" value="popup" <?php checked( $s['type'], 'popup' ); ?>> <?php esc_html_e( 'Popup', 'atlas-content-blocks' ); ?></label>
			</fieldset>

			<fieldset class="atlas-cb-section atlas-cb-only-hook atlas-cb-placement">
				<legend><?php esc_html_e( 'Placement', 'atlas-content-blocks' ); ?></legend>
				<p class="atlas-cb-choice">
					<label><input type="radio" name="atlas_cb[placement]" value="locations" <?php checked( ! $manual ); ?>> <?php esc_html_e( 'At these locations', 'atlas-content-blocks' ); ?></label>
					<label><input type="radio" name="atlas_cb[placement]" value="manual" <?php checked( $manual ); ?>> <?php esc_html_e( 'Placed by hand only (block or shortcode)', 'atlas-content-blocks' ); ?></label>
				</p>
				<div class="atlas-cb-only-placement-locations">
					<ul class="atlas-cb-locations">
						<?php
						foreach ( $s['locations'] as $i => $location ) {
							self::location_row( (string) $i, $location, $s );
						}
						?>
					</ul>
					<p><button type="button" class="button atlas-cb-add-location"><?php esc_html_e( 'Add another location', 'atlas-content-blocks' ); ?></button></p>
					<p class="description"><?php esc_html_e( 'Each location can be used once. In-content locations count top-level paragraphs and headings of the main post content only. With fewer paragraphs the block goes at the end; with fewer headings it is left out.', 'atlas-content-blocks' ); ?></p>
					<?php self::number( 'atlas-cb-priority', 'atlas_cb[priority]', $s['priority'], __( 'Priority (lower runs first)', 'atlas-content-blocks' ), -1000, 1000 ); ?>
				</div>
				<p class="description atlas-cb-only-placement-manual"><?php esc_html_e( 'Not placed automatically. Place it by hand with the "Content Block" block or the shortcode shown at the bottom of this box (after publishing).', 'atlas-content-blocks' ); ?></p>
				<div class="atlas-cb-location-extras" hidden>
					<?php
					foreach ( array( 'after_paragraph', 'before_heading', 'custom' ) as $location ) {
						if ( ! in_array( $location, $s['locations'], true ) ) {
							self::location_extra( $location, $s );
						}
					}
					?>
				</div>
				<template class="atlas-cb-location-template"><?php self::location_row( '__l__', '', $s ); ?></template>
			</fieldset>

			<details class="atlas-cb-section atlas-cb-details atlas-cb-only-hook">
				<summary><span class="atlas-cb-details-title"><?php esc_html_e( 'Container', 'atlas-content-blocks' ); ?></span> <span class="atlas-cb-details-summary atlas-cb-structure-summary"><?php echo esc_html( $structures[ $c['structure'] ] ?? '' ); ?></span></summary>
				<div class="atlas-cb-details-body">
					<?php
					self::select(
						'atlas-cb-structure',
						'atlas_cb[container][structure]',
						$c['structure'],
						$structures,
						__( 'Structure', 'atlas-content-blocks' )
					);
					?>
					<div class="atlas-cb-only-structure-custom">
						<?php
						self::select(
							'atlas-cb-width',
							'atlas_cb[container][width]',
							$c['width'],
							array(
								'boxed' => __( 'Boxed (theme container, up to 1320px)', 'atlas-content-blocks' ),
								'wide'  => __( 'Wide (full width)', 'atlas-content-blocks' ),
							),
							__( 'Layout width', 'atlas-content-blocks' )
						);
						self::select(
							'atlas-cb-content-width',
							'atlas_cb[container][content]',
							$c['content'],
							array(
								'standard' => __( 'Standard', 'atlas-content-blocks' ),
								'narrow'   => __( 'Narrow (710px)', 'atlas-content-blocks' ),
							),
							__( 'Content layout', 'atlas-content-blocks' )
						);
						?>
					</div>
					<div class="atlas-cb-not-structure-none">
						<?php
						$spacings = array(
							'none'   => __( 'None', 'atlas-content-blocks' ),
							'small'  => __( 'Small', 'atlas-content-blocks' ),
							'medium' => __( 'Medium', 'atlas-content-blocks' ),
							'large'  => __( 'Large', 'atlas-content-blocks' ),
						);
						self::select( 'atlas-cb-spacing-top', 'atlas_cb[container][spacing_top]', $c['spacing_top'], $spacings, __( 'Spacing above', 'atlas-content-blocks' ) );
						self::select( 'atlas-cb-spacing-bottom', 'atlas_cb[container][spacing_bottom]', $c['spacing_bottom'], $spacings, __( 'Spacing below', 'atlas-content-blocks' ) );
						?>
						<p class="description"><?php esc_html_e( 'Uses the theme spacing scale (Theme settings).', 'atlas-content-blocks' ); ?></p>
					</div>
				</div>
			</details>

			<div class="atlas-cb-section atlas-cb-conditions">
				<h3 class="atlas-cb-section-title"><?php esc_html_e( 'Display conditions', 'atlas-content-blocks' ); ?></h3>
				<div class="atlas-cb-summary-row">
					<p id="atlas-cb-conditions-summary" class="atlas-cb-conditions-summary"><?php echo esc_html( Atlas_CB_Summary::conditions( $s ) ); ?></p>
					<button type="button" class="button atlas-cb-edit-conditions" aria-haspopup="dialog" aria-describedby="atlas-cb-conditions-summary"><?php esc_html_e( 'Edit conditions', 'atlas-content-blocks' ); ?></button>
				</div>

				<dialog class="atlas-cb-dialog" aria-labelledby="atlas-cb-dialog-title">
					<div class="atlas-cb-dialog-header">
						<h2 id="atlas-cb-dialog-title"><?php esc_html_e( 'Display conditions', 'atlas-content-blocks' ); ?></h2>
					</div>
					<div class="atlas-cb-dialog-body">
						<div class="atlas-cb-conditions-editor">
							<fieldset class="atlas-cb-choice">
								<legend class="screen-reader-text"><?php esc_html_e( 'Conditions mode', 'atlas-content-blocks' ); ?></legend>
								<label><input type="radio" name="atlas_cb[conditions][mode]" value="basic" <?php checked( $s['conditions']['mode'], 'basic' ); ?>> <?php esc_html_e( 'Basic: include and exclude', 'atlas-content-blocks' ); ?></label>
								<label><input type="radio" name="atlas_cb[conditions][mode]" value="advanced" <?php checked( $s['conditions']['mode'], 'advanced' ); ?>> <?php esc_html_e( 'Advanced: groups of rules', 'atlas-content-blocks' ); ?></label>
							</fieldset>

							<div class="atlas-cb-only-mode-basic">
								<p class="description"><?php esc_html_e( 'Shown when an include rule of each kind used matches (for example a page rule and a visitor rule), unless an exclude rule matches. No include rules: shown nowhere.', 'atlas-content-blocks' ); ?></p>
								<?php self::rules_table( 'atlas_cb[conditions][include]', __( 'Include', 'atlas-content-blocks' ), $s['conditions']['include'], false ); ?>
								<?php self::rules_table( 'atlas_cb[conditions][exclude]', __( 'Exclude', 'atlas-content-blocks' ), $s['conditions']['exclude'], false ); ?>
							</div>

							<div class="atlas-cb-only-mode-advanced">
								<p class="description"><?php esc_html_e( 'Shown when every rule in at least one group matches (OR between groups, AND inside a group).', 'atlas-content-blocks' ); ?></p>
								<div class="atlas-cb-groups">
									<?php foreach ( $s['conditions']['groups'] as $g => $group ) : ?>
										<?php self::group( (string) $g, $group['rules'] ?? array() ); ?>
									<?php endforeach; ?>
								</div>
								<p><button type="button" class="button atlas-cb-add-group"><?php esc_html_e( 'Add group', 'atlas-content-blocks' ); ?></button></p>
							</div>
							<p class="description"><?php esc_html_e( 'Date, time, request and visitor rules need page caching to vary on them, or to be off for those pages.', 'atlas-content-blocks' ); ?></p>
						</div>
					</div>
					<div class="atlas-cb-dialog-footer">
						<button type="button" class="button atlas-cb-dialog-cancel"><?php esc_html_e( 'Cancel', 'atlas-content-blocks' ); ?></button>
						<button type="button" class="button button-primary atlas-cb-dialog-apply"><?php esc_html_e( 'Apply', 'atlas-content-blocks' ); ?></button>
					</div>
				</dialog>
				<template class="atlas-cb-group-template"><?php self::group( '__g__', array( array( 'rule' => 'entire_site' ) ) ); ?></template>
				<template class="atlas-cb-rule-template" data-negation="0"><?php self::rule_row( '__name__', '__i__', array( 'rule' => 'entire_site' ), false ); ?></template>
				<template class="atlas-cb-rule-template" data-negation="1"><?php self::rule_row( '__name__', '__i__', array( 'rule' => 'entire_site' ), true ); ?></template>
			</div>

			<details class="atlas-cb-section atlas-cb-details atlas-cb-only-popup" open>
				<summary><span class="atlas-cb-details-title"><?php esc_html_e( 'Popup triggers', 'atlas-content-blocks' ); ?></span> <span class="atlas-cb-details-summary atlas-cb-trigger-summary"><?php echo esc_html( Atlas_CB_Summary::trigger( $popup ) ); ?></span></summary>
				<div class="atlas-cb-details-body">
					<?php
					self::select(
						'atlas-cb-trigger',
						$n . '[trigger]',
						$popup['trigger'],
						array(
							'click'          => __( 'Only on click', 'atlas-content-blocks' ),
							'load'           => __( 'On page load', 'atlas-content-blocks' ),
							'delay'          => __( 'After a number of seconds', 'atlas-content-blocks' ),
							'scroll_down'    => __( 'On scroll down', 'atlas-content-blocks' ),
							'scroll_up'      => __( 'On scroll up', 'atlas-content-blocks' ),
							'scroll_element' => __( 'When an element comes into view', 'atlas-content-blocks' ),
							'inactivity'     => __( 'After inactivity', 'atlas-content-blocks' ),
							'pages'          => __( 'After a number of pages visited', 'atlas-content-blocks' ),
							'exit'           => __( 'Exit intent (desktop)', 'atlas-content-blocks' ),
						),
						__( 'Opens', 'atlas-content-blocks' )
					);
					?>
					<div class="atlas-cb-only-trigger-delay"><?php self::number( 'atlas-cb-delay', $n . '[delay]', $popup['delay'], __( 'Delay', 'atlas-content-blocks' ), 0, 3600, __( 'seconds', 'atlas-content-blocks' ) ); ?></div>
					<div class="atlas-cb-only-trigger-scroll_down">
						<?php self::number( 'atlas-cb-scroll', $n . '[scroll]', $popup['scroll'], __( 'Scrolled', 'atlas-content-blocks' ), 0, 100000 ); ?>
						<?php
						self::select(
							'atlas-cb-scroll-unit',
							$n . '[scroll_unit]',
							$popup['scroll_unit'],
							array(
								'px' => __( 'pixels', 'atlas-content-blocks' ),
								'%'  => __( 'percent of the page', 'atlas-content-blocks' ),
							),
							__( 'Unit', 'atlas-content-blocks' )
						);
						?>
					</div>
					<p class="atlas-cb-only-trigger-scroll_element atlas-cb-field-row">
						<label for="atlas-cb-scroll-element"><?php esc_html_e( 'Element (CSS selector)', 'atlas-content-blocks' ); ?></label>
						<input type="text" id="atlas-cb-scroll-element" class="regular-text code" name="<?php echo esc_attr( $n ); ?>[scroll_element]" value="<?php echo esc_attr( $popup['scroll_element'] ); ?>" placeholder="#pricing">
					</p>
					<div class="atlas-cb-only-trigger-inactivity"><?php self::number( 'atlas-cb-inactivity', $n . '[inactivity]', $popup['inactivity'], __( 'Inactive for', 'atlas-content-blocks' ), 1, 3600, __( 'seconds', 'atlas-content-blocks' ) ); ?></div>
					<div class="atlas-cb-only-trigger-pages"><?php self::number( 'atlas-cb-pages', $n . '[pages]', $popup['pages'], __( 'Pages visited', 'atlas-content-blocks' ), 1, 1000 ); ?></div>
					<p class="atlas-cb-field-row">
						<label for="atlas-cb-selector"><?php esc_html_e( 'Also open on click of (CSS selector, optional)', 'atlas-content-blocks' ); ?></label>
						<input type="text" id="atlas-cb-selector" class="regular-text code" name="<?php echo esc_attr( $n ); ?>[selector]" value="<?php echo esc_attr( $popup['selector'] ); ?>" placeholder="#ebookwfm, .open-demo-form">
					</p>
					<p class="description">
						<?php
						printf(
							/* translators: 1: class name, 2: link target */
							esc_html__( 'Always opens from elements with the class %1$s or links to %2$s.', 'atlas-content-blocks' ),
							'<code>atlas-popup-' . (int) $post->ID . '</code>',
							'<code>#atlas-popup-' . (int) $post->ID . '</code>'
						);
						?>
					</p>
					<div class="atlas-cb-not-trigger-click">
						<?php
						self::select(
							'atlas-cb-relaunch',
							$n . '[relaunch]',
							$popup['relaunch'],
							array(
								'always'   => __( 'Always (every page view)', 'atlas-content-blocks' ),
								'session'  => __( 'Once per visit', 'atlas-content-blocks' ),
								'interval' => __( 'Again after a while', 'atlas-content-blocks' ),
							),
							__( 'Relaunch', 'atlas-content-blocks' )
						);
						?>
						<div class="atlas-cb-only-relaunch-interval atlas-cb-inline">
							<?php self::number( 'atlas-cb-relaunch-amount', $n . '[relaunch_amount]', $popup['relaunch_amount'], __( 'After', 'atlas-content-blocks' ), 1, 1000 ); ?>
							<?php
							self::select(
								'atlas-cb-relaunch-unit',
								$n . '[relaunch_unit]',
								$popup['relaunch_unit'],
								array(
									'minutes' => __( 'minutes', 'atlas-content-blocks' ),
									'hours'   => __( 'hours', 'atlas-content-blocks' ),
									'days'    => __( 'days', 'atlas-content-blocks' ),
								),
								__( 'Unit', 'atlas-content-blocks' )
							);
							?>
						</div>
						<p class="description"><?php esc_html_e( 'Applies to the automatic trigger only, remembered in the visitor\'s browser. A click always opens.', 'atlas-content-blocks' ); ?></p>
					</div>
				</div>
			</details>

			<details class="atlas-cb-section atlas-cb-details atlas-cb-only-popup">
				<summary><span class="atlas-cb-details-title"><?php esc_html_e( 'Popup behaviour', 'atlas-content-blocks' ); ?></span></summary>
				<div class="atlas-cb-details-body">
					<?php
					self::checkbox( $n . '[close_overlay]', $popup['close_overlay'], __( 'Close when the backdrop is clicked', 'atlas-content-blocks' ) );
					self::checkbox( $n . '[close_esc]', $popup['close_esc'], __( 'Close with the Escape key', 'atlas-content-blocks' ) );
					self::checkbox( $n . '[close_submit]', $popup['close_submit'], __( 'Close when a form inside is submitted (also HubSpot forms)', 'atlas-content-blocks' ) );
					self::checkbox( $n . '[close_scroll]', $popup['close_scroll'], __( 'Close when the visitor scrolls back up past where it opened (needs scroll lock off)', 'atlas-content-blocks' ) );
					?>
					<p class="atlas-cb-field-row">
						<label for="atlas-cb-close-selector"><?php esc_html_e( 'Also close on click of (CSS selector, optional)', 'atlas-content-blocks' ); ?></label>
						<input type="text" id="atlas-cb-close-selector" class="regular-text code" name="<?php echo esc_attr( $n ); ?>[close_selector]" value="<?php echo esc_attr( $popup['close_selector'] ); ?>" placeholder=".close-popup">
					</p>
					<?php self::number( 'atlas-cb-close-delay', $n . '[close_delay]', $popup['close_delay'], __( 'Delay before closing on click or form submit', 'atlas-content-blocks' ), 0, 600, __( 'seconds', 'atlas-content-blocks' ) ); ?>
					<?php
					self::select(
						'atlas-cb-animation',
						$n . '[animation]',
						$popup['animation'],
						array(
							'none'         => __( 'None', 'atlas-content-blocks' ),
							'fade'         => __( 'Fade', 'atlas-content-blocks' ),
							'zoom'         => __( 'Zoom', 'atlas-content-blocks' ),
							'slide-top'    => __( 'Slide from the top', 'atlas-content-blocks' ),
							'slide-bottom' => __( 'Slide from the bottom', 'atlas-content-blocks' ),
							'slide-left'   => __( 'Slide from the left', 'atlas-content-blocks' ),
							'slide-right'  => __( 'Slide from the right', 'atlas-content-blocks' ),
						),
						__( 'Animation', 'atlas-content-blocks' )
					);
					self::checkbox( $n . '[on_demand]', $popup['on_demand'], __( 'Load content on demand (only when opened)', 'atlas-content-blocks' ) );
					self::checkbox( $n . '[focus_trap]', $popup['focus_trap'], __( 'Focus trap (modal, with backdrop). Off: the page stays usable behind the popup', 'atlas-content-blocks' ) );
					self::checkbox( $n . '[scroll_lock]', $popup['scroll_lock'], __( 'Lock page scrolling while open (modal only)', 'atlas-content-blocks' ) );
					self::checkbox( $n . '[stop_media]', $popup['stop_media'], __( 'Stop videos and audio when closed', 'atlas-content-blocks' ) );
					?>
					<p class="atlas-cb-field-row">
						<label for="atlas-cb-label"><?php esc_html_e( 'Name for screen readers', 'atlas-content-blocks' ); ?></label>
						<input type="text" id="atlas-cb-label" class="regular-text" name="<?php echo esc_attr( $n ); ?>[label]" value="<?php echo esc_attr( $popup['label'] ); ?>" placeholder="<?php echo esc_attr( get_the_title( $post ) ); ?>">
					</p>
				</div>
			</details>

			<details class="atlas-cb-section atlas-cb-details atlas-cb-only-popup">
				<summary><span class="atlas-cb-details-title"><?php esc_html_e( 'Popup design', 'atlas-content-blocks' ); ?></span></summary>
				<div class="atlas-cb-details-body">
					<?php
					self::select(
						'atlas-cb-size',
						$n . '[size]',
						$popup['size'],
						array(
							'small'  => __( 'Small (420px)', 'atlas-content-blocks' ),
							'medium' => __( 'Medium (640px)', 'atlas-content-blocks' ),
							'large'  => __( 'Large (960px)', 'atlas-content-blocks' ),
							'full'   => __( 'Full screen', 'atlas-content-blocks' ),
							'custom' => __( 'Custom width', 'atlas-content-blocks' ),
						),
						__( 'Size', 'atlas-content-blocks' )
					);
					?>
					<p class="atlas-cb-only-size-custom atlas-cb-field-row">
						<label for="atlas-cb-width-custom"><?php esc_html_e( 'Width (e.g. 720px, 80vw)', 'atlas-content-blocks' ); ?></label>
						<input type="text" id="atlas-cb-width-custom" class="small-text code" name="<?php echo esc_attr( $n ); ?>[width]" value="<?php echo esc_attr( $popup['width'] ); ?>">
					</p>
					<p class="atlas-cb-field-row">
						<label for="atlas-cb-max-height"><?php esc_html_e( 'Maximum height (e.g. 80vh, empty for the window height)', 'atlas-content-blocks' ); ?></label>
						<input type="text" id="atlas-cb-max-height" class="small-text code" name="<?php echo esc_attr( $n ); ?>[max_height]" value="<?php echo esc_attr( $popup['max_height'] ); ?>">
					</p>
					<?php
					self::select(
						'atlas-cb-position',
						$n . '[position]',
						$popup['position'],
						array(
							'top-left'     => __( 'Top left', 'atlas-content-blocks' ),
							'top'          => __( 'Top', 'atlas-content-blocks' ),
							'top-right'    => __( 'Top right', 'atlas-content-blocks' ),
							'left'         => __( 'Left', 'atlas-content-blocks' ),
							'center'       => __( 'Centre', 'atlas-content-blocks' ),
							'right'        => __( 'Right', 'atlas-content-blocks' ),
							'bottom-left'  => __( 'Bottom left', 'atlas-content-blocks' ),
							'bottom'       => __( 'Bottom', 'atlas-content-blocks' ),
							'bottom-right' => __( 'Bottom right', 'atlas-content-blocks' ),
						),
						__( 'Position', 'atlas-content-blocks' )
					);
					self::number( 'atlas-cb-offset', $n . '[offset]', $popup['offset'], __( 'Offset from the edges', 'atlas-content-blocks' ), 0, 500, 'px' );
					self::number( 'atlas-cb-padding', $n . '[padding]', $popup['padding'], __( 'Padding', 'atlas-content-blocks' ), 0, 200, 'px' );
					self::number( 'atlas-cb-radius', $n . '[radius]', $popup['radius'], __( 'Border radius', 'atlas-content-blocks' ), 0, 200, 'px' );
					self::checkbox( $n . '[shadow]', $popup['shadow'], __( 'Shadow', 'atlas-content-blocks' ) );
					self::select(
						'atlas-cb-overflow',
						$n . '[overflow]',
						$popup['overflow'],
						array(
							'scroll'  => __( 'Scroll when too tall', 'atlas-content-blocks' ),
							'clip'    => __( 'Clip', 'atlas-content-blocks' ),
							'visible' => __( 'Visible', 'atlas-content-blocks' ),
						),
						__( 'Content overflow', 'atlas-content-blocks' )
					);
					self::colour( 'atlas-cb-background', $n . '[background]', $popup['background'], __( 'Popup background', 'atlas-content-blocks' ), '#ffffff' );
					self::select(
						'atlas-cb-close-position',
						$n . '[close_position]',
						$popup['close_position'],
						array(
							'inside'  => __( 'Inside the top right corner', 'atlas-content-blocks' ),
							'outside' => __( 'Outside, above the top right corner', 'atlas-content-blocks' ),
						),
						__( 'Close button position', 'atlas-content-blocks' )
					);
					self::colour( 'atlas-cb-close-color', $n . '[close_color]', $popup['close_color'], __( 'Close button icon colour', 'atlas-content-blocks' ), '#ffffff' );
					self::colour( 'atlas-cb-close-bg', $n . '[close_bg]', $popup['close_bg'], __( 'Close button background', 'atlas-content-blocks' ), '#000000' );
					self::checkbox( $n . '[backdrop]', $popup['backdrop'], __( 'Show a backdrop', 'atlas-content-blocks' ) );
					?>
					<div class="atlas-cb-only-backdrop">
						<p class="atlas-cb-field-row">
							<label for="atlas-cb-backdrop-color"><?php esc_html_e( 'Backdrop colour', 'atlas-content-blocks' ); ?></label>
							<input type="color" id="atlas-cb-backdrop-color" name="<?php echo esc_attr( $n ); ?>[backdrop_color]" value="<?php echo esc_attr( $popup['backdrop_color'] ); ?>">
						</p>
						<?php self::number( 'atlas-cb-backdrop-alpha', $n . '[backdrop_alpha]', $popup['backdrop_alpha'], __( 'Backdrop opacity', 'atlas-content-blocks' ), 0, 100, '%' ); ?>
						<?php self::number( 'atlas-cb-backdrop-blur', $n . '[backdrop_blur]', $popup['backdrop_blur'], __( 'Backdrop blur', 'atlas-content-blocks' ), 0, 50, 'px' ); ?>
					</div>
				</div>
			</details>

			<fieldset class="atlas-cb-section">
				<legend><?php esc_html_e( 'Devices', 'atlas-content-blocks' ); ?></legend>
				<p class="description"><?php esc_html_e( 'Hide on:', 'atlas-content-blocks' ); ?></p>
				<?php
				$devices = array(
					'mobile'  => __( 'Mobile (below 768px)', 'atlas-content-blocks' ),
					'tablet'  => __( 'Tablet (768 to 1199px)', 'atlas-content-blocks' ),
					'desktop' => __( 'Desktop (1200px and wider)', 'atlas-content-blocks' ),
				);
				foreach ( $devices as $device => $label ) :
					?>
					<label class="atlas-cb-check"><input type="checkbox" name="atlas_cb[hide_on][]" value="<?php echo esc_attr( $device ); ?>" <?php checked( in_array( $device, $s['hide_on'], true ) ); ?>> <?php echo esc_html( $label ); ?></label>
				<?php endforeach; ?>
			</fieldset>

			<?php if ( 'publish' === $post->post_status ) : ?>
				<p class="atlas-cb-manual-hint">
					<?php esc_html_e( 'Place by hand with the "Content Block" block or:', 'atlas-content-blocks' ); ?>
					<code>[atlas_content_block id="<?php echo (int) $post->ID; ?>"]</code>
				</p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * One advanced-mode group.
	 *
	 * @param string $g     Group index.
	 * @param array  $rules Rules.
	 */
	private static function group( $g, array $rules ) {
		?>
		<div class="atlas-cb-group">
			<?php self::rules_table( 'atlas_cb[conditions][groups][' . $g . '][rules]', __( 'Group: all of these match', 'atlas-content-blocks' ), $rules, true ); ?>
			<p><button type="button" class="button-link atlas-cb-remove-group"><?php esc_html_e( 'Remove group', 'atlas-content-blocks' ); ?></button></p>
		</div>
		<?php
	}

	/**
	 * @param string $name     Field name prefix.
	 * @param string $label    Table caption.
	 * @param array  $rules    Stored rules.
	 * @param bool   $negation Rows can be negated.
	 */
	private static function rules_table( $name, $label, array $rules, $negation ) {
		?>
		<table class="atlas-cb-rules widefat" data-name="<?php echo esc_attr( $name ); ?>" data-negation="<?php echo $negation ? '1' : '0'; ?>">
			<caption><?php echo esc_html( $label ); ?></caption>
			<tbody>
				<?php foreach ( array_values( $rules ) as $i => $rule ) : ?>
					<?php self::rule_row( $name, (string) $i, $rule, $negation ); ?>
				<?php endforeach; ?>
			</tbody>
			<tfoot>
				<tr><td colspan="3"><button type="button" class="button atlas-cb-add-rule"><?php esc_html_e( 'Add rule', 'atlas-content-blocks' ); ?></button></td></tr>
			</tfoot>
		</table>
		<?php
	}

	/**
	 * One rule row: the rule select and every value field, of which the script
	 * shows the ones the chosen rule uses.
	 *
	 * @param string $name     Field name prefix.
	 * @param string $index    Row index.
	 * @param array  $rule     Rule.
	 * @param bool   $negation Show the "is not" choice.
	 */
	private static function rule_row( $name, $index, array $rule, $negation ) {
		$types   = Atlas_CB_Settings::rule_types();
		$current = $rule['rule'] ?? 'entire_site';
		$field   = function ( $key ) use ( $name, $index ) {
			return $name . '[' . $index . '][' . $key . ']';
		};
		$choices = Atlas_CB_Settings::rule_choices();

		// Keep a stored rule that is no longer offered (such as Language without WPML).
		if ( isset( $types[ $current ] ) && ! in_array( $current, array_merge( array(), ...array_map( 'array_keys', array_values( $choices ) ) ), true ) ) {
			$choices[ $types[ $current ]['group'] ][ $current ] = $types[ $current ]['label'];
		}

		$weekdays = array(
			1 => __( 'Mon', 'atlas-content-blocks' ),
			2 => __( 'Tue', 'atlas-content-blocks' ),
			3 => __( 'Wed', 'atlas-content-blocks' ),
			4 => __( 'Thu', 'atlas-content-blocks' ),
			5 => __( 'Fri', 'atlas-content-blocks' ),
			6 => __( 'Sat', 'atlas-content-blocks' ),
			7 => __( 'Sun', 'atlas-content-blocks' ),
		);
		$days     = array_map( 'intval', (array) ( $rule['days'] ?? array() ) );
		?>
		<tr class="atlas-cb-rule">
			<td class="atlas-cb-rule-main">
				<?php if ( $negation ) : ?>
					<label class="screen-reader-text" for="<?php echo esc_attr( 'atlas-cb-not-' . $name . $index ); ?>"><?php esc_html_e( 'Match', 'atlas-content-blocks' ); ?></label>
					<select id="<?php echo esc_attr( 'atlas-cb-not-' . $name . $index ); ?>" name="<?php echo esc_attr( $field( 'not' ) ); ?>" class="atlas-cb-rule-not">
						<option value="0" <?php selected( empty( $rule['not'] ) ); ?>><?php esc_html_e( 'is', 'atlas-content-blocks' ); ?></option>
						<option value="1" <?php selected( ! empty( $rule['not'] ) ); ?>><?php esc_html_e( 'is not', 'atlas-content-blocks' ); ?></option>
					</select>
				<?php endif; ?>
				<label class="screen-reader-text" for="<?php echo esc_attr( 'atlas-cb-rule-' . $name . $index ); ?>"><?php esc_html_e( 'Rule', 'atlas-content-blocks' ); ?></label>
				<select id="<?php echo esc_attr( 'atlas-cb-rule-' . $name . $index ); ?>" name="<?php echo esc_attr( $field( 'rule' ) ); ?>" class="atlas-cb-rule-select">
					<?php foreach ( $choices as $group => $options ) : ?>
						<optgroup label="<?php echo esc_attr( $group ); ?>">
							<?php foreach ( $options as $value => $label ) : ?>
								<option value="<?php echo esc_attr( $value ); ?>" data-fields="<?php echo esc_attr( implode( ' ', $types[ $value ]['fields'] ?? array() ) ); ?>" <?php selected( $current, $value ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</optgroup>
					<?php endforeach; ?>
				</select>
			</td>
			<td><div class="atlas-cb-rule-fields">
				<label class="atlas-cb-field" data-field="ids"><span><?php esc_html_e( 'IDs (comma separated)', 'atlas-content-blocks' ); ?></span>
					<input type="text" class="regular-text" name="<?php echo esc_attr( $field( 'ids' ) ); ?>" value="<?php echo esc_attr( $rule['ids'] ?? '' ); ?>" placeholder="796, 1024"></label>

				<label class="atlas-cb-field" data-field="taxonomy"><span><?php esc_html_e( 'Taxonomy', 'atlas-content-blocks' ); ?></span>
					<select name="<?php echo esc_attr( $field( 'taxonomy' ) ); ?>">
						<?php foreach ( get_taxonomies( array( 'show_ui' => true ), 'objects' ) as $taxonomy ) : ?>
							<option value="<?php echo esc_attr( $taxonomy->name ); ?>" <?php selected( $rule['taxonomy'] ?? 'category', $taxonomy->name ); ?>><?php echo esc_html( $taxonomy->labels->singular_name . ' (' . $taxonomy->name . ')' ); ?></option>
						<?php endforeach; ?>
					</select></label>

				<label class="atlas-cb-field" data-field="terms"><span><?php esc_html_e( 'Term IDs or slugs (comma separated; empty for any term on archives)', 'atlas-content-blocks' ); ?></span>
					<input type="text" class="regular-text" name="<?php echo esc_attr( $field( 'terms' ) ); ?>" value="<?php echo esc_attr( $rule['terms'] ?? '' ); ?>" placeholder="news, 12"></label>

				<label class="atlas-cb-field" data-field="role"><span><?php esc_html_e( 'Role', 'atlas-content-blocks' ); ?></span>
					<select name="<?php echo esc_attr( $field( 'role' ) ); ?>">
						<?php foreach ( wp_roles()->get_names() as $role => $role_name ) : ?>
							<option value="<?php echo esc_attr( $role ); ?>" <?php selected( $rule['role'] ?? '', $role ); ?>><?php echo esc_html( translate_user_role( $role_name ) ); ?></option>
						<?php endforeach; ?>
					</select></label>

				<fieldset class="atlas-cb-field atlas-cb-days" data-field="days">
					<legend><?php esc_html_e( 'Days', 'atlas-content-blocks' ); ?></legend>
					<?php foreach ( $weekdays as $number => $day ) : ?>
						<label><input type="checkbox" name="<?php echo esc_attr( $field( 'days' ) ); ?>[]" value="<?php echo esc_attr( $number ); ?>" <?php checked( in_array( $number, $days, true ) ); ?>> <?php echo esc_html( $day ); ?></label>
					<?php endforeach; ?>
				</fieldset>

				<label class="atlas-cb-field" data-field="from"><span><?php esc_html_e( 'From (optional)', 'atlas-content-blocks' ); ?></span>
					<input type="time" name="<?php echo esc_attr( $field( 'from' ) ); ?>" value="<?php echo esc_attr( $rule['from'] ?? '' ); ?>"></label>

				<label class="atlas-cb-field" data-field="to"><span><?php esc_html_e( 'Until (optional)', 'atlas-content-blocks' ); ?></span>
					<input type="time" name="<?php echo esc_attr( $field( 'to' ) ); ?>" value="<?php echo esc_attr( $rule['to'] ?? '' ); ?>"></label>

				<label class="atlas-cb-field" data-field="start"><span><?php esc_html_e( 'From (site time zone)', 'atlas-content-blocks' ); ?></span>
					<input type="datetime-local" name="<?php echo esc_attr( $field( 'start' ) ); ?>" value="<?php echo esc_attr( $rule['start'] ?? '' ); ?>"></label>

				<label class="atlas-cb-field" data-field="end"><span><?php esc_html_e( 'Until (site time zone)', 'atlas-content-blocks' ); ?></span>
					<input type="datetime-local" name="<?php echo esc_attr( $field( 'end' ) ); ?>" value="<?php echo esc_attr( $rule['end'] ?? '' ); ?>"></label>

				<label class="atlas-cb-field" data-field="name"><span><?php esc_html_e( 'Cookie name', 'atlas-content-blocks' ); ?></span>
					<input type="text" class="code" name="<?php echo esc_attr( $field( 'name' ) ); ?>" value="<?php echo esc_attr( $rule['name'] ?? '' ); ?>"></label>

				<label class="atlas-cb-field" data-field="operator"><span><?php esc_html_e( 'Comparison', 'atlas-content-blocks' ); ?></span>
					<select name="<?php echo esc_attr( $field( 'operator' ) ); ?>">
						<?php foreach ( Atlas_CB_Settings::operators() as $operator => $operator_label ) : ?>
							<option value="<?php echo esc_attr( $operator ); ?>" <?php selected( $rule['operator'] ?? 'contains', $operator ); ?>><?php echo esc_html( $operator_label ); ?></option>
						<?php endforeach; ?>
					</select></label>

				<label class="atlas-cb-field" data-field="value"><span><?php esc_html_e( 'Value (cookie: empty means the cookie is set)', 'atlas-content-blocks' ); ?></span>
					<input type="text" class="regular-text" name="<?php echo esc_attr( $field( 'value' ) ); ?>" value="<?php echo esc_attr( $rule['value'] ?? '' ); ?>"></label>

				<label class="atlas-cb-field" data-field="language"><span><?php esc_html_e( 'Language', 'atlas-content-blocks' ); ?></span>
					<?php self::language_input( $field( 'language' ), $rule['language'] ?? '' ); ?></label>
			</div></td>
			<td class="atlas-cb-rule-actions">
				<button type="button" class="button-link atlas-cb-remove-rule"><?php esc_html_e( 'Remove', 'atlas-content-blocks' ); ?></button>
			</td>
		</tr>
		<?php
	}

	/**
	 * WPML languages as a select, or a text field without WPML.
	 *
	 * @param string $name    Field name.
	 * @param string $current Current language code.
	 */
	private static function language_input( $name, $current ) {
		$languages = apply_filters( 'wpml_active_languages', null, array( 'skip_missing' => 0 ) );

		if ( ! is_array( $languages ) || ! $languages ) {
			printf( '<input type="text" class="small-text code" name="%s" value="%s">', esc_attr( $name ), esc_attr( $current ) );
			return;
		}

		echo '<select name="' . esc_attr( $name ) . '">';
		foreach ( $languages as $code => $language ) {
			$label = is_array( $language ) && isset( $language['translated_name'] ) ? $language['translated_name'] : $code;
			printf( '<option value="%s" %s>%s</option>', esc_attr( $code ), selected( $current, $code, false ), esc_html( $label ) );
		}
		echo '</select>';
	}

	/**
	 * @param int     $post_id Block ID.
	 * @param WP_Post $post    Block.
	 */
	public static function save( $post_id, $post ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( wp_is_post_revision( $post_id ) || ! isset( $_POST[ self::NONCE ], $_POST['atlas_cb'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE ] ) ), 'atlas_cb_save_' . $post_id ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$raw = wp_unslash( $_POST['atlas_cb'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitised field by field in Atlas_CB_Settings::sanitize().
		if ( ! is_array( $raw ) ) {
			return;
		}

		// update_post_meta() unslashes, so slash to keep backslashes in selectors.
		update_post_meta( $post_id, ATLAS_CB_META, wp_slash( Atlas_CB_Settings::sanitize( $raw ) ) );
		Atlas_CB_Settings::flush_index();
	}
}
